import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import DeviceDetail from './pages/DeviceDetail';
import Management from './pages/Management';
import Layout from './components/Layout';
import Alerts from './pages/Alerts';
import Reports from './pages/Reports';
import WellReport from './pages/WellReport';
import AshraeReport from './pages/AshraeReport';
import LeedReport from './pages/LeedReport';
import AhuReport from './pages/AhuReport';
import ResetReport from './pages/ResetReport';
import VapeSmokeReport from './pages/VapeSmokeReport';
import FloorPlan from './pages/FloorPlan';
import PrivateRoute from './components/PrivateRoute';
import AhuDetailPage from './pages/AhuDetailPage';
import Ashrae241Report from './pages/Ashrae241Report';
import AirPurifiers from './pages/AirPurifiers';
import GreenBuildingReport from './pages/GreenBuildingReport';
import EstidamaReport from './pages/EstidamaReport';
import BarjeelReport from './pages/BarjeelReport';
import WellSettings from './pages/WellSettings';

const App: React.FC = () => {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="/floorplan" element={<FloorPlan />} />
          <Route path="/device/:deviceId" element={<DeviceDetail />} />
          <Route element={<PrivateRoute />}>
            <Route path="/manage" element={<Management />} />
          </Route>
          <Route path="/alerts" element={<Alerts />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/well-report" element={<WellReport />} />
          <Route path="/well-settings" element={<PrivateRoute><WellSettings /></PrivateRoute>} />
          <Route path="/ashrae" element={<AshraeReport />} />
          <Route path="/ashrae-241" element={<Ashrae241Report />} />
          <Route path="/leed-report" element={<LeedReport />} />
          <Route path="/green-building-report" element={<GreenBuildingReport />} />
          <Route path="/estidama-report" element={<EstidamaReport />} />
          <Route path="/barjeel-report" element={<BarjeelReport />} />
          <Route path="/ahu-monitoring" element={<AhuReport />} />
          <Route path="/ahu-monitoring/:ahuId" element={<AhuDetailPage />} />
          <Route path="/reset-report" element={<ResetReport />} />
          <Route path="/vape-smoke-detection" element={<VapeSmokeReport />} />
          <Route path="/air-purifiers" element={<AirPurifiers />} />
        </Route>
      </Routes>
    </HashRouter>
  );
};

export default App;
