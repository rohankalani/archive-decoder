# RosaiQ Air OS - Backend Server

This directory contains the Node.js backend for the RosaiQ Air OS application. It is designed to connect to a PostgreSQL database and an MQTT broker for real-time data ingestion.

## 1. Prerequisites

- **Node.js**: (v18 or later recommended)
- **PostgreSQL**: A running PostgreSQL server (v14 or later recommended).
- **MQTT Broker (Optional for testing)**: A tool like [Mosquitto](https://mosquitto.org/) or a cloud-based broker.

## 2. Local Development Setup

### Step 1: Set up the PostgreSQL Database

1.  **Install PostgreSQL** if you don't have it already.

2.  **Install the TimescaleDB Extension:** For optimal performance with time-series data, you must install the TimescaleDB extension into your PostgreSQL instance. Follow the official **[TimescaleDB installation guide](https://docs.timescale.com/install/latest/self-hosted/)** for your operating system. This is a one-time setup for your database server.

3.  **Create a database and a user** for the application. Using `psql`:
    ```sql
    -- First, create the user and database
    CREATE DATABASE rosaiq_db;
    CREATE USER rosaiq_user WITH PASSWORD 'your_secure_password';
    
    -- Now, connect to the new database to grant privileges and enable the extension
    \c rosaiq_db
    
    -- Enable the TimescaleDB extension within your new database
    CREATE EXTENSION IF NOT EXISTS timescaledb;
    
    -- Grant privileges to your user
    GRANT ALL PRIVILEGES ON DATABASE rosaiq_db TO rosaiq_user;
    ALTER DATABASE rosaiq_db OWNER TO rosaiq_user;
    ```
    *Note: The server will automatically attempt to run `CREATE EXTENSION` on startup, but it's best practice to enable it during initial database setup.*

### Step 2: Configure Environment Variables

Create a file named `.env` in the `backend` directory. Copy the contents below and fill in your database details.

```env
# backend/.env

# PostgreSQL Connection Details
PGHOST=localhost
PGUSER=rosaiq_user
PGDATABASE=rosaiq_db
PGPASSWORD=your_secure_password
PGPORT=5432

# MQTT Broker Details
MQTT_BROKER_URL=mqtt://localhost:1883
# MQTT_USER=
# MQTT_PASSWORD=

```

### Step 3: Install Dependencies and Initialize Schema

1.  Navigate to the `backend` directory:
    ```bash
    cd backend
    ```
2.  Install the Node.js dependencies:
    ```bash
    npm install
    ```
3.  Run the database initialization script. This will create the necessary tables in your PostgreSQL database and convert the `readings` table to a hypertable.
    ```bash
    npm run db:init
    ```
    You should see output indicating that the tables were created successfully.

### Step 4: Run the Server

Start the backend server:

```bash
npm start
```

The server will start on `http://localhost:3001` and attempt to connect to your PostgreSQL database and MQTT broker using the credentials in your `.env` file.

## 3. How It Works

The server connects to the PostgreSQL database on startup. It listens for incoming sensor data from an MQTT broker on the topic `devices/+/data`. When data is received, it is processed, saved to the `readings` hypertable, and broadcast to all connected frontend clients via WebSockets.
