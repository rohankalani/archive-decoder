const express = require('express');
const router = express.Router();
const db = require('./database');

const handleRequest = (handler) => async (req, res) => {
    try {
        await handler(req, res);
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({ message: error.message || 'An internal server error occurred.' });
    }
};

router.get('/devices', handleRequest(async (req, res) => {
    const devicesWithData = await db.getAllDevicesWithLatestData();
    res.json(devicesWithData);
}));

router.get('/devices/:id', handleRequest(async (req, res) => {
    const device = await db.getDeviceWithLatestData(req.params.id);
    if (device) {
        res.json(device);
    } else {
        res.status(404).json({ message: 'Device not found' });
    }
}));

router.post('/devices', handleRequest(async (req, res) => {
    const { name, location_id, type } = req.body;
    if (!name || location_id === undefined) {
        return res.status(400).json({ message: 'Name and location_id are required' });
    }
    const newDevice = await db.addDevice(name, location_id, type);
    res.status(201).json(newDevice);
}));

router.put('/devices/:id', handleRequest(async (req, res) => {
    const { name, location_id } = req.body;
    if (!name || location_id === undefined) {
        return res.status(400).json({ message: 'Name and location_id are required' });
    }
    const updatedDevice = await db.updateDevice(req.params.id, name, location_id);
    res.json(updatedDevice);
}));

router.delete('/devices/:id', handleRequest(async (req, res) => {
    await db.deleteDevice(req.params.id);
    res.status(204).send();
}));

router.get('/devices/:id/history', handleRequest(async (req, res) => {
    const { id } = req.params;
    const { from, to, aggregation } = req.query;
    if (!from || !to || !aggregation) {
        return res.status(400).json({ message: 'Query parameters "from", "to", and "aggregation" are required.' });
    }
    const allowedAggregations = ['1h', '8h', '1d'];
    if (!allowedAggregations.includes(aggregation)) {
        return res.status(400).json({ message: `Invalid aggregation. Allowed values: ${allowedAggregations.join(', ')}` });
    }
    const data = await db.getHistoricalData(id, from, to, aggregation);
    res.json(data);
}));

router.get('/locations', handleRequest(async (req, res) => {
    const locations = await db.getLocations();
    res.json(locations);
}));

router.post('/locations', handleRequest(async (req, res) => {
    const { name, site, building, block, floor } = req.body;
    if (!name || !site || !building || !block || !floor) {
        return res.status(400).json({ message: 'Fields name, site, building, block, and floor are required' });
    }
    const newLocation = await db.addLocation(name, site, building, block, floor);
    res.status(201).json(newLocation);
}));

router.delete('/locations/:id', handleRequest(async (req, res) => {
    await db.deleteLocation(req.params.id);
    res.status(204).send();
}));

module.exports = router;