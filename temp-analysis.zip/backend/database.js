const { Pool } = require('pg');

const METRIC_COLUMNS = [ 'iaqi', 'pm25', 'co2', 'temp', 'humidity', 'voc', 'hcho', 'nox', 'pm03', 'pm1', 'pm5', 'pm10', 'pc03', 'pc05', 'pc1', 'pc25', 'pc5', 'pc10', 'smoke_vape_detected' ];

let pool;

const getPool = () => {
    if (!pool) {
        pool = new Pool({
            user: process.env.PGUSER,
            host: process.env.PGHOST,
            database: process.env.PGDATABASE,
            password: process.env.PGPASSWORD,
            port: process.env.PGPORT || 5432,
        });

        pool.on('error', (err, client) => {
            console.error('Unexpected error on idle PostgreSQL client', err);
            process.exit(-1);
        });
    }
    return pool;
};

const query = async (text, params) => {
    const start = Date.now();
    const res = await getPool().query(text, params);
    const duration = Date.now() - start;
    // console.log('executed query', { text, duration, rows: res.rowCount });
    return res;
};

const initDb = async () => {
    try {
        await query('SELECT NOW()'); // Test connection
    } catch (err) {
        console.error('CRITICAL: Failed to connect to PostgreSQL database.', err);
        throw err;
    }

    await query(`
        CREATE TABLE IF NOT EXISTS locations (
            id SERIAL PRIMARY KEY,
            name TEXT NOT NULL,
            site TEXT,
            building TEXT,
            block TEXT,
            floor TEXT
        )
    `);
    console.log("Table 'locations' is ready.");

    await query(`
        CREATE TABLE IF NOT EXISTS devices (
            id TEXT PRIMARY KEY,
            name TEXT,
            location_id INTEGER,
            type TEXT DEFAULT 'standard',
            FOREIGN KEY (location_id) REFERENCES locations (id) ON DELETE SET NULL
        )
    `);
    console.log("Table 'devices' is ready.");
    
    const readingsColumns = METRIC_COLUMNS.map(col => `${col} REAL`).join(', ');
    await query(`
        CREATE TABLE IF NOT EXISTS readings (
            id SERIAL PRIMARY KEY,
            device_id TEXT NOT NULL,
            timestamp TIMESTAMPTZ NOT NULL,
            ${readingsColumns},
            FOREIGN KEY (device_id) REFERENCES devices (id) ON DELETE CASCADE
        )
    `);
    await query('CREATE INDEX IF NOT EXISTS idx_readings_device_timestamp ON readings (device_id, timestamp DESC);');
    console.log("Table 'readings' and its index are ready.");
    
    // --- TimescaleDB Integration ---
    try {
        await query('CREATE EXTENSION IF NOT EXISTS timescaledb;');
        console.log("TimescaleDB extension is enabled.");

        const hypertableCheck = await query(`
            SELECT 1 FROM timescaledb_information.hypertables
            WHERE hypertable_schema = 'public' AND hypertable_name = 'readings'
        `);
        
        if (hypertableCheck.rowCount === 0) {
            await query("SELECT create_hypertable('readings', 'timestamp');");
            console.log("Successfully converted 'readings' table to a TimescaleDB hypertable.");
        } else {
            console.log("'readings' table is already a hypertable.");
        }
    } catch (err) {
        console.warn("Could not enable TimescaleDB hypertable for 'readings'. This is recommended for production performance but not required for basic functionality. Ensure the TimescaleDB extension is installed in your PostgreSQL instance. Error:", err.message);
    }
};

const ensureDeviceExists = async (deviceId) => {
    const res = await query('SELECT id FROM devices WHERE id = $1', [deviceId]);
    if (res.rowCount === 0) {
        await query('INSERT INTO devices (id, name) VALUES ($1, $2)', [deviceId, `Unassigned Sensor ${deviceId.slice(-4)}`]);
        console.log(`Auto-provisioned new device with ID: ${deviceId}`);
    }
};

const insertReading = async (deviceId, data) => {
    const columns = ['device_id', 'timestamp'];
    const values = [deviceId, data.timestamp || new Date().toISOString()];
    const valuePlaceholders = ['$1', '$2'];

    let placeholderIndex = 3;
    METRIC_COLUMNS.forEach(metric => {
        if (data[metric] !== undefined && data[metric] !== null) {
            columns.push(metric);
            values.push(data[metric]);
            valuePlaceholders.push(`$${placeholderIndex++}`);
        }
    });

    const sql = `INSERT INTO readings (${columns.join(', ')}) VALUES (${valuePlaceholders.join(', ')})`;
    await query(sql, values);
};

const mapRowToDeviceWithData = (row) => {
    if (!row) return null;
    const { id, name, type, location_id, location_name, location_site, location_building, location_block, location_floor, ...readingData } = row;
    
    // Cleanup extra properties from JOINs or subqueries
    delete readingData.rn;

    const latest_data = readingData.timestamp ? { deviceId: id, ...readingData } : null;
    
    return {
        id,
        name,
        type,
        location_id,
        location: {
            id: location_id,
            name: location_name,
            site: location_site,
            building: location_building,
            block: location_block,
            floor: location_floor,
        },
        latest_data,
    };
};

const getDeviceWithLatestData = async (deviceId) => {
    const sql = `
        SELECT
            d.id,
            d.name,
            d.type,
            d.location_id,
            l.name as location_name,
            l.site as location_site,
            l.building as location_building,
            l.block as location_block,
            l.floor as location_floor,
            r.timestamp,
            ${METRIC_COLUMNS.map(m => `r.${m}`).join(', ')}
        FROM devices d
        LEFT JOIN locations l ON d.location_id = l.id
        LEFT JOIN (
            SELECT * FROM readings
            WHERE device_id = $1
            ORDER BY timestamp DESC
            LIMIT 1
        ) r ON d.id = r.device_id
        WHERE d.id = $2
    `;
    const res = await query(sql, [deviceId, deviceId]);
    return mapRowToDeviceWithData(res.rows[0]);
};

const getAllDevicesWithLatestData = async () => {
    const sql = `
        WITH LatestReadings AS (
            SELECT
                *,
                ROW_NUMBER() OVER(PARTITION BY device_id ORDER BY timestamp DESC) as rn
            FROM readings
        )
        SELECT
            d.id,
            d.name,
            d.type,
            d.location_id,
            l.name as location_name,
            l.site as location_site,
            l.building as location_building,
            l.block as location_block,
            l.floor as location_floor,
            lr.timestamp,
            ${METRIC_COLUMNS.map(m => `lr.${m}`).join(', ')}
        FROM devices d
        LEFT JOIN locations l ON d.location_id = l.id
        LEFT JOIN LatestReadings lr ON d.id = lr.device_id AND lr.rn = 1
        ORDER BY d.name;
    `;
    const res = await query(sql);
    return res.rows.map(mapRowToDeviceWithData);
};

const getDevice = async (id) => {
    const res = await query(`
        SELECT 
            d.id, d.name, d.type, d.location_id, 
            l.id as loc_id, l.name as location_name, l.site, l.building, l.block, l.floor 
        FROM devices d 
        LEFT JOIN locations l ON d.location_id = l.id 
        WHERE d.id = $1`, [id]);
    
    if (res.rowCount === 0) return null;
    const row = res.rows[0];
    return {
        id: row.id, name: row.name, type: row.type, location_id: row.location_id,
        location: { id: row.loc_id, name: row.location_name, site: row.site, building: row.building, block: row.block, floor: row.floor }
    };
};

const addDevice = async (name, location_id, type = 'standard') => {
    const newId = `rosaiq-device-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    await query('INSERT INTO devices (id, name, location_id, type) VALUES ($1, $2, $3, $4)', [newId, name, location_id, type]);
    return getDeviceWithLatestData(newId);
};

const updateDevice = async (id, name, location_id) => {
    await query('UPDATE devices SET name = $1, location_id = $2 WHERE id = $3', [name, location_id, id]);
    return getDeviceWithLatestData(id);
};

const deleteDevice = (id) => query('DELETE FROM devices WHERE id = $1', [id]);
const getLocations = async () => (await query('SELECT * FROM locations ORDER BY name')).rows;

const addLocation = async (name, site, building, block, floor) => {
    const res = await query('INSERT INTO locations (name, site, building, block, floor) VALUES ($1, $2, $3, $4, $5) RETURNING *', [name, site, building, block, floor]);
    return res.rows[0];
};

const deleteLocation = (id) => query('DELETE FROM locations WHERE id = $1', [id]);

const getHistoricalData = async (deviceId, from, to, aggregation) => {
    let groupByClause, selectClause;
    switch (aggregation) {
        case '8h':
            selectClause = "time_bucket('8 hours', timestamp) as timestamp";
            break;
        case '1d':
            selectClause = "time_bucket('1 day', timestamp) as timestamp";
            break;
        case '1h':
        default:
            selectClause = "time_bucket('1 hour', timestamp) as timestamp";
            break;
    }

    const aggregatedMetrics = METRIC_COLUMNS.map(m => `AVG(${m}) as ${m}`).join(', ');
    const sql = `
        SELECT
            ${selectClause},
            ${aggregatedMetrics}
        FROM readings
        WHERE device_id = $1 AND timestamp >= $2 AND timestamp <= $3
        GROUP BY 1
        ORDER BY 1
    `;
    const res = await query(sql, [deviceId, from, to]);
    return res.rows.map(row => ({
        ...row,
        timestamp: row.timestamp.toISOString() // Ensure timestamp is ISO string
    }));
};

const seedDatabase = async () => {
    const res = await query('SELECT id FROM devices');
    if (res.rowCount === 0) {
        console.log('No existing data found. Seeding database with sample data...');
        try {
            const loc1 = await query("INSERT INTO locations (name, site, building, block, floor) VALUES ($1, $2, $3, $4, $5) RETURNING id", ["Floor 1 - Conference Wing", "Corporate HQ", "Building A", "West Wing", "Floor 1"]);
            const loc2 = await query("INSERT INTO locations (name, site, building, block, floor) VALUES ($1, $2, $3, $4, $5) RETURNING id", ["Floor 2 - Research Labs", "Corporate HQ", "Building A", "East Wing", "Floor 2"]);
            const loc3 = await query("INSERT INTO locations (name, site, building, block, floor) VALUES ($1, $2, $3, $4, $5) RETURNING id", ["Floor 1 - Mechanical Room", "Factory", "Building A", "Core", "Floor 1"]);
            const loc4 = await query("INSERT INTO locations (name, site, building, block, floor) VALUES ($1, $2, $3, $4, $5) RETURNING id", ["Floor 3 - Executive Suites", "Corporate HQ", "Building A", "West Wing", "Floor 3"]);
            
            await query("INSERT INTO devices (id, name, location_id, type) VALUES ($1, $2, $3, $4)", ['sim-device-01', 'Conf Room "Orion"', loc1.rows[0].id, 'standard']);
            await query("INSERT INTO devices (id, name, location_id, type) VALUES ($1, $2, $3, $4)", ['sim-device-02', 'Lab 2B - Fume Hood', loc2.rows[0].id, 'standard']);
            await query("INSERT INTO devices (id, name, location_id, type) VALUES ($1, $2, $3, $4)", ['sim-device-03', 'AHU-01 Supply Duct', loc3.rows[0].id, 'standard']);
            await query("INSERT INTO devices (id, name, location_id, type) VALUES ($1, $2, $3, $4)", ['sim-device-04', 'CEO Office', loc4.rows[0].id, 'standard']);
            await query("INSERT INTO devices (id, name, location_id, type) VALUES ($1, $2, $3, $4)", ['sim-device-11', 'Restroom - Floor 1', loc1.rows[0].id, 'vape-smoke']);

            
            console.log('Database seeded with 5 initial devices and 4 locations.');
        } catch (err) {
            console.error('Error seeding database:', err);
        }
    }
};

// Handle command-line initialization
if (require.main === module && process.argv.includes('--init')) {
    console.log("Running database initialization...");
    initDb()
        .then(() => {
            console.log("Database schema initialized successfully.");
            process.exit(0);
        })
        .catch(err => {
            console.error("Database initialization failed:", err);
            process.exit(1);
        });
}

module.exports = {
    initDb,
    seedDatabase,
    ensureDeviceExists,
    insertReading,
    getDeviceWithLatestData,
    getAllDevicesWithLatestData,
    getDevice,
    addDevice,
    updateDevice,
    deleteDevice,
    getLocations,
    addLocation,
    deleteLocation,
    getHistoricalData
};