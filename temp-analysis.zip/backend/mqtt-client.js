
const fs = require('fs');
const path = require('path');
const mqtt = require('mqtt');
const db = require('./database');
const { broadcast } = require('./websocket');
const { calculateIaqi } = require('./utils/aqiCalculator');

// --- Configuration ---
const MQTT_BROKER_URL = process.env.MQTT_BROKER_URL || 'mqtt://localhost:1883';
const MQTT_USER = process.env.MQTT_USER;
const MQTT_PASSWORD = process.env.MQTT_PASSWORD;

// --- TLS Configuration ---
const useTls = MQTT_BROKER_URL.startsWith('mqtts');
const certsPath = path.join(__dirname, 'certs/ca.crt');
let TLS_OPTIONS = {};

if (useTls) {
  try {
    if (fs.existsSync(certsPath)) {
      TLS_OPTIONS = {
        ca: [fs.readFileSync(certsPath)],
        rejectUnauthorized: true,
      };
      console.log('TLS is enabled for MQTT connection.');
    } else {
      console.warn('TLS connection requested, but ca.crt not found at', certsPath);
    }
  } catch (error) {
    console.error('Error reading CA certificate for TLS:', error);
  }
}

let client;

// This function contains the core logic for processing incoming data,
// whether it's from MQTT or a direct simulator call.
const processDirectData = async (deviceId, data) => {
  try {
    await db.ensureDeviceExists(deviceId);
    data.iaqi = calculateIaqi(data);
    await db.insertReading(deviceId, data);
    const fullDeviceData = await db.getDeviceWithLatestData(deviceId);
    if (fullDeviceData) {
      broadcast(fullDeviceData);
    }
  } catch (error) {
    console.error(`Error processing data for device ${deviceId}:`, error);
  }
};


const connectMqtt = () => {
  const options = {
    ...TLS_OPTIONS,
    username: MQTT_USER,
    password: MQTT_PASSWORD,
    connectTimeout: 5000,
    reconnectPeriod: 5000,
  };

  console.log(`Attempting to connect to MQTT broker at ${MQTT_BROKER_URL}...`);
  client = mqtt.connect(MQTT_BROKER_URL, options);

  client.on('connect', () => {
    console.log('Successfully connected to MQTT broker.');
    client.subscribe('devices/+/data', (err) => {
      if (err) {
        console.error('MQTT subscription failed:', err);
      } else {
        console.log('Subscribed to topic: devices/+/data');
      }
    });
  });

  client.on('message', async (topic, message) => {
    const deviceId = topic.split('/')[1];
    const data = JSON.parse(message.toString());
    await processDirectData(deviceId, data);
  });

  client.on('reconnect', () => {
    console.log('MQTT client attempting to reconnect...');
  });

  client.on('error', (err) => {
    console.error('MQTT client error:', err.message);
  });

  client.on('close', () => {
    console.log('MQTT connection closed. The client will attempt to reconnect if configured.');
  });
};

const getMqttClient = () => {
  return client;
};

module.exports = { connectMqtt, getMqttClient, processDirectData };