
const express = require('express');
const cors = require('cors');
const http = require('http');
const path = require('path');
const apiRouter = require('./api-router');
const { initDb, seedDatabase } = require('./database');
const { connectMqtt, processDirectData } = require('./mqtt-client');
const { initWebSocketServer } = require('./websocket');
const { startSimulator } = require('./simulator');

const app = express();
const PORT = process.env.PORT || 3001;

// --- Middleware ---
app.use(cors()); 
app.use(express.json());

// --- API Routes ---
app.use(apiRouter);

// --- Serve Static Frontend Assets ---
if (process.env.NODE_ENV === 'production') {
  const buildPath = path.join(__dirname, '..', 'dist');
  app.use(express.static(buildPath));
  app.get('*', (req, res) => {
    res.sendFile(path.join(buildPath, 'index.html'));
  });
}

// --- Create HTTP server and initialize WebSocket server ---
const server = http.createServer(app);
initWebSocketServer(server);


// --- Server Initialization ---
const startServer = async () => {
  try {
    // Set up the database. The initDb function connects and checks tables.
    await initDb();
    console.log('Database connected and tables verified.');
    await seedDatabase();

    // Start the Express server with WebSocket support
    server.listen(PORT, () => {
      console.log(`🚀 Server is running on http://localhost:${PORT}`);
    });

    // --- Start MQTT Client ---
    // Connect to the MQTT broker to receive live sensor data.
    connectMqtt();

    // --- Start Data Simulator for Development/Demo ---
    if (process.env.NODE_ENV !== 'production') {
      console.log('[SIMULATOR] Starting data simulator for development...');
      startSimulator(processDirectData);
    }

  } catch (error) {
    console.error('❌ Failed to start server:', error);
    process.exit(1);
  }
};

startServer();