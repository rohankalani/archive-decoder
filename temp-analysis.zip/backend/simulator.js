// --- LoRaWAN Network Server (LNS) Simulator ---
// This script simulates a Milesight UG65 gateway's built-in network server.
// It generates realistic sensor data and passes it to a handler function.

const PUBLISH_INTERVAL = 5000; // 5 seconds

const DEVICE_PROFILES = {
    'sim-device-01': {
        name: 'Conf Room "Orion"',
        state: { co2: 500, temp: 21.5, humidity: 45, voc: 75, pm25: 8, occupancy: 0 },
        update: (s) => {
            const hour = new Date().getHours();
            const isMeetingTime = (hour >= 9 && hour < 12) || (hour >= 14 && hour < 17);
            
            if (isMeetingTime) {
                s.co2 += getRandom(20, 50);
                s.occupancy = Math.min(s.occupancy + 1, 10);
            } else {
                s.co2 -= getRandom(10, 30);
                s.occupancy = Math.max(s.occupancy - 2, 0);
            }
            s.co2 = clamp(s.co2, 400, 1500);
            s.voc = s.co2 > 1000 ? getRandom(150, 250) : getRandom(50, 100);
            s.temp += (s.occupancy > 0 ? 0.1 : -0.1) + getRandom(-0.2, 0.2);
            s.pm25 += getRandom(-0.5, 0.5);
        }
    },
    'sim-device-02': {
        name: 'Lab 2B - Fume Hood',
        state: { co2: 600, temp: 22.0, humidity: 50, voc: 250, pm25: 18 },
        update: (s) => {
            s.co2 += getRandom(-20, 20);
            s.voc += getRandom(-15, 15);
            s.pm25 += getRandom(-2, 2);
            s.voc = clamp(s.voc, 200, 400);
            s.pm25 = clamp(s.pm25, 15, 35);
        }
    },
    'sim-device-03': {
        name: 'AHU-01 Supply Duct',
        state: { co2: 410, temp: 18.0, humidity: 55, voc: 20, pm25: 2 },
        update: (s) => {
             s.co2 += getRandom(-5, 5);
             s.temp += getRandom(-0.1, 0.1);
             s.pm25 += getRandom(-0.1, 0.2);
             s.co2 = clamp(s.co2, 400, 450);
             s.pm25 = clamp(s.pm25, 1, 5);
        }
    },
    'default': {
        state: { co2: 450, temp: 22.5, humidity: 48, voc: 60, pm25: 10 },
        update: (s) => {
            s.co2 += getRandom(-10, 10);
            s.temp += getRandom(-0.2, 0.2);
            s.humidity += getRandom(-1, 1);
            s.voc += getRandom(-5, 5);
            s.pm25 += getRandom(-1, 1);
        }
    }
};

const otherDeviceIds = [
    'sim-device-04', 'sim-device-05', 'sim-device-06', 'sim-device-07', 
    'sim-device-08', 'sim-device-09', 'sim-device-10'
];
otherDeviceIds.forEach(id => {
    DEVICE_PROFILES[id] = {
        name: `Generic Sensor ${id.slice(-2)}`,
        state: { ...DEVICE_PROFILES.default.state },
        update: DEVICE_PROFILES.default.update
    };
});

const clamp = (value, min, max) => Math.max(min, Math.min(value, max));
const getRandom = (min, max, decimals = 1) => parseFloat((Math.random() * (max - min) + min).toFixed(decimals));

const generateData = (deviceId, profile, dataHandler) => {
    if (!dataHandler) return;

    // 1. Update state based on profile logic
    profile.update(profile.state);

    // 2. Generate other random metrics and clamp all values
    const s = profile.state;
    const payload = {
      co2: clamp(s.co2, 400, 5000),
      temp: clamp(s.temp, 15, 35),
      humidity: clamp(s.humidity, 20, 80),
      voc: clamp(s.voc, 10, 1000),
      pm25: clamp(s.pm25, 0, 500),
      occupancy: s.occupancy,
      hcho: getRandom(10, 100),
      nox: getRandom(10, 150),
      pm10: clamp(s.pm25 * 1.5 + getRandom(-5, 5), 0, 600),
      timestamp: new Date().toISOString(),
      smoke_vape_detected: Math.random() > 0.99 ? 1 : 0, // 1% chance
    };

    // 3. Pass the data to the handler function
    dataHandler(deviceId, payload);
};

const startSimulator = (dataHandler) => {
    const deviceIds = Object.keys(DEVICE_PROFILES).filter(k => k !== 'default');
    console.log(`[LNS SIMULATOR] Starting data simulation for ${deviceIds.length} devices.`);
    console.log(`[LNS SIMULATOR] Pushing new data every ${PUBLISH_INTERVAL / 1000} seconds.`);

    deviceIds.forEach(deviceId => {
        const profile = DEVICE_PROFILES[deviceId];
        generateData(deviceId, profile, dataHandler); // Initial push
        setInterval(() => generateData(deviceId, profile, dataHandler), PUBLISH_INTERVAL);
    });
};

module.exports = { startSimulator };