// This utility calculates a composite Indoor Air Quality Index (IAQI)
// based on the ROSAIQ Air Quality Parameters standard.
// The final IAQI is the highest (worst) of the individual pollutant sub-indices.

// Breakpoint structure: [Concentration Low, Concentration High, AQI Low, AQI High]
type Breakpoint = [number, number, number, number];
type BreakpointTable = Breakpoint[];

const ROSAIQ_BREAKPOINTS = {
  pm25: [
    [0.0, 50.4, 0, 50],
    [50.5, 60.4, 51, 100],
    [60.5, 75.4, 101, 150],
    [75.5, 150.4, 151, 200],
    [150.5, 250.4, 201, 300],
    [250.5, 500.4, 301, 500],
  ],
  pm10: [
    [0.0, 75.0, 0, 50],
    [75.1, 150.0, 51, 100],
    [150.1, 250.0, 101, 150],
    [250.1, 350.0, 151, 200],
    [350.1, 420.0, 201, 300],
    [420.1, 600.0, 301, 500],
  ],
  hcho: [
    [0.0, 30.0, 0, 50],
    [30.1, 80.0, 51, 100],
    [80.1, 120.0, 101, 150],
    [120.1, 200.0, 151, 200],
    [200.1, 300.0, 201, 300],
    [300.1, 500.0, 301, 500],
  ],
  voc: [ // As per ROSAIQ Index
    [0.0, 100.0, 0, 50],
    [100.1, 200.0, 51, 100],
    [200.1, 300.0, 101, 150],
    [300.1, 400.0, 151, 200],
    [400.1, 450.0, 201, 300],
    [450.1, 500.0, 301, 500],
  ],
  nox: [ // As per ROSAIQ Index
    [0.0, 100.0, 0, 50],
    [100.1, 200.0, 51, 100],
    [200.1, 300.0, 101, 150],
    [300.1, 400.0, 151, 200],
    [400.1, 450.0, 201, 300],
    [450.1, 500.0, 301, 500],
  ],
};

const AQI_POLLUTANTS = ['pm25', 'pm10', 'hcho', 'voc', 'nox'];

const calculateSubIndex = (metric, value) => {
    if (value === undefined || value === null || isNaN(value)) return 0;

    const table = ROSAIQ_BREAKPOINTS[metric];
    if (!table || table.length === 0) return 0;

    // Round the value to one decimal place to match the precision of the breakpoint table.
    // This prevents floating point gaps (e.g., 50.45).
    const roundedValue = parseFloat(value.toFixed(1));

    const breakpoint = table.find(b => roundedValue >= b[0] && roundedValue <= b[1]);
    if (!breakpoint) {
      if (roundedValue > table[table.length - 1][1]) return table[table.length - 1][3];
      return 0;
    }

    const [c_lo, c_hi, i_lo, i_hi] = breakpoint;
    if (c_hi - c_lo === 0) return i_lo; 

    const aqi = ((i_hi - i_lo) / (c_hi - c_lo)) * (roundedValue - c_lo) + i_lo;
    return Math.round(aqi);
};

const calculateIaqi = (data) => {
    let maxAqi = 0;

    AQI_POLLUTANTS.forEach(metric => {
        const value = data[metric];
        const aqi = calculateSubIndex(metric, value);
        if (aqi > maxAqi) {
            maxAqi = aqi;
        }
    });
    
    return maxAqi;
};

module.exports = { calculateIaqi };