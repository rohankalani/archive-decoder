const { WebSocketServer, WebSocket } = require('ws');

let wss;

const initWebSocketServer = (server) => {
  // Listen on the main server path to simplify proxying.
  wss = new WebSocketServer({ server });

  wss.on('connection', (ws) => {
    console.log('Client connected to WebSocket.');
    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
    });
    ws.on('error', (error) => {
      console.error('WebSocket client connection error:', error);
    });
  });

  // Add a server-level error handler to catch issues with the server itself.
  wss.on('error', (error) => {
    console.error('WebSocket Server error:', error);
  });

  console.log('WebSocket server initialized.');
  return wss;
};

const broadcast = (data) => {
  if (!wss) {
    console.error('WebSocket server not initialized. Cannot broadcast.');
    return;
  }

  const message = JSON.stringify(data);
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message, (err) => {
        if (err) {
          console.error('Error sending message to client:', err);
        }
      });
    }
  });
};

module.exports = { initWebSocketServer, broadcast };