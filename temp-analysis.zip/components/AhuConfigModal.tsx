import React, { useState, useEffect } from 'react';
import { X, Loader2, Plus, Trash2 } from 'lucide-react';
import { AhuReport, FilterStage, FilterType, FilterGrade, ParticleSize, RosaiqAhsMonitor } from '../types';

interface AhuConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: {
    name: string;
    totalDpChangeThreshold: number;
    airflowRate: number;
    fanEfficiency: number;
    filterStages: FilterStage[];
    rosaiqMonitor: RosaiqAhsMonitor;
  }) => Promise<void>;
  ahu: AhuReport | null; // null for adding, AhuReport object for editing
}

const initialFilterStage: FilterStage = { 
    id: `new_${Date.now()}`, name: 'Final Filter', type: 'V-Cell', grade: 'MERV 13', 
    initialDp: 60, cost: 150, lifespanDays: 365,
    standardFilterInitialDp: 80, standardFilterFinalDp: 250, standardFilterLifespanDays: 180, standardFilterCost: 90,
};

const AhuConfigModal: React.FC<AhuConfigModalProps> = ({ isOpen, onClose, onSave, ahu }) => {
  const [name, setName] = useState('');
  const [totalDpChangeThreshold, setTotalDpChangeThreshold] = useState(250);
  const [airflowRate, setAirflowRate] = useState(2000);
  const [fanEfficiency, setFanEfficiency] = useState(65);
  const [filterStages, setFilterStages] = useState<FilterStage[]>([initialFilterStage]);
  const [rosaiqMonitor, setRosaiqMonitor] = useState<RosaiqAhsMonitor>({ id: 'rosaiq-mon-new', targetParticleSize: 'pm1' });
  
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (ahu) {
      setName(ahu.name);
      setTotalDpChangeThreshold(ahu.totalDpChangeThreshold);
      setAirflowRate(ahu.airflowRate);
      setFanEfficiency(ahu.fanEfficiency);
      setFilterStages(ahu.filterStages);
      setRosaiqMonitor(ahu.rosaiqMonitor);
    } else {
      // Reset for "Add" mode
      setName('');
      setTotalDpChangeThreshold(250);
      setAirflowRate(2000);
      setFanEfficiency(65);
      setFilterStages([initialFilterStage]);
      setRosaiqMonitor({ id: `rosaiq-mon-${Date.now()}`, targetParticleSize: 'pm1' });
    }
  }, [ahu, isOpen]);

  const handleStageChange = (index: number, field: keyof FilterStage, value: string | number) => {
    const newStages = [...filterStages];
    (newStages[index] as any)[field] = value;
    setFilterStages(newStages);
  };
  
  const addFilterStage = () => {
    setFilterStages([...filterStages, { ...initialFilterStage, id: `new_${Date.now()}`, name: 'Pre-Filter', grade: 'MERV 8', initialDp: 25, cost: 30, lifespanDays: 90, standardFilterInitialDp: 35, standardFilterFinalDp: 150, standardFilterLifespanDays: 60, standardFilterCost: 20 }]);
  };

  const removeFilterStage = (index: number) => {
    setFilterStages(filterStages.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || totalDpChangeThreshold <= 0 || airflowRate <= 0 || fanEfficiency <= 0 || filterStages.some(s => !s.name || s.cost < 0 || s.initialDp <= 0 || s.lifespanDays <= 0)) {
      alert("Please provide valid inputs for all fields.");
      return;
    }
    setIsSubmitting(true);
    await onSave({ name, totalDpChangeThreshold, airflowRate, fanEfficiency, filterStages, rosaiqMonitor });
    setIsSubmitting(false);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4">
      <div className="bg-secondary rounded-lg shadow-xl w-full max-w-3xl animate-fade-in-scale" onClick={e => e.stopPropagation()}>
        <form onSubmit={handleSubmit}>
          <div className="p-5 border-b border-slate-700 flex justify-between items-center">
            <h2 className="text-xl font-bold text-white">{ahu ? 'Edit AHU Configuration' : 'Add New AHU'}</h2>
            <button type="button" onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
              <X className="w-6 h-6" />
            </button>
          </div>
          <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
            {/* --- General Info --- */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="ahu-name" className="block text-sm font-medium text-slate-300 mb-1">AHU Name</label>
                <input id="ahu-name" type="text" value={name} onChange={e => setName(e.target.value)} required className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" placeholder="e.g., Rooftop Unit 1"/>
              </div>
              <div>
                <label htmlFor="ahu-threshold" className="block text-sm font-medium text-slate-300 mb-1">Total DP Change Threshold (Pa)</label>
                <input id="ahu-threshold" type="number" value={totalDpChangeThreshold} onChange={e => setTotalDpChangeThreshold(Number(e.target.value))} required className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" placeholder="e.g., 250"/>
              </div>
               <div>
                <label htmlFor="ahu-airflow" className="block text-sm font-medium text-slate-300 mb-1">Airflow Rate (CFM)</label>
                <input id="ahu-airflow" type="number" value={airflowRate} onChange={e => setAirflowRate(Number(e.target.value))} required className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" placeholder="e.g., 2000"/>
              </div>
               <div>
                <label htmlFor="ahu-efficiency" className="block text-sm font-medium text-slate-300 mb-1">Fan Efficiency (%)</label>
                <input id="ahu-efficiency" type="number" value={fanEfficiency} onChange={e => setFanEfficiency(Number(e.target.value))} required className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" placeholder="e.g., 65"/>
              </div>
            </div>
             <div>
                <label htmlFor="particle-size" className="block text-sm font-medium text-slate-300 mb-1">RosaiQ™ Target Particle Size</label>
                <select id="particle-size" value={rosaiqMonitor.targetParticleSize} onChange={e => setRosaiqMonitor(r => ({...r, targetParticleSize: e.target.value as ParticleSize}))} className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white">
                    <option value="pm05">PM 0.5</option>
                    <option value="pm1">PM 1.0</option>
                    <option value="pm25">PM 2.5</option>
                </select>
            </div>

            {/* --- Filter Stages --- */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Filter Stages</h3>
              <div className="space-y-4">
                {filterStages.map((stage, index) => (
                  <div key={stage.id} className="bg-tertiary p-4 rounded-lg border border-slate-700 relative">
                    {filterStages.length > 1 && <button type="button" onClick={() => removeFilterStage(index)} className="absolute top-2 right-2 p-1 text-slate-500 hover:text-red-400"><Trash2 size={16}/></button>}
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                        {/* Advanced Filter Side */}
                        <div className="space-y-3">
                            <h4 className="font-semibold text-cyan-400 border-b border-cyan-800 pb-1">Advanced Filter Stage #{index + 1}</h4>
                            <div><label className="text-xs text-slate-400">Stage Name</label><input type="text" value={stage.name} onChange={e => handleStageChange(index, 'name', e.target.value)} className="w-full bg-slate-800 border-slate-600 rounded p-1.5 text-sm"/></div>
                            <div className="grid grid-cols-2 gap-2">
                                <div><label className="text-xs text-slate-400">Type</label><select value={stage.type} onChange={e => handleStageChange(index, 'type', e.target.value)} className="w-full bg-slate-800 border-slate-600 rounded p-1.5 text-sm"><option>Panel</option><option>Bag</option><option>V-Cell</option></select></div>
                                <div><label className="text-xs text-slate-400">Grade</label><select value={stage.grade} onChange={e => handleStageChange(index, 'grade', e.target.value)} className="w-full bg-slate-800 border-slate-600 rounded p-1.5 text-sm"><option>MERV 8</option><option>MERV 13</option><option>F7</option><option>F8</option><option>HEPA 13</option><option>Custom</option></select></div>
                            </div>
                            <div className="grid grid-cols-3 gap-2">
                                <div><label className="text-xs text-slate-400">Initial DP (Pa)</label><input type="number" value={stage.initialDp} onChange={e => handleStageChange(index, 'initialDp', Number(e.target.value))} className="w-full bg-slate-800 border-slate-600 rounded p-1.5 text-sm"/></div>
                                <div><label className="text-xs text-slate-400">Cost ($)</label><input type="number" value={stage.cost} onChange={e => handleStageChange(index, 'cost', Number(e.target.value))} className="w-full bg-slate-800 border-slate-600 rounded p-1.5 text-sm"/></div>
                                <div><label className="text-xs text-slate-400">Lifespan (days)</label><input type="number" value={stage.lifespanDays} onChange={e => handleStageChange(index, 'lifespanDays', Number(e.target.value))} className="w-full bg-slate-800 border-slate-600 rounded p-1.5 text-sm"/></div>
                            </div>
                        </div>
                        {/* Standard Baseline Side */}
                        <div className="space-y-3 md:border-l md:border-slate-600/50 md:pl-6">
                            <h4 className="font-semibold text-slate-400 border-b border-slate-600 pb-1">Standard Filter Baseline</h4>
                             <div className="grid grid-cols-2 gap-2">
                                <div><label className="text-xs text-slate-400">Initial DP (Pa)</label><input type="number" value={stage.standardFilterInitialDp} onChange={e => handleStageChange(index, 'standardFilterInitialDp', Number(e.target.value))} className="w-full bg-slate-800 border-slate-600 rounded p-1.5 text-sm"/></div>
                                <div><label className="text-xs text-slate-400">Final DP (Pa)</label><input type="number" value={stage.standardFilterFinalDp} onChange={e => handleStageChange(index, 'standardFilterFinalDp', Number(e.target.value))} className="w-full bg-slate-800 border-slate-600 rounded p-1.5 text-sm"/></div>
                            </div>
                            <div className="grid grid-cols-2 gap-2">
                                <div><label className="text-xs text-slate-400">Cost ($)</label><input type="number" value={stage.standardFilterCost} onChange={e => handleStageChange(index, 'standardFilterCost', Number(e.target.value))} className="w-full bg-slate-800 border-slate-600 rounded p-1.5 text-sm"/></div>
                                <div><label className="text-xs text-slate-400">Lifespan (days)</label><input type="number" value={stage.standardFilterLifespanDays} onChange={e => handleStageChange(index, 'standardFilterLifespanDays', Number(e.target.value))} className="w-full bg-slate-800 border-slate-600 rounded p-1.5 text-sm"/></div>
                            </div>
                        </div>
                    </div>
                  </div>
                ))}
                <button type="button" onClick={addFilterStage} className="w-full text-sm flex items-center justify-center gap-2 p-2 bg-tertiary hover:bg-slate-700 rounded-md border border-dashed border-slate-600">
                  <Plus size={16}/> Add Filter Stage
                </button>
              </div>
            </div>
            
          </div>
          <div className="p-5 border-t border-slate-700 flex justify-end gap-3">
            <button type="button" onClick={onClose} className="px-4 py-2 rounded-md text-white bg-slate-600 hover:bg-slate-500 transition-colors">
              Cancel
            </button>
            <button type="submit" disabled={isSubmitting} className="px-4 py-2 rounded-md text-white bg-accent hover:bg-accent-dark disabled:bg-slate-500 flex items-center gap-2">
              {isSubmitting && <Loader2 className="w-4 h-4 animate-spin" />}
              {ahu ? 'Save Changes' : 'Add AHU'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AhuConfigModal;