import React from 'react';
import { ComposedChart, Area, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { format } from 'date-fns';

interface AhuCostAnalysisChartProps {
    data: { 
        timestamp: string; 
        cumulativeCost: number;
        cumulativeCostStandard: number;
        cumulativeEnergyCost: number;
        cumulativeEnergyCostStandard: number;
        cumulativeFilterCost: number;
        cumulativeFilterCostStandard: number;
    }[];
}

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
        const rosaiqData = payload.find(p => p.dataKey === 'cumulativeCost');
        const standardData = payload.find(p => p.dataKey === 'cumulativeCostStandard');

        return (
            <div className="bg-primary/80 backdrop-blur-sm p-3 rounded-md border border-slate-700 space-y-2 text-sm">
                <p className="font-semibold text-slate-300">{format(new Date(label), 'd MMM yyyy')}</p>
                <div className="border-t border-slate-700 my-1"></div>
                {rosaiqData && (
                    <div>
                        <p className="font-bold" style={{ color: rosaiqData.stroke }}>RosaiQ™ TCO</p>
                        <p className="text-slate-400 pl-2">Total: ${rosaiqData.payload.cumulativeCost.toFixed(2)}</p>
                        <p className="text-slate-400 pl-2">Energy: ${rosaiqData.payload.cumulativeEnergyCost.toFixed(2)}</p>
                        <p className="text-slate-400 pl-2">Filters: ${rosaiqData.payload.cumulativeFilterCost.toFixed(2)}</p>
                    </div>
                )}
                 {standardData && (
                    <div>
                        <p className="font-bold" style={{ color: standardData.stroke }}>Standard TCO</p>
                        <p className="text-slate-400 pl-2">Total: ${standardData.payload.cumulativeCostStandard.toFixed(2)}</p>
                        <p className="text-slate-400 pl-2">Energy: ${standardData.payload.cumulativeEnergyCostStandard.toFixed(2)}</p>
                        <p className="text-slate-400 pl-2">Filters: ${standardData.payload.cumulativeFilterCostStandard.toFixed(2)}</p>
                    </div>
                )}
            </div>
        );
    }
    return null;
};

const AhuCostAnalysisChart: React.FC<AhuCostAnalysisChartProps> = ({ data }) => {
    return (
        <div className="h-48">
             <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={data} margin={{ top: 5, right: 5, left: -25, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#475569" strokeOpacity={0.5} />
                    <XAxis 
                        dataKey="timestamp" 
                        stroke="#94a3b8" 
                        tick={{ fontSize: 10 }}
                        tickFormatter={(ts) => format(new Date(ts), 'MMM')}
                        interval="preserveStartEnd"
                    />
                    <YAxis stroke="#94a3b8" tick={{ fontSize: 10 }} unit="$" />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend iconSize={8} wrapperStyle={{fontSize: "10px", paddingTop: '10px'}}/>
                    
                    <defs>
                        <linearGradient id="rosaiqGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#6ee7b7" stopOpacity={0.4}/>
                            <stop offset="95%" stopColor="#6ee7b7" stopOpacity={0}/>
                        </linearGradient>
                         <linearGradient id="standardGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#2dd4bf" stopOpacity={0.4}/>
                            <stop offset="95%" stopColor="#2dd4bf" stopOpacity={0}/>
                        </linearGradient>
                    </defs>

                    {/* Energy Cost Areas */}
                    <Area type="monotone" dataKey="cumulativeEnergyCost" name="RosaiQ™ Energy Cost" stroke="transparent" fill="url(#rosaiqGradient)" />
                    <Area type="monotone" dataKey="cumulativeEnergyCostStandard" name="Standard Energy Cost" stroke="transparent" fill="url(#standardGradient)" />
                    
                    {/* Total Cost Lines */}
                    <Line type="monotone" dataKey="cumulativeCost" name="RosaiQ™ TCO" stroke="#6ee7b7" strokeWidth={2.5} dot={false} activeDot={{ r: 4 }} />
                    <Line type="monotone" dataKey="cumulativeCostStandard" name="Standard TCO" stroke="#2dd4bf" strokeWidth={2.5} dot={false} activeDot={{ r: 4 }} />
                </ComposedChart>
            </ResponsiveContainer>
        </div>
    );
};

export default AhuCostAnalysisChart;