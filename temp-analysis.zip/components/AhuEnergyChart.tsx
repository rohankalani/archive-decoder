import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { format } from 'date-fns';

interface AhuEnergyChartProps {
    data: { timestamp: string; dailyEnergyCost: number; dailyEnergyCostStandard: number }[];
}

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
        return (
            <div className="bg-primary/80 backdrop-blur-sm p-3 rounded-md border border-slate-700 space-y-1 text-sm">
                <p className="font-semibold text-slate-300">{format(new Date(label), 'd MMM yyyy')}</p>
                 <p style={{ color: payload[0].fill }}>RosaiQ™ Cost: ${payload[0].value.toFixed(2)}</p>
                 <p style={{ color: payload[1].fill }}>Standard Cost: ${payload[1].value.toFixed(2)}</p>
            </div>
        );
    }
    return null;
};


const AhuEnergyChart: React.FC<AhuEnergyChartProps> = ({ data }) => {
    return (
        <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data} margin={{ top: 5, right: 5, left: -25, bottom: 5 }} barGap={0}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#475569" strokeOpacity={0.5} />
                    <XAxis 
                        dataKey="timestamp" 
                        stroke="#94a3b8" 
                        tick={{ fontSize: 10 }}
                        tickFormatter={(ts) => format(new Date(ts), 'MMM')}
                        interval="preserveStartEnd"
                    />
                    <YAxis stroke="#94a3b8" tick={{ fontSize: 10 }} unit="$" />
                    <Tooltip content={<CustomTooltip />} cursor={{fill: 'rgba(100, 116, 139, 0.1)'}} />
                    <Legend iconSize={8} wrapperStyle={{fontSize: "10px", paddingTop: '10px'}}/>
                    <Bar dataKey="dailyEnergyCost" name="RosaiQ™ Cost" fill="#6ee7b7" radius={[2, 2, 0, 0]} barSize={10}/>
                    <Bar dataKey="dailyEnergyCostStandard" name="Standard Cost" fill="#2dd4bf" radius={[2, 2, 0, 0]} barSize={10} />
                </BarChart>
            </ResponsiveContainer>
        </div>
    );
};

export default AhuEnergyChart;