import React from 'react';
import { DeviceWithData, PurifierMode } from '../types';
import { Wind, Power, Filter, Zap, SlidersHorizontal, Thermometer, Droplets, User } from 'lucide-react';

interface AirPurifierCardProps {
    purifier: DeviceWithData;
}

type PurifierStatus = 'Idle' | 'Purifying' | 'Offline';

const getStatus = (purifier: DeviceWithData): PurifierStatus => {
    if (purifier.status === 'offline') return 'Offline';
    if ((purifier.latest_data?.fan_speed ?? 0) > 0) return 'Purifying';
    return 'Idle';
};

const statusConfig: Record<PurifierStatus, { color: string, icon: React.ReactNode }> = {
    'Idle': { color: 'border-green-500/50', icon: <Wind className="w-8 h-8 text-green-400" /> },
    'Purifying': { color: 'border-cyan-500', icon: <Wind className="w-8 h-8 text-cyan-400 animate-spin-slow" /> },
    'Offline': { color: 'border-slate-600', icon: <Wind className="w-8 h-8 text-slate-500" /> },
};

const modeConfig: Record<PurifierMode, { label: string, icon: React.ReactNode }> = {
    'auto': { label: 'Auto', icon: <Zap size={14} /> },
    'manual': { label: 'Manual', icon: <SlidersHorizontal size={14} /> },
    'off': { label: 'Off', icon: <Power size={14} /> },
};

const AirPurifierCard: React.FC<AirPurifierCardProps> = ({ purifier }) => {
    const status = getStatus(purifier);
    const config = statusConfig[status];
    const data = purifier.latest_data;
    const mode = data?.mode ?? 'off';

    const fanSpeed = data?.fan_speed ?? 0;
    const filterLife = data?.filter_life ?? 0;

    return (
        <div className={`bg-secondary p-5 rounded-lg border-2 ${config.color} transition-all flex flex-col`}>
            <div className="flex justify-between items-start">
                <div>
                    <h3 className="text-lg font-bold text-white">{purifier.name}</h3>
                    <p className="text-sm text-slate-400">{purifier.location.name}</p>
                </div>
                {config.icon}
            </div>
            
            <div className="mt-4">
                <p className="text-2xl font-bold text-white">{status}</p>
                 <div className="flex items-center gap-2 mt-1 text-sm text-slate-300">
                    {modeConfig[mode].icon}
                    <span>Mode: {modeConfig[mode].label}</span>
                </div>
            </div>

            <div className="space-y-4 mt-6 flex-grow">
                <div>
                    <div className="flex justify-between items-baseline text-xs text-slate-400 mb-1">
                        <span>Fan Speed</span>
                        <span className="font-semibold text-white">{fanSpeed.toFixed(0)}%</span>
                    </div>
                    <div className="w-full bg-slate-700 rounded-full h-2.5">
                        <div className="bg-cyan-500 h-2.5 rounded-full" style={{ width: `${fanSpeed}%` }}></div>
                    </div>
                </div>
                <div>
                    <div className="flex justify-between items-baseline text-xs text-slate-400 mb-1">
                        <span>Filter Life</span>
                        <span className="font-semibold text-white">{filterLife.toFixed(1)}%</span>
                    </div>
                    <div className="w-full bg-slate-700 rounded-full h-2.5">
                        <div className="bg-green-500 h-2.5 rounded-full" style={{ width: `${filterLife}%` }}></div>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-left mt-6 border-t border-slate-700 pt-4 text-xs">
                <div className="flex items-center gap-2">
                    <Filter className="w-4 h-4 text-slate-500"/>
                    <div>
                        <p className="text-slate-400">PM2.5</p>
                        <p className="font-bold text-white">{data?.pm25?.toFixed(1) ?? '--'} µg/m³</p>
                    </div>
                </div>
                 <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-slate-500"/>
                    <div>
                        <p className="text-slate-400">Occupancy</p>
                        <p className="font-bold text-white">{data?.occupancy?.toFixed(0) ?? '--'}</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AirPurifierCard;