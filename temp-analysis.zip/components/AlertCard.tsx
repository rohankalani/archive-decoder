import React from 'react';
// FIX: Corrected import path for types.
import { Alert, AlertSeverity } from '../types';
import { AlertTriangle, XCircle, Info, CheckCircle } from 'lucide-react';

interface AlertCardProps {
  alert: Alert;
  onAcknowledge: (alertId: string) => void;
}

const severityConfig: Record<AlertSeverity, { icon: React.ReactNode, color: string }> = {
  critical: { icon: <XCircle className="w-8 h-8" />, color: '#ef4444' }, // red-500
  warning: { icon: <AlertTriangle className="w-8 h-8" />, color: '#facc15' }, // yellow-400
  info: { icon: <Info className="w-8 h-8" />, color: '#38bdf8' }, // sky-400
};

const TimeAgo: React.FC<{ timestamp: string }> = ({ timestamp }) => {
    const calculateTimeAgo = (date: Date): string => {
        const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
        let interval = seconds / 31536000;
        if (interval > 1) return Math.floor(interval) + " years ago";
        interval = seconds / 2592000;
        if (interval > 1) return Math.floor(interval) + " months ago";
        interval = seconds / 86400;
        if (interval > 1) return Math.floor(interval) + " days ago";
        interval = seconds / 3600;
        if (interval > 1) return Math.floor(interval) + " hours ago";
        interval = seconds / 60;
        if (interval > 1) return Math.floor(interval) + " minutes ago";
        if (seconds < 5) return "just now";
        return Math.floor(seconds) + " seconds ago";
    };
    return <span>{calculateTimeAgo(new Date(timestamp))}</span>;
}


const AlertCard: React.FC<AlertCardProps> = ({ alert, onAcknowledge }) => {
  const config = severityConfig[alert.severity];

  return (
    <div className="bg-secondary rounded-lg shadow-md p-5 flex flex-col sm:flex-row items-start gap-5">
      <div className="flex-shrink-0" style={{ color: config.color }}>
        {config.icon}
      </div>
      <div className="flex-grow">
        <div className="flex items-center gap-3 mb-1">
          <h3 className="text-lg font-bold text-white">{alert.title}</h3>
          {alert.status === 'active' ? (
            <span className="px-2.5 py-0.5 text-xs font-semibold text-white rounded-full" style={{ backgroundColor: `${config.color}90` }}>
              {alert.status}
            </span>
          ) : (
            <span className="px-2.5 py-0.5 text-xs font-semibold text-green-800 bg-green-300 rounded-full">
              {alert.status}
            </span>
          )}
        </div>
        <p className="text-slate-300 mb-2">{alert.description}</p>
        <div className="text-xs text-slate-400 flex items-center gap-2 flex-wrap">
          <span>Device: <span className="font-medium text-slate-300">{alert.deviceName}</span></span>
          <span className="text-slate-600">&bull;</span>
          <span>Location: <span className="font-medium text-slate-300">{alert.locationName}</span></span>
          <span className="text-slate-600">&bull;</span>
          <TimeAgo timestamp={alert.timestamp} />
        </div>
      </div>
      <div className="flex-shrink-0 self-start sm:self-center">
        {alert.status === 'active' && (
          <button
            onClick={() => onAcknowledge(alert.id)}
            className="px-4 py-2 text-sm font-semibold bg-tertiary hover:bg-slate-600 text-white rounded-md transition-colors"
          >
            Acknowledge
          </button>
        )}
      </div>
    </div>
  );
};

export default AlertCard;