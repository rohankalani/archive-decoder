import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { ChartAggregation } from '../types';
import { DateRange } from 'react-day-picker';
import { format } from 'date-fns';

interface AqiSubIndexChartProps {
    data: any[];
    aggregation: ChartAggregation;
    timezone?: string;
    dateRange?: DateRange;
}

const POLLUTANT_COLORS: Record<string, string> = {
    'Overall AQI': '#ffffff',
    'PM2.5': '#ef4444', // red-500
    'PM10': '#f97316', // orange-500
    'HCHO': '#a855f7', // purple-500
    'VOC': '#3b82f6', // blue-500
    'NOx': '#22c55e', // green-500
};

const CustomTooltip = ({ active, payload, label, timezone }: any) => {
    if (active && payload && payload.length) {
        const date = new Date(label);
        const dateOptions: Intl.DateTimeFormatOptions = {
            year: 'numeric', month: 'short', day: 'numeric', timeZone: timezone
        };
        const timeOptions: Intl.DateTimeFormatOptions = {
            hour: '2-digit', minute: '2-digit', timeZone: timezone
        };
        const displayTime = `${date.toLocaleDateString(undefined, dateOptions)}, ${date.toLocaleTimeString([], timeOptions)}`;

        return (
            <div className="bg-primary/80 backdrop-blur-sm p-3 rounded-md border border-slate-700 space-y-1">
                <p className="text-sm text-slate-300">{displayTime}</p>
                <ul className="space-y-1">
                    {payload.sort((a: any, b: any) => b.value - a.value).map((entry: any) => (
                        <li key={entry.name} className="flex items-center text-sm">
                            <span className="w-2.5 h-2.5 rounded-full mr-2" style={{ backgroundColor: entry.color }}></span>
                            <span className="flex-grow text-slate-300">{entry.name}:</span>
                            <span className="font-bold text-white ml-2">{entry.value}</span>
                        </li>
                    ))}
                </ul>
            </div>
        );
    }
    return null;
};

const AqiSubIndexChart: React.FC<AqiSubIndexChartProps> = ({ data, aggregation, timezone, dateRange }) => {
    
    const formatXAxis = (tickItem: string) => {
        const date = new Date(tickItem);
        const daysInRange = dateRange?.from && dateRange?.to 
            ? (dateRange.to.getTime() - dateRange.from.getTime()) / (1000 * 3600 * 24)
            : 7;

        if (aggregation === '1d') {
            return format(date, 'MMM d');
        }
        if (daysInRange <= 2) {
            return format(date, 'HH:mm');
        }
        return format(date, 'MMM d, HH:mm');
    };

    return (
        <div className="bg-secondary p-4 sm:p-6 rounded-lg mt-4">
            <h3 className="text-xl font-bold text-white mb-4">AQI &amp; Sub-Indices</h3>
            <ResponsiveContainer width="100%" height={350}>
                <LineChart data={data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#475569" strokeOpacity={0.5} />
                    <XAxis 
                        dataKey="timestamp" 
                        tickFormatter={formatXAxis}
                        stroke="#94a3b8"
                        tick={{ fontSize: 12 }}
                        interval="preserveStartEnd"
                    />
                    <YAxis 
                        stroke="#94a3b8"
                        tick={{ fontSize: 12 }}
                        domain={[0, 'dataMax + 20']}
                        allowDataOverflow={true}
                        label={{ value: 'AQI', angle: -90, position: 'insideLeft', fill: '#94a3b8', style: { textAnchor: 'middle' } }}
                    />
                    <Tooltip content={<CustomTooltip timezone={timezone} />} />
                    <Legend wrapperStyle={{fontSize: "12px"}}/>
                    
                    {Object.entries(POLLUTANT_COLORS).map(([name, color]) => (
                        <Line
                            key={name}
                            type="monotone"
                            dataKey={name}
                            stroke={color}
                            strokeWidth={name === 'Overall AQI' ? 3 : 1.5}
                            dot={false}
                            activeDot={{ r: 5 }}
                        />
                    ))}
                </LineChart>
            </ResponsiveContainer>
        </div>
    );
};

export default AqiSubIndexChart;