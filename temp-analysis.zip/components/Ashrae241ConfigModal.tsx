import React, { useState, useEffect, useMemo } from 'react';
import { X, Loader2, Plus, Trash2, Wind, Filter as FilterIcon, Sun } from 'lucide-react';
import { Ashrae241Config, InRoomDevice, Location } from '../types';

interface Ashrae241ConfigModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (config: Ashrae241Config) => Promise<void>;
    locations: Location[];
    initialConfigs: Ashrae241Config[];
    initialLocationId: number | null;
}

const defaultConfig: Omit<Ashrae241Config, 'locationId'> = {
    floorArea: null,
    ceilingHeight: 10,
    targetECACH: 5,
    outdoorAirflow: null,
    recirculatedAirflow: null,
    mervRating: 13,
    inRoomDevices: [],
};

const MERV_RATINGS = [8, 13, 14, 16];

const Ashrae241ConfigModal: React.FC<Ashrae241ConfigModalProps> = ({ isOpen, onClose, onSave, locations, initialConfigs, initialLocationId }) => {
    const [selectedLocationId, setSelectedLocationId] = useState<number | ''>(initialLocationId ?? '');
    const [config, setConfig] = useState<Omit<Ashrae241Config, 'locationId'>>(defaultConfig);
    const [isSubmitting, setIsSubmitting] = useState(false);
    
    useEffect(() => {
        if (initialLocationId) {
            setSelectedLocationId(initialLocationId);
        } else if (locations.length > 0) {
            setSelectedLocationId(locations[0].id);
        }
    }, [initialLocationId, locations]);

    useEffect(() => {
        if (selectedLocationId !== '') {
            const existingConfig = initialConfigs.find(c => c.locationId === selectedLocationId);
            setConfig(existingConfig ? { ...existingConfig } : defaultConfig);
        } else {
            setConfig(defaultConfig);
        }
    }, [selectedLocationId, initialConfigs]);

    const handleInRoomDeviceChange = (index: number, field: keyof InRoomDevice, value: string | number) => {
        const newDevices = [...config.inRoomDevices];
        (newDevices[index] as any)[field] = value;
        setConfig(c => ({...c, inRoomDevices: newDevices}));
    };
    
    const addInRoomDevice = () => {
        const newDevice: InRoomDevice = { id: `dev-${Date.now()}`, name: '', cadr: 0 };
        setConfig(c => ({...c, inRoomDevices: [...c.inRoomDevices, newDevice]}));
    };
    
    const removeInRoomDevice = (id: string) => {
        setConfig(c => ({...c, inRoomDevices: c.inRoomDevices.filter(d => d.id !== id)}));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (selectedLocationId === '') {
            alert("Please select a location to configure.");
            return;
        }
        setIsSubmitting(true);
        await onSave({ ...config, locationId: selectedLocationId });
        setIsSubmitting(false);
        onClose();
    };

    const zoneVolume = useMemo(() => {
        if (config.floorArea && config.ceilingHeight) {
            return config.floorArea * config.ceilingHeight;
        }
        return 0;
    }, [config.floorArea, config.ceilingHeight]);

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4">
            <div className="bg-secondary rounded-lg shadow-xl w-full max-w-2xl animate-fade-in-scale" onClick={e => e.stopPropagation()}>
                <form onSubmit={handleSubmit}>
                    <div className="p-5 border-b border-slate-700 flex justify-between items-center">
                        <h2 className="text-xl font-bold text-white">ASHRAE 241 Zone Configuration</h2>
                        <button type="button" onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-6 h-6" /></button>
                    </div>
                    <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
                        <div>
                            <label htmlFor="location-select" className="block text-sm font-medium text-slate-300 mb-1">Zone / Location</label>
                            <select id="location-select" value={selectedLocationId} onChange={e => setSelectedLocationId(Number(e.target.value))} className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white">
                                 <option value="" disabled>-- Select a Zone --</option>
                                {locations.map(loc => <option key={loc.id} value={loc.id}>{loc.name}</option>)}
                            </select>
                        </div>
                        
                        {selectedLocationId && (
                        <>
                            {/* --- Zone Properties --- */}
                            <div className="bg-tertiary p-4 rounded-lg border border-slate-700">
                                <h3 className="font-semibold text-white mb-3">Zone Properties</h3>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div><label className="text-xs text-slate-400">Floor Area (sq ft)</label><input type="number" value={config.floorArea ?? ''} onChange={e => setConfig(c => ({...c, floorArea: e.target.value ? Number(e.target.value) : null}))} className="w-full bg-slate-800 border-slate-600 rounded p-1.5 text-sm"/></div>
                                    <div><label className="text-xs text-slate-400">Ceiling Height (ft)</label><input type="number" value={config.ceilingHeight ?? ''} onChange={e => setConfig(c => ({...c, ceilingHeight: e.target.value ? Number(e.target.value) : null}))} className="w-full bg-slate-800 border-slate-600 rounded p-1.5 text-sm"/></div>
                                    <div className="bg-slate-800 p-1.5 rounded text-center"><p className="text-xs text-slate-400">Zone Volume (ft³)</p><p className="font-bold text-white">{zoneVolume.toLocaleString()}</p></div>
                                </div>
                                <div className="mt-4"><label className="text-sm font-medium text-slate-300">Target eCACH</label><input type="number" step="0.1" value={config.targetECACH} onChange={e => setConfig(c => ({...c, targetECACH: Number(e.target.value)}))} className="w-full mt-1 bg-slate-800 border-slate-600 rounded p-1.5 text-sm"/></div>
                            </div>
                            {/* --- HVAC --- */}
                            <div className="bg-tertiary p-4 rounded-lg border border-slate-700">
                                <h3 className="font-semibold text-white mb-3">Ventilation & Filtration</h3>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div><label className="text-xs text-slate-400 flex items-center gap-1"><Wind size={12}/>Outdoor Airflow (CFM)</label><input type="number" value={config.outdoorAirflow ?? ''} onChange={e => setConfig(c => ({...c, outdoorAirflow: e.target.value ? Number(e.target.value) : null}))} className="w-full bg-slate-800 border-slate-600 rounded p-1.5 text-sm"/></div>
                                    <div><label className="text-xs text-slate-400 flex items-center gap-1"><FilterIcon size={12}/>Recirculated Airflow (CFM)</label><input type="number" value={config.recirculatedAirflow ?? ''} onChange={e => setConfig(c => ({...c, recirculatedAirflow: e.target.value ? Number(e.target.value) : null}))} className="w-full bg-slate-800 border-slate-600 rounded p-1.5 text-sm"/></div>
                                    <div><label className="text-xs text-slate-400">Filter MERV Rating</label><select value={config.mervRating ?? ''} onChange={e => setConfig(c => ({...c, mervRating: Number(e.target.value)}))} className="w-full bg-slate-800 border-slate-600 rounded p-1.5 text-sm">{MERV_RATINGS.map(r => <option key={r} value={r}>MERV {r}</option>)}</select></div>
                                </div>
                            </div>
                             {/* --- In-Room Devices --- */}
                            <div className="bg-tertiary p-4 rounded-lg border border-slate-700">
                                <h3 className="font-semibold text-white mb-3 flex items-center gap-2"><Sun size={14}/> In-Room Air Cleaning Devices</h3>
                                <div className="space-y-2">
                                    {config.inRoomDevices.map((dev, index) => (
                                        <div key={dev.id} className="flex items-center gap-2">
                                            <input type="text" placeholder="Device Name" value={dev.name} onChange={e => handleInRoomDeviceChange(index, 'name', e.target.value)} className="flex-grow bg-slate-800 border-slate-600 rounded p-1.5 text-sm"/>
                                            <input type="number" placeholder="CADR" value={dev.cadr} onChange={e => handleInRoomDeviceChange(index, 'cadr', Number(e.target.value))} className="w-24 bg-slate-800 border-slate-600 rounded p-1.5 text-sm"/>
                                            <span className="text-xs text-slate-400">CFM</span>
                                            <button type="button" onClick={() => removeInRoomDevice(dev.id)} className="p-1 text-slate-500 hover:text-red-400"><Trash2 size={16}/></button>
                                        </div>
                                    ))}
                                    <button type="button" onClick={addInRoomDevice} className="w-full text-sm flex items-center justify-center gap-2 p-1.5 bg-slate-800/50 hover:bg-slate-700 rounded-md border border-dashed border-slate-600">
                                        <Plus size={16}/> Add Device
                                    </button>
                                </div>
                            </div>
                        </>
                        )}
                    </div>
                    <div className="p-5 border-t border-slate-700 flex justify-end gap-3">
                        <button type="button" onClick={onClose} className="px-4 py-2 rounded-md text-white bg-slate-600 hover:bg-slate-500">Cancel</button>
                        <button type="submit" disabled={isSubmitting || !selectedLocationId} className="px-4 py-2 rounded-md text-white bg-accent hover:bg-accent-dark disabled:bg-slate-500 flex items-center gap-2">
                            {isSubmitting && <Loader2 className="w-4 h-4 animate-spin" />}
                            Save Configuration
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default Ashrae241ConfigModal;
