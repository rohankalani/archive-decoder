import React from 'react';
import { Building, Globe, CheckCircle, WifiOff } from 'lucide-react';
import { GlanceSummary, MajorPollutant } from '../types';
import { useSettings } from '../contexts/SettingsContext';
import { ResponsiveContainer, BarChart, Bar, Cell } from 'recharts';

interface GlanceCardProps {
  summary: GlanceSummary & { pollutantTrends?: Record<MajorPollutant, { time: string; value: number }[]> };
  onClick: (() => void) | null; // Allow null to make it non-clickable
  activeMetric: MajorPollutant | 'aqi';
}

const METRIC_DETAILS: Record<MajorPollutant | 'aqi', { name: string, unit: string }> = {
    aqi: { name: 'Avg. AQI', unit: '' },
    pm25: { name: 'Avg. PM2.5', unit: 'µg/m³' },
    co2: { name: 'Avg. CO₂', unit: 'ppm' },
    voc: { name: 'Avg. VOC', unit: 'index' },
};

const GlanceCard: React.FC<GlanceCardProps> = ({ summary, onClick, activeMetric = 'aqi' }) => {
    const { getQualityFromAqi, getMetricQuality } = useSettings();

    const isAqiView = activeMetric === 'aqi';

    const trendData = isAqiView 
        ? summary.trend.map(d => ({ ...d, value: d.aqi }))
        : summary.pollutantTrends?.[activeMetric]?.map(d => ({...d})) || [];
    
    const averageValue = trendData.reduce((acc, curr) => acc + curr.value, 0) / (trendData.length || 1);
    
    const quality = isAqiView 
        ? getQualityFromAqi(averageValue) 
        : getMetricQuality(activeMetric, averageValue);
    
    const metricDetail = METRIC_DETAILS[activeMetric];

    return (
        <button 
            onClick={onClick ? onClick : undefined} 
            className="bg-secondary p-4 rounded-lg flex flex-col justify-between gap-4 border-l-4 hover:bg-tertiary transition-colors duration-200 w-full disabled:cursor-default"
            style={{ borderColor: quality.color }}
            disabled={!onClick}
        >
            <div className="flex justify-between items-start">
                <div className="flex items-center gap-4">
                    {summary.level === 'site' ? <Globe className="w-8 h-8 text-slate-400" /> : <Building className="w-8 h-8 text-slate-400" />}
                    <div>
                        <p className="text-xs text-slate-400 capitalize">{summary.level}</p>
                        <h2 className="text-xl font-bold text-white text-left">{summary.name}</h2>
                    </div>
                </div>
                <div className="text-right">
                    <p className="text-4xl font-bold" style={{ color: quality.color }}>{averageValue.toFixed(0)}</p>
                    <p className="text-xs text-slate-400">{metricDetail.name}</p>
                </div>
            </div>

            <div className="h-20 -mx-4 -mb-4">
                 <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={trendData} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                        <Bar dataKey="value">
                            {trendData.map((entry, index) => {
                                const pointQuality = isAqiView 
                                    ? getQualityFromAqi(entry.value) 
                                    : getMetricQuality(activeMetric, entry.value);
                                return <Cell key={`cell-${index}`} fill={pointQuality.color} />;
                            })}
                        </Bar>
                    </BarChart>
                </ResponsiveContainer>
            </div>
            
            <div className="flex items-center justify-between text-xs text-slate-500 border-t border-slate-700/50 pt-3">
                 <div className="flex items-center gap-2" title="Online Devices">
                    <CheckCircle className="w-4 h-4 text-green-500"/>
                    <span>{summary.onlineCount} / {summary.totalCount} Online</span>
                </div>
                <div className="flex items-center gap-2" title="Offline Devices">
                    {summary.totalCount - summary.onlineCount > 0 && <WifiOff className="w-4 h-4 text-slate-500"/>}
                </div>
            </div>
        </button>
    );
};

export default GlanceCard;