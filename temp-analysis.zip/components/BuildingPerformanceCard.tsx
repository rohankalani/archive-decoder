import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { GlanceSummary, MajorPollutant, GlanceTimePeriod } from '../types';
import { useSettings } from '../contexts/SettingsContext';
import { format } from 'date-fns';

interface BuildingPerformanceCardProps {
    buildingSummary: GlanceSummary & { pollutantTrends: Record<MajorPollutant, { time: string; value: number }[]> };
    activePollutant: MajorPollutant;
    timePeriod: GlanceTimePeriod;
}

const POLLUTANT_CONFIG: Record<MajorPollutant, { name: string, unit: string }> = {
    pm25: { name: 'PM2.5', unit: 'µg/m³' },
    co2: { name: 'CO₂', unit: 'ppm' },
    voc: { name: 'VOC', unit: 'index' },
};

const CustomTooltip = ({ active, payload, label, activePollutant }: any) => {
    if (active && payload && payload.length) {
        const value = payload[0].value;
        const config = POLLUTANT_CONFIG[activePollutant as MajorPollutant];
        return (
            <div className="bg-primary/80 backdrop-blur-sm p-3 rounded-md border border-slate-700">
                <p className="text-sm text-slate-300">{label}</p>
                <p style={{ color: payload[0].payload.fill }}>
                    {config.name}: {value.toFixed(1)} {config.unit}
                </p>
            </div>
        );
    }
    return null;
};

const BuildingPerformanceCard: React.FC<BuildingPerformanceCardProps> = ({ buildingSummary, activePollutant, timePeriod }) => {
    const { getMetricQuality } = useSettings();
    const activeConfig = POLLUTANT_CONFIG[activePollutant];

    const formatXAxis = (tickItem: string) => {
        const date = new Date(tickItem);
        return timePeriod === '12m' ? format(date, 'MMM') : format(date, 'd');
    };

    const trendData = buildingSummary.pollutantTrends[activePollutant].map(d => ({
        ...d,
        time: formatXAxis(d.time)
    }));
    
    const averageValue = trendData.reduce((acc, curr) => acc + curr.value, 0) / (trendData.length || 1);
    const quality = getMetricQuality(activePollutant, averageValue);
    
    return (
        <div className="bg-tertiary p-4 rounded-lg">
            <div className="flex justify-between items-start mb-3">
                <h4 className="text-lg font-bold text-white">{buildingSummary.name}</h4>
                <div className="text-right">
                    <p className="text-2xl font-bold" style={{ color: quality.color }}>{averageValue.toFixed(0)}</p>
                    <p className="text-xs text-slate-400">Avg. {activeConfig.name}</p>
                </div>
            </div>
            <div className="h-40">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={trendData} margin={{ top: 5, right: 5, left: -25, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#475569" strokeOpacity={0.3} />
                        <XAxis dataKey="time" stroke="#94a3b8" tick={{ fontSize: 10 }} />
                        <YAxis stroke="#94a3b8" tick={{ fontSize: 10 }} domain={['auto', 'dataMax + 10']} />
                        <Tooltip content={<CustomTooltip activePollutant={activePollutant} />} cursor={{fill: 'rgba(100, 116, 139, 0.2)'}} />
                        <Bar dataKey="value" name={activeConfig.name} radius={[2, 2, 0, 0]}>
                            {trendData.map((entry, index) => {
                                const quality = getMetricQuality(activePollutant, entry.value);
                                return <Cell key={`cell-${index}`} fill={quality.color} />;
                            })}
                        </Bar>
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
};

export default BuildingPerformanceCard;