import React from 'react';

interface MetricInfo {
  label: string;
  value: number | undefined;
  unit: string;
  color: string;
}

interface CombinedMetricDisplayProps {
  primary: MetricInfo;
  secondary: MetricInfo;
}

const CombinedMetricDisplay: React.FC<CombinedMetricDisplayProps> = ({ primary, secondary }) => {
  const renderMetric = (metric: MetricInfo, isPrimary: boolean) => {
    if (metric.value === undefined || metric.value === null) {
      return (
        <div>
          <div className="flex items-center space-x-2 mb-1">
            <div className={`rounded-full w-2.5 h-2.5`} style={{ backgroundColor: '#64748b' }}></div>
            <p className="text-sm text-slate-400">{metric.label}</p>
          </div>
          <div className="flex items-baseline">
            <p className={`font-bold leading-tight text-slate-500 ${isPrimary ? 'text-2xl' : 'text-xl'}`}>--</p>
            <p className="text-sm text-slate-500 ml-1">{metric.unit}</p>
          </div>
        </div>
      );
    }
    return (
      <div>
        <div className="flex items-center space-x-2 mb-1">
          <div className={`rounded-full w-2.5 h-2.5`} style={{ backgroundColor: metric.color }}></div>
          <p className="text-sm text-slate-400">{metric.label}</p>
        </div>
        <div className="flex items-baseline">
          <p className={`font-bold leading-tight text-white ${isPrimary ? 'text-2xl' : 'text-xl'}`}>
            {metric.value.toLocaleString()}
          </p>
          <p className="text-sm text-slate-400 ml-1">{metric.unit}</p>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col justify-between h-full">
      {renderMetric(primary, true)}
      <div className="border-t border-slate-700/50 my-2"></div>
      {renderMetric(secondary, false)}
    </div>
  );
};

export default CombinedMetricDisplay;
