import React, { useState } from 'react';
import { Link } from 'react-router-dom';
// FIX: Corrected import path for types.
import { DeviceWithData, Metric } from '../types';
import { useSettings } from '../contexts/SettingsContext';
import MetricDisplay from './MetricDisplay';
import { Edit, Check, X, Loader2, Flame } from 'lucide-react';
import { useAlerts } from '../contexts/AlertsContext';
import { useAuth } from '../contexts/AuthContext';

interface DeviceCardProps {
  device: DeviceWithData;
  onUpdateName: (id: string, newName: string) => Promise<void>;
}

// FIX: Added 'dp', 'presence', 'smoke_vape_detected', 'fan_speed', and 'filter_life' to satisfy the Record<Metric, string> type.
const metricShortNames: Record<Metric, string> = {
    pm25: 'PM2.5', pm10: 'PM10', hcho: 'HCHO', voc: 'VOC', nox: 'NOx',
    iaqi: 'IAQI', co2: 'CO2', temp: 'Temp', humidity: 'Humidity',
    pm03: 'PM0.3', pm1: 'PM1', pm5: 'PM5', pc03: 'PC0.3', pc05: 'PC0.5',
    pc1: 'PC1', pc25: 'PC2.5', pc5: 'PC5', pc10: 'PC10', occupancy: 'Occupancy',
    dp: 'DP',
    presence: 'Presence',
    smoke_vape_detected: 'Smoke/Vape',
    battery: 'Battery',
    fan_speed: 'Fan Speed',
    filter_life: 'Filter Life',
};

const DeviceCard: React.FC<DeviceCardProps> = ({ device, onUpdateName }) => {
  const { getMetricQuality, calculateOverallAqi } = useSettings();
  const { alerts } = useAlerts();
  const { role } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [editingName, setEditingName] = useState(device.name);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const data = device.latest_data;
  const isOnline = device.status === 'online';

  const smokeVapeAlert = alerts.find(a => a.deviceId === device.id && a.type === 'smoke-vape-detected' && a.status === 'active');

  const handleEditClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsEditing(true);
  };

  const handleCancel = (e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    setIsEditing(false);
    setEditingName(device.name);
  };

  const handleSave = async (e?: React.MouseEvent | React.FormEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    if (editingName.trim() === '' || editingName === device.name) {
      setIsEditing(false);
      return;
    }
    setIsSubmitting(true);
    await onUpdateName(device.id, editingName);
    setIsSubmitting(false);
    setIsEditing(false);
  };
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSave();
    } else if (e.key === 'Escape') {
      handleCancel();
    }
  };

  const getMetricData = (metric: Metric) => {
    const value = data?.[metric];
    if (!isOnline || value === undefined || value === null) {
      return { value: null, quality: { label: 'N/A', color: '#64748b' } };
    }
    return { value, quality: getMetricQuality(metric, value) };
  };
  
  const { aqi, quality, dominantPollutant } = calculateOverallAqi(data);
  const temp = getMetricData('temp');
  const humidity = getMetricData('humidity');
  const co2 = getMetricData('co2');
  const pm25 = getMetricData('pm25');

  const renderMetric = (label: string, metricData: ReturnType<typeof getMetricData>, unit: string) => {
    if (metricData.value === null) {
        return (
           <div>
              <div className="flex items-center space-x-2 mb-1">
                  <div className={`rounded-full w-2 h-2`} style={{ backgroundColor: metricData.quality.color }}></div>
                  <p className={`text-xs text-slate-400`}>{label}</p>
              </div>
              <div className="flex items-baseline">
                  <p className={`text-lg font-bold leading-tight text-slate-500`}>--</p>
                  <p className={`text-xs text-slate-500 ml-1`}>{unit}</p>
              </div>
          </div>
        )
    }
    return <MetricDisplay label={label} value={metricData.value} unit={unit} color={metricData.quality.color} size="small"/>
  }

  const cardClasses = `block bg-secondary rounded-lg shadow-lg hover:shadow-accent/30 transition-all duration-300 p-6 space-y-4 ${
      smokeVapeAlert
      ? 'ring-2 ring-red-500 shadow-red-500/50 animate-pulse'
      : 'hover:ring-2 hover:ring-accent/50'
  }`;

  return (
    <Link to={isEditing ? '#' : `/device/${device.id}`} className={cardClasses}>
        <div className="flex justify-between items-start">
            <div className="flex-1 min-w-0">
                <div className="group relative">
                    {isEditing ? (
                        <form onSubmit={handleSave} className="flex items-center gap-2" onClick={(e) => { e.preventDefault(); e.stopPropagation();}}>
                            <input
                                type="text"
                                value={editingName}
                                onChange={e => setEditingName(e.target.value)}
                                onKeyDown={handleKeyDown}
                                autoFocus
                                className="bg-slate-950 text-white text-xl font-bold p-1 rounded-md outline-none ring-2 ring-accent w-full"
                            />
                             <button type="submit" disabled={isSubmitting} className="p-1 text-green-400 hover:bg-slate-700 rounded-full disabled:text-slate-500">
                                {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin"/> : <Check className="w-4 h-4" />}
                            </button>
                            <button type="button" onClick={handleCancel} className="p-1 text-red-400 hover:bg-slate-700 rounded-full">
                                <X className="w-4 h-4" />
                            </button>
                        </form>
                    ) : (
                        <h3 className="text-xl font-bold text-cyan-400 flex items-center gap-2 truncate">
                            {smokeVapeAlert && <Flame className="w-5 h-5 text-red-500 flex-shrink-0" />}
                            <span className="truncate" title={device.name}>{device.name}</span>
                            {role === 'admin' && (
                                <button onClick={handleEditClick} className="opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
                                    <Edit className="w-4 h-4 text-slate-400 hover:text-white" />
                                </button>
                            )}
                        </h3>
                    )}
                </div>
                <p className="text-sm text-white truncate" title={device.location.name}>{device.location.name}</p>
                 <div className="flex items-center gap-2 mt-1">
                    <div className={`w-2 h-2 rounded-full ${isOnline ? 'bg-green-400' : 'bg-slate-500'} ${isOnline && !smokeVapeAlert ? 'animate-pulse' : ''}`}></div>
                    <p className={`text-xs ${isOnline ? 'text-slate-300' : 'text-slate-500'}`}>{isOnline ? 'Online' : 'Offline'}</p>
                </div>
            </div>
            <div className="text-right flex-shrink-0 ml-4">
                <p className="text-xs text-slate-400">
                    AQI {dominantPollutant && metricShortNames[dominantPollutant] ? `(${metricShortNames[dominantPollutant]})` : ''}
                </p>
                <p className={`text-3xl font-bold leading-tight ${!isOnline ? 'text-slate-600' : ''}`} style={isOnline ? { color: quality.color } : {}}>
                    {isOnline ? aqi : '--'}
                </p>
            </div>
        </div>
      
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
            {renderMetric('PM2.5', pm25, 'µg/m³')}
            {renderMetric('CO₂', co2, 'ppm')}
            {renderMetric('Temp.', temp, '°C')}
            {renderMetric('Humidity', humidity, '%')}
        </div>

        { !data && isOnline && <div className="text-center py-4 text-slate-500">Waiting for data...</div> }
    </Link>
  );
};

export default DeviceCard;
