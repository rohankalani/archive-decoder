import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
// FIX: Corrected import path for types.
import { DeviceWithData, Metric } from '../types';
import { useSettings } from '../contexts/SettingsContext';
import { ResponsiveContainer, AreaChart, Area, YAxis } from 'recharts';

interface DeviceGlanceCardProps {
  device: DeviceWithData;
}

// FIX: Added 'dp', 'presence', 'smoke_vape_detected', 'fan_speed', and 'filter_life' to satisfy the Record<Metric, string> type.
const metricShortNames: Record<Metric, string> = {
    pm25: 'PM2.5', pm10: 'PM10', hcho: 'HCHO', voc: 'VOC', nox: 'NOx',
    iaqi: 'IAQI', co2: 'CO2', temp: 'Temp', humidity: 'Humidity',
    pm03: 'PM0.3', pm1: 'PM1', pm5: 'PM5', pc03: 'PC0.3', pc05: 'PC0.5',
    pc1: 'PC1', pc25: 'PC2.5', pc5: 'PC5', pc10: 'PC10', occupancy: 'Occupancy',
    dp: 'DP',
    presence: 'Presence',
    smoke_vape_detected: 'Smoke/Vape',
    battery: 'Battery',
    fan_speed: 'Fan Speed',
    filter_life: 'Filter Life',
};

const DeviceGlanceCard: React.FC<DeviceGlanceCardProps> = ({ device }) => {
  const { calculateOverallAqi } = useSettings();

  const data = device.latest_data;
  const isOnline = device.status === 'online';
  const { aqi, quality, dominantPollutant } = calculateOverallAqi(data);
  
  // Calculate historical AQI for each data point in the snippet
  const chartData = useMemo(() => {
    return device.historical_snippet?.map(d => {
        const { aqi: historicalAqi } = calculateOverallAqi(d);
        return { ...d, aqi: historicalAqi ?? 0 };
    });
  }, [device.historical_snippet, calculateOverallAqi]);

  return (
    <Link to={`/device/${device.id}`} className="block bg-secondary/70 backdrop-blur-sm rounded-lg shadow-lg hover:shadow-accent/30 hover:ring-2 hover:ring-accent/50 transition-all duration-300 p-4 flex flex-col justify-between">
      {/* Top Row */}
      <div className="flex justify-between items-start">
        <div className="flex-1 min-w-0">
          <h3 className="text-lg font-bold text-white leading-tight truncate" title={device.name}>{device.name}</h3>
          <p className="text-xs text-slate-400 truncate" title={device.location.name}>{device.location.name}</p>
        </div>
        <div className="text-right flex flex-col items-end flex-shrink-0 ml-2">
          <p className={`text-5xl font-bold leading-none ${!isOnline ? 'text-slate-600' : ''}`} style={isOnline ? { color: quality.color } : {}}>
            {isOnline ? aqi : '--'}
          </p>
          <p className="text-xs text-slate-400 mt-1">
            {isOnline && dominantPollutant && metricShortNames[dominantPollutant] ? `from ${metricShortNames[dominantPollutant]}` : 'AQI'}
          </p>
        </div>
      </div>

      {/* Chart */}
      <div className="h-16 mt-3 mb-1">
        {isOnline && chartData && chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 5, right: 0, left: 0, bottom: 0 }}>
                <defs>
                    <linearGradient id="colorAqiLevelsStroke" x1="0" y1="1" x2="0" y2="0">
                        <stop offset="0%" stopColor="#4ade80" />   {/* Good */}
                        <stop offset="20%" stopColor="#4ade80" />
                        <stop offset="40%" stopColor="#facc15" />  {/* Moderate */}
                        <stop offset="60%" stopColor="#f97316" />  {/* Unhealthy Sens */}
                        <stop offset="80%" stopColor="#ef4444" />  {/* Unhealthy */}
                        <stop offset="100%" stopColor="#a855f7" /> {/* Very Unhealthy */}
                    </linearGradient>
                    <linearGradient id="colorAqiLevelsFill" x1="0" y1="1" x2="0" y2="0">
                        <stop offset="0%" stopColor="#4ade80" stopOpacity={0.1}/>
                        <stop offset="20%" stopColor="#4ade80" stopOpacity={0.2}/>
                        <stop offset="40%" stopColor="#facc15" stopOpacity={0.3}/>
                        <stop offset="60%" stopColor="#f97316" stopOpacity={0.4}/>
                        <stop offset="80%" stopColor="#ef4444" stopOpacity={0.5}/>
                        <stop offset="100%" stopColor="#a855f7" stopOpacity={0.6}/>
                    </linearGradient>
                </defs>
                {/* FIX: Replaced corrupted line with a valid YAxis component to fix type error. */}
                <YAxis hide domain={['dataMin - 5', 'dataMax + 5']} />
              <Area
                  type="monotone"
                  dataKey="aqi"
                  stroke="url(#colorAqiLevelsStroke)"
                  strokeWidth={2}
                  fill="url(#colorAqiLevelsFill)"
              />
            </AreaChart>
          </ResponsiveContainer>
        ) : (
            <div className="flex items-center justify-center h-full text-slate-600 text-sm">No recent data for trend</div>
        )}
      </div>

      {/* Bottom Row */}
      <div className="flex justify-between items-center text-xs text-slate-500 border-t border-slate-700/50 pt-3 mt-1">
        <span>Status: <span className={isOnline ? 'text-green-400 font-semibold' : 'text-slate-500 font-semibold'}>{isOnline ? 'Online' : 'Offline'}</span></span>
        <span>Battery: <span className="font-semibold text-white">{data?.battery?.toFixed(0) ?? '--'}%</span></span>
      </div>
    </Link>
  );
};

export default DeviceGlanceCard;
