import React, { useState, useEffect, useCallback } from 'react';
import { getDevices, getLocations, addDevice, updateDevice, deleteDevice, addLocation, deleteLocation } from '../services/apiService';
import { DeviceWithData, Location } from '../types';
import { Plus, Trash2, Edit, X, Loader2 } from 'lucide-react';

const DeviceLocationManagement: React.FC = () => {
    const [devices, setDevices] = useState<DeviceWithData[]>([]);
    const [locations, setLocations] = useState<Location[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const [isDeviceModalOpen, setIsDeviceModalOpen] = useState(false);
    const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);
    const [editingDevice, setEditingDevice] = useState<DeviceWithData | null>(null);
    const [newDeviceName, setNewDeviceName] = useState('');
    const [selectedLocation, setSelectedLocation] = useState<number | ''>('');
    
    const [newLocationName, setNewLocationName] = useState('');
    const [newLocationSite, setNewLocationSite] = useState('');
    const [newLocationBuilding, setNewLocationBuilding] = useState('');
    const [newLocationBlock, setNewLocationBlock] = useState('');
    const [newLocationFloor, setNewLocationFloor] = useState('');

    const [isSubmitting, setIsSubmitting] = useState(false);

    const fetchData = useCallback(async () => {
        try {
            setLoading(true);
            setError(null);
            const [devicesData, locationsData] = await Promise.all([getDevices(), getLocations()]);
            setDevices(devicesData.filter(d => d.type === 'standard'));
            setLocations(locationsData);
        } catch (err) {
            setError("Failed to load management data. Please try again.");
            console.error(err);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const openAddDeviceModal = () => {
        setEditingDevice(null);
        setNewDeviceName('');
        setSelectedLocation(locations.length > 0 ? locations[0].id : '');
        setIsDeviceModalOpen(true);
    };

    const openEditDeviceModal = (device: DeviceWithData) => {
        setEditingDevice(device);
        setNewDeviceName(device.name);
        setSelectedLocation(device.location_id);
        setIsDeviceModalOpen(true);
    };
    
    const handleDeviceSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newDeviceName || selectedLocation === '') return;
        setIsSubmitting(true);
        try {
            if (editingDevice) {
                await updateDevice(editingDevice.id, newDeviceName, selectedLocation as number);
            } else {
                await addDevice(newDeviceName, selectedLocation as number, 'standard');
            }
            setIsDeviceModalOpen(false);
            fetchData();
        } catch (err) {
            console.error("Failed to save device", err);
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleDeleteDevice = async (id: string) => {
        if (window.confirm('Are you sure you want to delete this device? This action is permanent.')) {
            try {
                await deleteDevice(id);
                fetchData();
            } catch (err) {
                console.error('Failed to delete device', err);
            }
        }
    };
    
    const handleLocationSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newLocationName || !newLocationSite || !newLocationBuilding || !newLocationBlock || !newLocationFloor) {
            alert("All location fields are required.");
            return;
        }
        setIsSubmitting(true);
        try {
            await addLocation(newLocationName, newLocationSite, newLocationBuilding, newLocationBlock, newLocationFloor);
            setNewLocationName(''); setNewLocationSite(''); setNewLocationBuilding(''); setNewLocationBlock(''); setNewLocationFloor('');
            setIsLocationModalOpen(false);
            fetchData();
        } catch (err) {
            console.error("Failed to add location", err);
        } finally {
            setIsSubmitting(false);
        }
    };
    
    const handleDeleteLocation = async (id: number) => {
         if (devices.some(d => d.location_id === id)) {
            alert("Cannot delete a location that has devices assigned to it. Please reassign the devices first.");
            return;
        }
        if (window.confirm('Are you sure you want to delete this location?')) {
            try {
                await deleteLocation(id);
                fetchData();
            } catch (err) {
                console.error('Failed to delete location', err);
            }
        }
    };

    if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>;
    if (error) return <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error}</div>;

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-tertiary p-6 rounded-lg shadow-inner">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-2xl font-bold text-white">Air Quality Sensors</h2>
                    <button onClick={openAddDeviceModal} className="flex items-center gap-2 px-4 py-2 rounded-md text-white bg-accent hover:bg-accent-dark">
                        <Plus className="w-5 h-5" /> Add Sensor
                    </button>
                </div>
                <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
                    {devices.map(device => (
                        <div key={device.id} className="bg-secondary p-4 rounded-md flex justify-between items-center">
                            <div>
                                <p className="font-semibold text-white">{device.name}</p>
                                <p className="text-sm text-slate-400">{device.location?.name || 'Unassigned'}</p>
                            </div>
                            <div className="flex items-center gap-3">
                                <button onClick={() => openEditDeviceModal(device)} className="text-slate-400 hover:text-white"><Edit className="w-5 h-5" /></button>
                                <button onClick={() => handleDeleteDevice(device.id)} className="text-slate-400 hover:text-red-500"><Trash2 className="w-5 h-5" /></button>
                            </div>
                        </div>
                    ))}
                    {devices.length === 0 && <p className="text-slate-400 text-center py-4">No standard sensors configured.</p>}
                </div>
            </div>

            <div className="bg-tertiary p-6 rounded-lg shadow-inner">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-2xl font-bold text-white">Locations</h2>
                    <button onClick={() => setIsLocationModalOpen(true)} className="flex items-center gap-2 px-4 py-2 rounded-md text-white bg-accent hover:bg-accent-dark">
                        <Plus className="w-5 h-5" /> Add Location
                    </button>
                </div>
                 <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
                    {locations.map(loc => (
                        <div key={loc.id} className="bg-secondary p-4 rounded-md flex justify-between items-center">
                            <div>
                               <p className="font-semibold text-white">{loc.name}</p>
                               <p className="text-sm text-slate-400">{`${loc.site} / ${loc.building} / ${loc.block} / ${loc.floor}`}</p>
                            </div>
                            <button onClick={() => handleDeleteLocation(loc.id)} className="text-slate-400 hover:text-red-500"><Trash2 className="w-5 h-5" /></button>
                        </div>
                    ))}
                    {locations.length === 0 && <p className="text-slate-400 text-center py-4">No locations configured.</p>}
                </div>
            </div>
            
            {isDeviceModalOpen && (
                 <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4 animate-fade-in-scale">
                    <div className="bg-secondary rounded-lg shadow-xl w-full max-w-md">
                        <form onSubmit={handleDeviceSubmit}>
                            <div className="p-5 border-b border-slate-700 flex justify-between items-center"><h2 className="text-xl font-bold text-white">{editingDevice ? 'Edit Sensor' : 'Add New Sensor'}</h2><button type="button" onClick={() => setIsDeviceModalOpen(false)} className="text-slate-400 hover:text-white"><X className="w-6 h-6" /></button></div>
                            <div className="p-5 space-y-4">
                                <div><label htmlFor="device-name" className="block text-sm font-medium text-slate-300 mb-1">Sensor Name</label><input id="device-name" type="text" value={newDeviceName} onChange={e => setNewDeviceName(e.target.value)} required className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" /></div>
                                <div><label htmlFor="location-select" className="block text-sm font-medium text-slate-300 mb-1">Location</label><select id="location-select" value={selectedLocation} onChange={e => setSelectedLocation(Number(e.target.value))} required className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white"><option value="" disabled>Select a location</option>{locations.map(loc => <option key={loc.id} value={loc.id}>{loc.name}</option>)}</select></div>
                            </div>
                            <div className="p-5 border-t border-slate-700 flex justify-end gap-3"><button type="button" onClick={() => setIsDeviceModalOpen(false)} className="px-4 py-2 rounded-md text-white bg-slate-600 hover:bg-slate-500">Cancel</button><button type="submit" disabled={isSubmitting} className="px-4 py-2 rounded-md text-white bg-accent hover:bg-accent-dark disabled:bg-slate-500 flex items-center gap-2">{isSubmitting && <Loader2 className="w-4 h-4 animate-spin"/>}{editingDevice ? 'Save Changes' : 'Add Sensor'}</button></div>
                        </form>
                    </div>
                 </div>
            )}
            
            {isLocationModalOpen && (
                 <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4 animate-fade-in-scale">
                    <div className="bg-secondary rounded-lg shadow-xl w-full max-w-md">
                        <form onSubmit={handleLocationSubmit}>
                             <div className="p-5 border-b border-slate-700 flex justify-between items-center"><h2 className="text-xl font-bold text-white">Add Location</h2><button type="button" onClick={() => setIsLocationModalOpen(false)} className="text-slate-400 hover:text-white"><X className="w-6 h-6" /></button></div>
                             <div className="p-5 space-y-4">
                                <div><label htmlFor="location-name" className="block text-sm font-medium text-slate-300 mb-1">Location Display Name</label><input id="location-name" type="text" value={newLocationName} onChange={e => setNewLocationName(e.target.value)} required placeholder="e.g., Main Office - Room 101" className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" /></div>
                                <div><label htmlFor="location-site" className="block text-sm font-medium text-slate-300 mb-1">Site</label><input id="location-site" type="text" value={newLocationSite} onChange={e => setNewLocationSite(e.target.value)} required placeholder="e.g., Corporate HQ" className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" /></div>
                                <div><label htmlFor="location-building" className="block text-sm font-medium text-slate-300 mb-1">Building</label><input id="location-building" type="text" value={newLocationBuilding} onChange={e => setNewLocationBuilding(e.target.value)} required placeholder="e.g., Building A" className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" /></div>
                                 <div><label htmlFor="location-block" className="block text-sm font-medium text-slate-300 mb-1">Block / Wing</label><input id="location-block" type="text" value={newLocationBlock} onChange={e => setNewLocationBlock(e.target.value)} required placeholder="e.g., West Wing" className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" /></div>
                                 <div><label htmlFor="location-floor" className="block text-sm font-medium text-slate-300 mb-1">Floor</label><input id="location-floor" type="text" value={newLocationFloor} onChange={e => setNewLocationFloor(e.target.value)} required placeholder="e.g., Floor 2" className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" /></div>
                            </div>
                            <div className="p-5 border-t border-slate-700 flex justify-end gap-3"><button type="button" onClick={() => setIsLocationModalOpen(false)} className="px-4 py-2 rounded-md text-white bg-slate-600 hover:bg-slate-500">Cancel</button><button type="submit" disabled={isSubmitting} className="px-4 py-2 rounded-md text-white bg-accent hover:bg-accent-dark disabled:bg-slate-500 flex items-center gap-2">{isSubmitting && <Loader2 className="w-4 h-4 animate-spin"/>}Add Location</button></div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default DeviceLocationManagement;