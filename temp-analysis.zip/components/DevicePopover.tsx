import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { DeviceWithData } from '../types';
import { useSettings } from '../contexts/SettingsContext';
// FIX: Imported 'Zap' icon from lucide-react.
import { X, ArrowRight, Edit, Check, Loader2, Wind, Filter, Power, SlidersHorizontal, User, Cloud, Zap } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface DevicePopoverProps {
    device: DeviceWithData;
    onClose: () => void;
    position: { top: number; left: number };
    onUpdateName: (id: string, newName: string) => Promise<void>;
}

const PopoverMetric: React.FC<{ label: string; value: string | number | undefined; unit: string; color?: string; icon?: React.ReactNode }> = ({ label, value, unit, color, icon }) => (
    <div className="flex justify-between items-center text-sm">
        <div className="flex items-center gap-2">
            {color && <div className="w-2 h-2 rounded-full" style={{ backgroundColor: color }}></div>}
            {icon}
            <span className="text-slate-400">{label}</span>
        </div>
        <span className="font-bold text-white">
            {value !== undefined ? `${value} ${unit}`.trim() : 'N/A'}
        </span>
    </div>
);


const DevicePopover: React.FC<DevicePopoverProps> = ({ device, onClose, position, onUpdateName }) => {
    const { calculateOverallAqi, getMetricQuality } = useSettings();
    const { role } = useAuth();
    const data = device.latest_data;
    
    const [isEditing, setIsEditing] = useState(false);
    const [editingName, setEditingName] = useState(device.name);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSave = async (e: React.MouseEvent | React.FormEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (editingName.trim() === '' || editingName === device.name) {
            setIsEditing(false);
            return;
        }
        setIsSubmitting(true);
        await onUpdateName(device.id, editingName);
        setIsSubmitting(false);
        setIsEditing(false);
    };

    const handleCancel = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setIsEditing(false);
        setEditingName(device.name);
    };

    const renderContent = () => {
        switch(device.type) {
            case 'air-purifier':
                const mode = data?.mode ?? 'off';
                const modeIcon = { 'auto': <Zap size={14}/>, 'manual': <SlidersHorizontal size={14}/>, 'off': <Power size={14}/> }[mode];
                return (
                    <div className="space-y-2">
                        <PopoverMetric icon={<Wind size={14} className="text-slate-500"/>} label="Fan Speed" value={data?.fan_speed?.toFixed(0)} unit="%" />
                        <PopoverMetric icon={<Filter size={14} className="text-slate-500"/>} label="Filter Life" value={data?.filter_life?.toFixed(1)} unit="%" />
                        <PopoverMetric icon={modeIcon} label="Mode" value={mode.charAt(0).toUpperCase() + mode.slice(1)} unit="" />
                    </div>
                );
            case 'vape-smoke':
                return (
                     <div className="space-y-2">
                        <PopoverMetric icon={<Cloud size={14} className="text-slate-500"/>} label="VOC Index" value={data?.voc?.toFixed(0)} unit="" />
                        <PopoverMetric icon={<Filter size={14} className="text-slate-500"/>} label="PM2.5" value={data?.pm25?.toFixed(1)} unit="µg/m³" />
                        <PopoverMetric icon={<User size={14} className="text-slate-500"/>} label="Presence" value={data?.presence === 1 ? 'Detected' : 'None'} unit="" />
                    </div>
                );
            case 'standard':
            default:
                const { aqi, quality } = calculateOverallAqi(data);
                const pm25 = getMetricQuality('pm25', data?.pm25 ?? 0);
                const co2 = getMetricQuality('co2', data?.co2 ?? 0);
                 return (
                    <div className="space-y-2">
                        <div className="flex justify-between items-center">
                            <span className="text-slate-400 text-sm">Overall AQI</span>
                            <span className="text-2xl font-bold" style={{ color: quality.color }}>{aqi}</span>
                        </div>
                        <PopoverMetric label="PM2.5" value={data?.pm25?.toFixed(1)} unit="µg/m³" color={pm25.color} />
                        <PopoverMetric label="CO₂" value={data?.co2?.toFixed(0)} unit="ppm" color={co2.color} />
                    </div>
                );
        }
    }


    return (
        <div 
            className="absolute z-20 w-64 bg-slate-800 rounded-lg shadow-2xl border border-slate-700 animate-fade-in-scale"
            style={{ ...position, transform: 'translate(-50%, 10px)' }}
            onClick={(e) => e.stopPropagation()}
        >
            <div className="p-3 border-b border-slate-700 flex justify-between items-center">
                <div className="flex-1 min-w-0 group">
                    {isEditing ? (
                        <form onSubmit={handleSave} className="flex items-center gap-2">
                            <input
                                type="text"
                                value={editingName}
                                onChange={e => setEditingName(e.target.value)}
                                autoFocus
                                className="bg-slate-900 text-white font-bold p-1 rounded-md outline-none ring-1 ring-accent w-full text-sm"
                            />
                             <button type="submit" disabled={isSubmitting} className="p-1 text-green-400 hover:bg-slate-700 rounded-full disabled:text-slate-500">
                                {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin"/> : <Check className="w-4 h-4" />}
                            </button>
                            <button type="button" onClick={handleCancel} className="p-1 text-red-400 hover:bg-slate-700 rounded-full">
                                <X className="w-4 h-4" />
                            </button>
                        </form>
                    ) : (
                         <h3 className="font-bold text-white truncate flex items-center gap-2">
                            {device.name}
                            {role === 'admin' && (
                                <button onClick={(e) => { e.stopPropagation(); setIsEditing(true); }} className="opacity-0 group-hover:opacity-100 transition-opacity">
                                    <Edit className="w-3 h-3 text-slate-400 hover:text-white" />
                                </button>
                            )}
                        </h3>
                    )}
                    <p className="text-xs text-slate-400 truncate">{device.location.name}</p>
                </div>
                <button onClick={onClose} className="ml-2 text-slate-500 hover:text-white"><X size={16} /></button>
            </div>
            <div className="p-3">
                {renderContent()}
            </div>
            <Link to={`/device/${device.id}`} className="block text-center p-2 border-t border-slate-700 text-accent hover:bg-slate-750 rounded-b-lg text-sm font-semibold">
                View Details <ArrowRight className="inline w-4 h-4" />
            </Link>
        </div>
    );
};

export default DevicePopover;
