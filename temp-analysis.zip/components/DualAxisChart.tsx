import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts';
import { format } from 'date-fns';
import { AhuReport } from '../types';

interface AhuPerformanceChartProps {
    reportData: AhuReport;
}

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
        const dataPoint = payload[0].payload;
        return (
            <div className="bg-primary/80 backdrop-blur-sm p-3 rounded-md border border-slate-700 space-y-2 text-sm">
                <p className="font-semibold text-slate-300">{format(new Date(label), 'd MMM yyyy')}</p>
                <div className="border-t border-slate-700 my-1"></div>
                <div className="flex justify-between items-center" style={{ color: '#4ade80' }}>
                    <span>Particle Efficiency:</span>
                    <span className="font-bold ml-2">{dataPoint.particleEfficiency.toFixed(1)} %</span>
                </div>
                 <div className="flex justify-between items-center" style={{ color: '#f97316' }}>
                    <span>Total DP:</span>
                    <span className="font-bold ml-2">{dataPoint.totalDifferentialPressure.toFixed(1)} Pa</span>
                </div>
            </div>
        );
    }
    return null;
};

const AhuPerformanceChart: React.FC<AhuPerformanceChartProps> = ({ reportData }) => {
    const { historicalData, totalDpChangeThreshold } = reportData;
    
    return (
        <ResponsiveContainer width="100%" height={150}>
            <LineChart data={historicalData} margin={{ top: 5, right: 5, left: -15, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#475569" strokeOpacity={0.5} />
                <XAxis
                    dataKey="timestamp"
                    stroke="#94a3b8"
                    tick={{ fontSize: 10 }}
                    tickFormatter={(ts) => format(new Date(ts), 'd MMM')}
                />
                <YAxis yAxisId="left" stroke="#4ade80" tick={{ fontSize: 10 }} domain={[85, 100]} unit="%" />
                <YAxis yAxisId="right" orientation="right" stroke="#f97316" tick={{ fontSize: 10 }} domain={[0, 'dataMax + 50']} unit=" Pa" />
                
                <Tooltip content={<CustomTooltip />} />
                <Legend iconSize={8} wrapperStyle={{ fontSize: "10px", paddingTop: '10px' }}/>

                <ReferenceLine 
                    y={totalDpChangeThreshold} 
                    yAxisId="right" 
                    label={{ value: 'Change', fill: '#ef4444', fontSize: 10, position: 'insideTopLeft' }}
                    stroke="#ef4444" 
                    strokeDasharray="3 3" 
                    strokeWidth={1.5} 
                />

                <Line yAxisId="left" type="monotone" dataKey="particleEfficiency" name="Efficiency" stroke="#4ade80" strokeWidth={2} dot={false} activeDot={{ r: 4 }} />
                <Line yAxisId="right" type="monotone" dataKey="totalDifferentialPressure" name="Total DP" stroke="#f97316" strokeWidth={2} dot={false} activeDot={{ r: 4 }} />
            </LineChart>
        </ResponsiveContainer>
    );
};

export default AhuPerformanceChart;