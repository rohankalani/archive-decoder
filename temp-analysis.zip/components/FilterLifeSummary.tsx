import React from 'react';
import { FilterStage, ParticleSize } from '../types';
import { Shield, Calendar, ChevronsRight, BarChart2 } from 'lucide-react';

interface FilterLifeSummaryProps {
    filterStages: FilterStage[];
    perStageAnalysis: {
        daysInUse: number;
        averageEfficiency: number;
        predictedTotalLife: number;
    }[];
    targetParticleSize: ParticleSize;
}

const MetricCompare: React.FC<{ label: string; advancedValue: string; standardValue: string; }> = ({ label, advancedValue, standardValue }) => (
    <div className="grid grid-cols-2 gap-4 items-center">
        <div className="text-right border-r border-slate-600 pr-4">
             <p className="font-bold text-cyan-400 text-lg">{advancedValue}</p>
        </div>
        <div className="text-left">
            <p className="font-bold text-slate-300 text-lg">{standardValue}</p>
        </div>
        <p className="col-span-2 text-center text-xs text-slate-400 -mt-2">{label}</p>
    </div>
);


const FilterStageCard: React.FC<{ stage: FilterStage; analysis: FilterLifeSummaryProps['perStageAnalysis'][0]; targetParticleSize: ParticleSize; }> = ({ stage, analysis, targetParticleSize }) => {
    
    return (
        <div className="bg-tertiary p-5 rounded-lg flex-1">
            <div className="text-center mb-4">
                <h4 className="text-lg font-bold text-white">{stage.name}</h4>
                <p className="text-sm text-slate-400">{stage.grade} / {stage.type}</p>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-center text-sm font-semibold mb-4">
                <p className="text-cyan-400">RosaiQ™ Advanced Filter</p>
                <p className="text-slate-300">Standard Filter Baseline</p>
            </div>
            
            <div className="space-y-4">
                <MetricCompare 
                    label="Predicted Total Life"
                    advancedValue={`${analysis.predictedTotalLife.toFixed(0)} days`}
                    standardValue={`${stage.standardFilterLifespanDays} days`}
                />
                <MetricCompare 
                    label="Days in Current Cycle"
                    advancedValue={`${analysis.daysInUse} days`}
                    standardValue={`${analysis.daysInUse} days`}
                />
            </div>

            <div className="mt-6 border-t border-slate-700 pt-4">
                <h5 className="text-center font-semibold text-cyan-400 text-sm mb-2">Advanced Filter Performance</h5>
                 <div className="flex items-center justify-center gap-4 bg-slate-800/50 p-3 rounded-lg">
                    <BarChart2 className="w-6 h-6 text-cyan-400"/>
                    <div>
                        <p className="text-2xl font-bold text-white">{analysis.averageEfficiency.toFixed(1)}<span className="text-lg text-slate-400">%</span></p>
                        <p className="text-xs text-slate-400">Avg. Filtration Efficiency @ {targetParticleSize.toUpperCase()}</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

const FilterLifeSummary: React.FC<FilterLifeSummaryProps> = ({ filterStages, perStageAnalysis, targetParticleSize }) => {
    return (
        <div className="flex flex-col md:flex-row gap-6">
            {filterStages.map((stage, index) => (
                <FilterStageCard
                    key={stage.id}
                    stage={stage}
                    analysis={perStageAnalysis[index]}
                    targetParticleSize={targetParticleSize}
                />
            ))}
        </div>
    );
};

export default FilterLifeSummary;