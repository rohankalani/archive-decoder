import React, { useState, useRef } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { Home, Map, Settings, Bell, BarChart3, BookText, Filter, BadgeCheck, FileBarChart, Cloud, Wind, SlidersHorizontal, Shield, Biohazard, MonitorPlay, ScrollText, ChevronDown, AirVent, ShieldCheck, Gem, Landmark } from 'lucide-react';
import { useAlerts } from '../contexts/AlertsContext';
import { useAuth } from '../contexts/AuthContext';
// FIX: Corrected import path for types.
import { UserRole } from '../types';

interface HeaderProps {
    onSettingsClick: () => void;
}

const NavItem: React.FC<{ to: string, title: string, children: React.ReactNode, end?: boolean }> = ({ to, title, children, end }) => {
    return (
        <NavLink
            to={to}
            end={end}
            className={({ isActive }) =>
                `flex items-center gap-2 px-3 py-2 rounded-md transition-colors duration-200 text-sm font-medium ${
                    isActive
                        ? 'bg-accent text-white'
                        : 'text-slate-300 hover:bg-slate-700 hover:text-white'
                }`
            }
        >
            {children}
            <span className="hidden lg:inline">{title}</span>
        </NavLink>
    );
};

const DropdownNavItem: React.FC<{ to: string, title: string, children: React.ReactNode }> = ({ to, title, children }) => {
    return (
        <NavLink
            to={to}
            className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2 rounded-md transition-colors duration-200 text-sm w-full ${
                    isActive ? 'bg-accent text-white' : 'text-slate-300 hover:bg-slate-700 hover:text-white'
                }`
            }
        >
            {children}
            <span>{title}</span>
        </NavLink>
    );
};

const NavDropdown: React.FC<{ title: string; icon: React.ReactNode; children: React.ReactNode; paths: string[] }> = ({ title, icon, children, paths }) => {
    const [isOpen, setIsOpen] = useState(false);
    const location = useLocation();
    const isActive = paths.some(path => location.pathname === path || (path !== "/" && location.pathname.startsWith(path)));
    const timerRef = useRef<number | null>(null);

    const handleMouseEnter = () => {
        if (timerRef.current) {
            clearTimeout(timerRef.current);
            timerRef.current = null;
        }
        setIsOpen(true);
    };

    const handleMouseLeave = () => {
        timerRef.current = window.setTimeout(() => {
            setIsOpen(false);
        }, 200); // 200ms delay before closing
    };


    return (
        <div className="relative" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
            <button
                aria-expanded={isOpen}
                className={`flex items-center gap-2 px-3 py-2 rounded-md transition-colors duration-200 text-sm font-medium ${
                    isActive ? 'bg-accent text-white' : 'text-slate-300 hover:bg-slate-700 hover:text-white'
                }`}
            >
                {icon}
                <span className="hidden lg:inline">{title}</span>
                <ChevronDown className="w-4 h-4 hidden lg:inline" />
            </button>
            {isOpen && (
                <div className="absolute top-full mt-2 left-0 bg-secondary rounded-md shadow-lg p-2 z-50 w-60 animate-fade-in-scale">
                    <div className="flex flex-col gap-1">
                        {children}
                    </div>
                </div>
            )}
        </div>
    );
};


const RoleSwitcher: React.FC = () => {
    const { role, setRole } = useAuth();
    return (
        <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-slate-400"/>
            <select
                value={role}
                onChange={(e) => setRole(e.target.value as UserRole)}
                className="bg-secondary border-none text-white text-sm focus:ring-0 focus:outline-none"
            >
                <option value="admin">Admin</option>
                <option value="user">Standard User</option>
            </select>
        </div>
    )
}

const Header: React.FC<HeaderProps> = ({ onSettingsClick }) => {
    const { alerts } = useAlerts();
    const { role } = useAuth();
    const activeAlertsCount = alerts.filter(a => a.status === 'active').length;

    const liveMonitoringPaths = ["/ahu-monitoring", "/vape-smoke-detection", "/air-purifiers"];
    const reportsPaths = ["/reports", "/green-building-report", "/estidama-report", "/barjeel-report", "/well-report", "/ashrae", "/ashrae-241", "/leed-report", "/reset-report"];

    return (
        <header className="bg-secondary p-4 flex justify-between items-center sticky top-0 z-40 shadow-lg print:hidden">
            {/* Left side: Logo & Title */}
            <div className="flex items-center gap-4">
                <div className="bg-gradient-to-br from-cyan-400 to-sky-600 p-2 rounded-lg">
                    <Wind className="w-6 h-6 text-white" />
                </div>
                <h1 className="text-2xl text-white hidden sm:block">
                    <span className="font-bold">RosaiQ</span>
                    <span className="font-light text-slate-300"> Air OS</span>
                </h1>
            </div>

            {/* Center: Navigation */}
            <nav className="flex items-center gap-1 sm:gap-2">
                <NavItem to="/" title="Dashboard" end>
                    <Home className="w-5 h-5" />
                </NavItem>
                <NavItem to="/floorplan" title="Floor Plan">
                    <Map className="w-5 h-5" />
                </NavItem>
                
                <NavDropdown title="Live Monitoring" icon={<MonitorPlay className="w-5 h-5" />} paths={liveMonitoringPaths}>
                    <DropdownNavItem to="/ahu-monitoring" title="AHU Status"><Filter className="w-5 h-5" /></DropdownNavItem>
                    <DropdownNavItem to="/air-purifiers" title="Connected Air Purifiers"><AirVent className="w-5 h-5" /></DropdownNavItem>
                    <DropdownNavItem to="/vape-smoke-detection" title="Vape/Smoke Events"><Cloud className="w-5 h-5" /></DropdownNavItem>
                </NavDropdown>

                <NavDropdown title="Reports" icon={<ScrollText className="w-5 h-5" />} paths={reportsPaths}>
                    <DropdownNavItem to="/reports" title="Weekly Summary"><BookText className="w-5 h-5" /></DropdownNavItem>
                    <DropdownNavItem to="/green-building-report" title="Dubai Green Building"><ShieldCheck className="w-5 h-5" /></DropdownNavItem>
                    <DropdownNavItem to="/estidama-report" title="Abu Dhabi Estidama"><Gem className="w-5 h-5" /></DropdownNavItem>
                    <DropdownNavItem to="/barjeel-report" title="UAE Barjeel"><Landmark className="w-5 h-5" /></DropdownNavItem>
                    <DropdownNavItem to="/well-report" title="WELL"><FileBarChart className="w-5 h-5" /></DropdownNavItem>
                    <DropdownNavItem to="/ashrae" title="ASHRAE 62.1"><BarChart3 className="w-5 h-5" /></DropdownNavItem>
                    <DropdownNavItem to="/ashrae-241" title="ASHRAE 241"><Biohazard className="w-5 h-5" /></DropdownNavItem>
                    <DropdownNavItem to="/leed-report" title="LEED"><FileBarChart className="w-5 h-5" /></DropdownNavItem>
                    <DropdownNavItem to="/reset-report" title="RESET"><BadgeCheck className="w-5 h-5" /></DropdownNavItem>
                </NavDropdown>
            </nav>

            {/* Right side: Alerts & Settings */}
            <div className="flex items-center gap-2">
                 <RoleSwitcher />
                 <NavLink to="/alerts" className={({isActive}) => `relative flex items-center gap-2 px-3 py-2 rounded-md transition-colors duration-200 text-sm font-medium ${isActive ? 'bg-accent text-white' : 'text-slate-300 hover:bg-slate-700 hover:text-white'}`}>
                    <Bell className="w-5 h-5" />
                    <span className="hidden lg:inline">Alerts</span>
                    {activeAlertsCount > 0 && (
                        <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-xs font-bold text-white">
                            {activeAlertsCount}
                        </span>
                    )}
                </NavLink>
                {role === 'admin' && (
                    <>
                        <NavLink to="/manage" className={({isActive}) => `flex items-center gap-2 px-3 py-2 rounded-md transition-colors duration-200 text-sm font-medium ${isActive ? 'bg-accent text-white' : 'text-slate-300 hover:bg-slate-700 hover:text-white'}`}>
                            <SlidersHorizontal className="w-5 h-5" />
                            <span className="hidden lg:inline">Manage</span>
                        </NavLink>
                         <button onClick={onSettingsClick} className="flex items-center gap-2 px-3 py-2 rounded-md transition-colors duration-200 text-sm font-medium text-slate-300 hover:bg-slate-700 hover:text-white">
                            <Settings className="w-5 h-5" />
                            <span className="hidden lg:inline">Settings</span>
                        </button>
                    </>
                )}
            </div>
        </header>
    );
};

export default Header;