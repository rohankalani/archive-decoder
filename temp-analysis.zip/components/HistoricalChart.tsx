import React, { useState, useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { HistoricalData, Metric, ChartAggregation } from '../types';
import { useSettings } from '../contexts/SettingsContext';
import { format } from 'date-fns';
import { DateRange } from 'react-day-picker';

type MetricDetails = Record<Metric, { name: string, unit: string }>;

const CustomTooltip = ({ active, payload, label, timezone, activeMetric, metricDetails }: any) => {
  if (active && payload && payload.length) {
    const date = new Date(label);
    const dateOptions: Intl.DateTimeFormatOptions = {
        year: 'numeric', month: 'short', day: 'numeric', timeZone: timezone
    };
    const timeOptions: Intl.DateTimeFormatOptions = {
        hour: '2-digit', minute: '2-digit', timeZone: timezone
    };
    const displayTime = `${date.toLocaleDateString(undefined, dateOptions)}, ${date.toLocaleTimeString([], timeOptions)}`;

    const data = payload[0];
    const metricName = metricDetails[activeMetric as Metric]?.name || 'Value';
    const unit = metricDetails[activeMetric as Metric]?.unit || '';

    return (
      <div className="bg-primary/80 backdrop-blur-sm p-3 rounded-md border border-slate-700 space-y-1">
        <p className="text-sm text-slate-300">{`Time: ${displayTime}`}</p>
        <p className="font-semibold" style={{ color: data.fill }}>
            {`${metricName}: ${data.value.toLocaleString(undefined, { maximumFractionDigits: 2 })} ${unit}`}
        </p>
      </div>
    );
  }

  return null;
};

interface HistoricalChartProps {
  data: HistoricalData[];
  metrics: Metric[];
  metricDetails: MetricDetails;
  title: string;
  aggregation: ChartAggregation;
  timezone?: string;
  dateRange?: DateRange;
}

const HistoricalChart: React.FC<HistoricalChartProps> = ({ data, metrics, metricDetails, title, aggregation, timezone, dateRange }) => {
    const { getMetricQuality } = useSettings();
    const [activeMetric, setActiveMetric] = useState<Metric>(metrics[0]);
    
    const yDomain = useMemo(() => {
        if (!data || data.length === 0) return [0, 100];
        let max = -Infinity;
        data.forEach(item => {
            const value = item[activeMetric as keyof HistoricalData] as number;
            if (value > max) max = value;
        });
        if (max === -Infinity) return [0, 100];
        return [0, Math.ceil(max * 1.1)]; // 10% padding on top
    }, [data, activeMetric]);

    if(!data || data.length === 0) {
        return <div className="bg-secondary p-4 sm:p-6 rounded-lg text-center text-slate-500 py-10">No historical data available for this period.</div>;
    }
    
    const formatXAxis = (tickItem: string) => {
        const date = new Date(tickItem);
        // Determine the number of days in the range to format intelligently
        const daysInRange = dateRange?.from && dateRange?.to 
            ? (dateRange.to.getTime() - dateRange.from.getTime()) / (1000 * 3600 * 24)
            : 7;

        if (aggregation === '1d') {
            return format(date, 'MMM d');
        }
        if (daysInRange <= 2) { // If viewing 2 days or less, show time only
            return format(date, 'HH:mm');
        }
        // Otherwise, show date and time for clarity
        return format(date, 'MMM d, HH:mm');
    };

  return (
    <div className="bg-secondary p-4 sm:p-6 rounded-lg">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-4">
          <h3 className="text-xl font-bold text-white">{title}</h3>
          <div className="flex flex-wrap gap-2">
              {metrics.map(metric => {
                  const metricDetail = metricDetails[metric];
                  if (!metricDetail) return null;
                  return (
                  <button
                      key={metric}
                      onClick={() => setActiveMetric(metric)}
                      className={`px-3 py-1 text-sm font-semibold rounded-full transition-all duration-200 ${
                          activeMetric === metric
                              ? 'bg-accent text-white shadow-md'
                              : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                      }`}
                      aria-pressed={activeMetric === metric}
                  >
                      {metricDetail.name}
                  </button>
              )})}
          </div>
      </div>
      
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }} barCategoryGap="20%">
          <CartesianGrid strokeDasharray="3 3" stroke="#475569" strokeOpacity={0.5} />
          <XAxis 
              dataKey="timestamp" 
              tickFormatter={formatXAxis}
              stroke="#94a3b8"
              tick={{ fontSize: 12 }}
              interval="preserveStartEnd"
          />
          <YAxis 
              stroke="#94a3b8"
              tick={{ fontSize: 12 }}
              domain={yDomain}
              allowDataOverflow={true}
              type="number"
          />
          <Tooltip content={<CustomTooltip timezone={timezone} activeMetric={activeMetric} metricDetails={metricDetails} />} cursor={{fill: 'rgba(100, 116, 139, 0.2)'}} />
          <Bar dataKey={activeMetric} name={metricDetails[activeMetric]?.name} radius={[4, 4, 0, 0]}>
            {data.map((entry, index) => {
                const value = entry[activeMetric as keyof HistoricalData] as number;
                const { color } = getMetricQuality(activeMetric, data[index][activeMetric as keyof HistoricalData] as number);
                return <Cell key={`cell-${index}`} fill={color} />;
            })}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default HistoricalChart;