import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Header from './Header';
import SettingsModal from './SettingsModal';

const Layout: React.FC = () => {
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  return (
    <div className="min-h-screen bg-primary flex flex-col">
      <Header onSettingsClick={() => setIsSettingsOpen(true)} />
      <main className="flex-grow p-4 sm:p-6 lg:p-8">
        <Outlet />
      </main>
      <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
    </div>
  );
};

export default Layout;