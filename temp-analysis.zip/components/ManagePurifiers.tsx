import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { DeviceWithData, Location, AirPurifierConfig } from '../types';
import { Plus, Trash2, Edit2, X, Loader2, Info, Wind } from 'lucide-react';
import { updateAirPurifierConfig, addDevice, deleteDevice, getDevices, getAirPurifierConfigs, getLocations } from '../services/apiService';

const CEILING_HEIGHT_FT = 8; // Standard assumption

interface ManagePurifiersProps {
    onDataChanged: () => void;
}

const ConfigModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSave: (config: AirPurifierConfig) => Promise<void>;
    purifier: DeviceWithData;
    initialConfig: AirPurifierConfig | undefined;
}> = ({ isOpen, onClose, onSave, purifier, initialConfig }) => {
    const [config, setConfig] = useState<AirPurifierConfig>(() => 
        initialConfig || {
            deviceId: purifier.id,
            cadr: 150,
            roomArea: null,
            autoMode: {
                enabled: true,
                occupancyRequired: true,
                pm25Threshold: 12,
                vocThreshold: 200,
            }
        }
    );
    const [isSubmitting, setIsSubmitting] = useState(false);
    
    useEffect(() => {
        setConfig(initialConfig || {
            deviceId: purifier.id,
            cadr: 150,
            roomArea: null,
            autoMode: {
                enabled: true,
                occupancyRequired: true,
                pm25Threshold: 12,
                vocThreshold: 200,
            }
        });
    }, [initialConfig, purifier.id]);

    const ach = useMemo(() => {
        if (!config.cadr || !config.roomArea || config.roomArea === 0) return 0;
        const volume = config.roomArea * CEILING_HEIGHT_FT;
        if (volume === 0) return 0;
        return (config.cadr * 60) / volume;
    }, [config.cadr, config.roomArea]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        await onSave(config);
        setIsSubmitting(false);
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4">
            <div className="bg-secondary rounded-lg shadow-xl w-full max-w-lg" onClick={e => e.stopPropagation()}>
                <form onSubmit={handleSubmit}>
                    <div className="p-5 border-b border-slate-700 flex justify-between items-center">
                        <div>
                            <h2 className="text-xl font-bold text-white">Configure Purifier</h2>
                            <p className="text-sm text-cyan-400">{purifier.name}</p>
                        </div>
                        <button type="button" onClick={onClose} className="text-slate-400 hover:text-white"><X size={24} /></button>
                    </div>
                    <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                        <div className="grid grid-cols-2 gap-4">
                            <div><label className="text-sm text-slate-300">Room Area (sq ft)</label><input type="number" value={config.roomArea ?? ''} onChange={e => setConfig(c => ({...c, roomArea: e.target.value ? Number(e.target.value) : null}))} className="w-full bg-tertiary mt-1 p-2 rounded border border-slate-600"/></div>
                            <div><label className="text-sm text-slate-300">Device CADR (CFM)</label><input type="number" value={config.cadr} onChange={e => setConfig(c => ({...c, cadr: Number(e.target.value)}))} className="w-full bg-tertiary mt-1 p-2 rounded border border-slate-600"/></div>
                        </div>
                         <div className="bg-tertiary p-3 rounded-lg text-center">
                            <p className="text-xs text-slate-400 flex items-center justify-center gap-2"><Wind size={14} />Calculated Air Changes per Hour</p>
                            <p className="text-2xl font-bold text-cyan-400">{ach.toFixed(1)} ACH</p>
                        </div>
                        <div>
                            <h3 className="text-lg font-semibold text-white mb-2">Auto Mode Settings</h3>
                            <div className="space-y-3 bg-tertiary p-4 rounded-lg">
                                <label className="flex items-center gap-3"><input type="checkbox" checked={config.autoMode.enabled} onChange={e => setConfig(c => ({...c, autoMode: {...c.autoMode, enabled: e.target.checked}}))} className="w-5 h-5 accent-accent"/><span>Enable Auto Mode</span></label>
                                <label className="flex items-center gap-3"><input type="checkbox" checked={config.autoMode.occupancyRequired} onChange={e => setConfig(c => ({...c, autoMode: {...c.autoMode, occupancyRequired: e.target.checked}}))} className="w-5 h-5 accent-accent"/><span>Require Occupancy to Activate</span></label>
                                <div className="grid grid-cols-2 gap-4 pt-2">
                                    <div><label className="text-sm text-slate-300">PM2.5 Threshold (µg/m³)</label><input type="number" value={config.autoMode.pm25Threshold ?? ''} onChange={e => setConfig(c => ({...c, autoMode: {...c.autoMode, pm25Threshold: e.target.value ? Number(e.target.value) : null}}))} className="w-full bg-slate-800 mt-1 p-2 rounded border border-slate-600"/></div>
                                    <div><label className="text-sm text-slate-300">VOC Threshold (index)</label><input type="number" value={config.autoMode.vocThreshold ?? ''} onChange={e => setConfig(c => ({...c, autoMode: {...c.autoMode, vocThreshold: e.target.value ? Number(e.target.value) : null}}))} className="w-full bg-slate-800 mt-1 p-2 rounded border border-slate-600"/></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="p-5 border-t border-slate-700 flex justify-end gap-3">
                        <button type="button" onClick={onClose} className="px-4 py-2 rounded-md bg-slate-600">Cancel</button>
                        <button type="submit" disabled={isSubmitting} className="px-4 py-2 rounded-md bg-accent hover:bg-accent-dark disabled:bg-slate-500 flex items-center gap-2">
                            {isSubmitting && <Loader2 className="animate-spin" size={16} />} Save
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const AddDeviceModal: React.FC<{
    isOpen: boolean; onClose: () => void; onSave: (name: string, locationId: number) => Promise<void>; locations: Location[]
}> = ({ isOpen, onClose, onSave, locations }) => {
    const [name, setName] = useState('');
    const [locationId, setLocationId] = useState<number | ''>(locations[0]?.id ?? '');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if(!name || !locationId) return;
        setIsSubmitting(true);
        await onSave(name, locationId);
        setIsSubmitting(false);
        onClose();
    };
    if(!isOpen) return null;
    return (
         <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4">
            <div className="bg-secondary rounded-lg shadow-xl w-full max-w-md" onClick={e => e.stopPropagation()}>
                <form onSubmit={handleSubmit}>
                    <div className="p-5 border-b border-slate-700 flex justify-between items-center"><h2 className="text-xl font-bold text-white">Add New Air Purifier</h2><button type="button" onClick={onClose} className="text-slate-400 hover:text-white"><X size={24} /></button></div>
                    <div className="p-6 space-y-4">
                        <div><label className="text-sm text-slate-300">Device Name</label><input type="text" value={name} onChange={e => setName(e.target.value)} required className="w-full bg-tertiary mt-1 p-2 rounded border border-slate-600"/></div>
                        <div><label className="text-sm text-slate-300">Location</label><select value={locationId} onChange={e => setLocationId(Number(e.target.value))} required className="w-full bg-tertiary mt-1 p-2 rounded border border-slate-600"><option value="" disabled>Select a location</option>{locations.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}</select></div>
                    </div>
                    <div className="p-5 border-t border-slate-700 flex justify-end gap-3"><button type="button" onClick={onClose} className="px-4 py-2 rounded-md bg-slate-600">Cancel</button><button type="submit" disabled={isSubmitting} className="px-4 py-2 rounded-md bg-accent hover:bg-accent-dark disabled:bg-slate-500 flex items-center gap-2">{isSubmitting && <Loader2 className="animate-spin" size={16}/>}Add Device</button></div>
                </form>
            </div>
        </div>
    )
}

const ManagePurifiers: React.FC<ManagePurifiersProps> = ({ onDataChanged }) => {
    const [purifiers, setPurifiers] = useState<DeviceWithData[]>([]);
    const [configs, setConfigs] = useState<AirPurifierConfig[]>([]);
    const [locations, setLocations] = useState<Location[]>([]);
    const [loading, setLoading] = useState(true);
    const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [selectedPurifier, setSelectedPurifier] = useState<DeviceWithData | null>(null);
    
    const fetchData = useCallback(async () => {
        setLoading(true);
        const [devicesData, configsData, locationsData] = await Promise.all([
            getDevices(),
            getAirPurifierConfigs(),
            getLocations()
        ]);
        setPurifiers(devicesData.filter(d => d.type === 'air-purifier'));
        setConfigs(configsData);
        setLocations(locationsData);
        setLoading(false);
    }, []);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const handleOpenConfig = (purifier: DeviceWithData) => {
        setSelectedPurifier(purifier);
        setIsConfigModalOpen(true);
    };

    const handleSaveConfig = async (config: AirPurifierConfig) => {
        await updateAirPurifierConfig(config);
        await fetchData();
        onDataChanged();
    };
    
    const handleAddDevice = async (name: string, locationId: number) => {
        await addDevice(name, locationId, 'air-purifier');
        await fetchData();
        onDataChanged();
    };

    const handleDelete = async (deviceId: string) => {
        if(window.confirm("Are you sure you want to delete this air purifier?")) {
            await deleteDevice(deviceId);
            await fetchData();
            onDataChanged();
        }
    };

    if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>;

    return (
        <div className="bg-tertiary p-6 rounded-lg shadow-inner">
            {selectedPurifier && <ConfigModal isOpen={isConfigModalOpen} onClose={() => setIsConfigModalOpen(false)} onSave={handleSaveConfig} purifier={selectedPurifier} initialConfig={configs.find(c => c.deviceId === selectedPurifier.id)} />}
            <AddDeviceModal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} onSave={handleAddDevice} locations={locations} />

            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-white">Air Purifiers</h2>
                <button onClick={() => setIsAddModalOpen(true)} className="flex items-center gap-2 px-4 py-2 rounded-md text-white bg-accent hover:bg-accent-dark"><Plus size={20}/>Add Purifier</button>
            </div>
            <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
                {purifiers.map(purifier => {
                    const config = configs.find(c => c.deviceId === purifier.id);
                    return (
                        <div key={purifier.id} className="bg-secondary p-4 rounded-md flex justify-between items-center">
                            <div>
                                <p className="font-semibold text-white">{purifier.name}</p>
                                <p className="text-sm text-slate-400">{purifier.location.name} - {config?.roomArea ? `${config.roomArea} sq ft` : 'Unconfigured'}</p>
                            </div>
                            <div className="flex items-center gap-3">
                                <button onClick={() => handleOpenConfig(purifier)} className="text-slate-400 hover:text-white"><Edit2 size={20}/></button>
                                <button onClick={() => handleDelete(purifier.id)} className="text-slate-400 hover:text-red-500"><Trash2 size={20}/></button>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default ManagePurifiers;