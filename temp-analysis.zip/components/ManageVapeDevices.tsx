import React, { useState, useEffect, useCallback } from 'react';
import { getDevices, getLocations, addDevice, updateDevice, deleteDevice } from '../services/apiService';
import { DeviceWithData, Location } from '../types';
import { Plus, Trash2, Edit, X, Loader2 } from 'lucide-react';

interface ManageVapeDevicesProps {
    onDataChanged: () => void;
}

const ManageVapeDevices: React.FC<ManageVapeDevicesProps> = ({ onDataChanged }) => {
    const [devices, setDevices] = useState<DeviceWithData[]>([]);
    const [locations, setLocations] = useState<Location[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const [isDeviceModalOpen, setIsDeviceModalOpen] = useState(false);
    const [editingDevice, setEditingDevice] = useState<DeviceWithData | null>(null);
    const [newDeviceName, setNewDeviceName] = useState('');
    const [selectedLocation, setSelectedLocation] = useState<number | ''>('');
    
    const [isSubmitting, setIsSubmitting] = useState(false);

    const fetchData = useCallback(async () => {
        try {
            setLoading(true);
            setError(null);
            const [devicesData, locationsData] = await Promise.all([getDevices(), getLocations()]);
            setDevices(devicesData.filter(d => d.type === 'vape-smoke'));
            setLocations(locationsData);
        } catch (err) {
            setError("Failed to load management data. Please try again.");
            console.error(err);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const openAddDeviceModal = () => {
        setEditingDevice(null);
        setNewDeviceName('');
        setSelectedLocation(locations.length > 0 ? locations[0].id : '');
        setIsDeviceModalOpen(true);
    };

    const openEditDeviceModal = (device: DeviceWithData) => {
        setEditingDevice(device);
        setNewDeviceName(device.name);
        setSelectedLocation(device.location_id);
        setIsDeviceModalOpen(true);
    };
    
    const handleDeviceSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newDeviceName || selectedLocation === '') return;
        setIsSubmitting(true);
        try {
            if (editingDevice) {
                await updateDevice(editingDevice.id, newDeviceName, selectedLocation as number);
            } else {
                await addDevice(newDeviceName, selectedLocation as number, 'vape-smoke');
            }
            setIsDeviceModalOpen(false);
            fetchData();
            onDataChanged();
        } catch (err) {
            console.error("Failed to save device", err);
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleDeleteDevice = async (id: string) => {
        if (window.confirm('Are you sure you want to delete this device?')) {
            try {
                await deleteDevice(id);
                fetchData();
                onDataChanged();
            } catch (err) {
                console.error('Failed to delete device', err);
            }
        }
    };
    
    if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>;
    if (error) return <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error}</div>;

    return (
        <div className="bg-tertiary p-6 rounded-lg shadow-inner">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-white">Vape/Smoke Detectors</h2>
                <button onClick={openAddDeviceModal} className="flex items-center gap-2 px-4 py-2 rounded-md text-white bg-accent hover:bg-accent-dark">
                    <Plus className="w-5 h-5" /> Add Detector
                </button>
            </div>
            <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
                {devices.map(device => (
                    <div key={device.id} className="bg-secondary p-4 rounded-md flex justify-between items-center">
                        <div>
                            <p className="font-semibold text-white">{device.name}</p>
                            <p className="text-sm text-slate-400">{device.location.name}</p>
                        </div>
                        <div className="flex items-center gap-3">
                            <button onClick={() => openEditDeviceModal(device)} className="text-slate-400 hover:text-white"><Edit className="w-5 h-5" /></button>
                            <button onClick={() => handleDeleteDevice(device.id)} className="text-slate-400 hover:text-red-500"><Trash2 className="w-5 h-5" /></button>
                        </div>
                    </div>
                ))}
                {devices.length === 0 && <p className="text-slate-400 text-center py-4">No vape/smoke detectors configured.</p>}
            </div>
            
            {isDeviceModalOpen && (
                 <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4 animate-fade-in-scale">
                    <div className="bg-secondary rounded-lg shadow-xl w-full max-w-md">
                        <form onSubmit={handleDeviceSubmit}>
                            <div className="p-5 border-b border-slate-700 flex justify-between items-center"><h2 className="text-xl font-bold text-white">{editingDevice ? 'Edit Detector' : 'Add Vape/Smoke Detector'}</h2><button type="button" onClick={() => setIsDeviceModalOpen(false)} className="text-slate-400 hover:text-white"><X className="w-6 h-6" /></button></div>
                            <div className="p-5 space-y-4">
                                <div><label htmlFor="device-name" className="block text-sm font-medium text-slate-300 mb-1">Detector Name</label><input id="device-name" type="text" value={newDeviceName} onChange={e => setNewDeviceName(e.target.value)} required className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" /></div>
                                <div><label htmlFor="location-select" className="block text-sm font-medium text-slate-300 mb-1">Location</label><select id="location-select" value={selectedLocation} onChange={e => setSelectedLocation(Number(e.target.value))} required className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white"><option value="" disabled>Select a location</option>{locations.map(loc => <option key={loc.id} value={loc.id}>{loc.name}</option>)}</select></div>
                            </div>
                            <div className="p-5 border-t border-slate-700 flex justify-end gap-3"><button type="button" onClick={() => setIsDeviceModalOpen(false)} className="px-4 py-2 rounded-md text-white bg-slate-600 hover:bg-slate-500">Cancel</button><button type="submit" disabled={isSubmitting} className="px-4 py-2 rounded-md text-white bg-accent hover:bg-accent-dark disabled:bg-slate-500 flex items-center gap-2">{isSubmitting && <Loader2 className="w-4 h-4 animate-spin"/>}{editingDevice ? 'Save Changes' : 'Add Detector'}</button></div>
                        </form>
                    </div>
                 </div>
            )}
        </div>
    );
};

export default ManageVapeDevices;