import React from 'react';

interface MetricDisplayProps {
  label: string;
  value: number | null | undefined;
  unit: string;
  color?: string;
  size?: 'normal' | 'small';
}

const MetricDisplay: React.FC<MetricDisplayProps> = ({ label, value, unit, color, size = 'normal' }) => {
  const isSmall = size === 'small';
  const isValueValid = value !== null && value !== undefined && !isNaN(value);

  return (
    <div>
      <div className="flex items-center space-x-2 mb-1">
        {color && <div className={`rounded-full ${isSmall ? 'w-2 h-2' : 'w-2.5 h-2.5'}`} style={{ backgroundColor: color }}></div>}
        <p className={`${isSmall ? 'text-xs' : 'text-sm'} text-slate-400`}>{label}</p>
      </div>
      <div className="flex items-baseline">
        {isValueValid ? (
          <>
            <p className={`${isSmall ? 'text-lg' : 'text-2xl'} font-bold leading-tight text-white`}>{value.toLocaleString()}</p>
            <p className={`${isSmall ? 'text-xs' : 'text-sm'} text-slate-400 ml-1`}>{unit}</p>
          </>
        ) : (
          <>
            <p className={`${isSmall ? 'text-lg' : 'text-2xl'} font-bold leading-tight text-slate-500`}>--</p>
            <p className={`${isSmall ? 'text-xs' : 'text-sm'} text-slate-500 ml-1`}>{unit}</p>
          </>
        )}
      </div>
    </div>
  );
};

export default MetricDisplay;