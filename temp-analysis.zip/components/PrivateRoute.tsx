import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const PrivateRoute: React.FC = () => {
  const { role } = useAuth();

  if (role !== 'admin') {
    // Redirect non-admin users to the home page
    return <Navigate to="/" replace />;
  }

  return <Outlet />;
};

export default PrivateRoute;
