import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { useSettings, AQI_POLLUTANTS, AQI_LEVELS } from '../contexts/SettingsContext';
// FIX: Corrected import path for types.
import { Metric, Thresholds, UnitSystem, BreakpointTable, AqiLevel } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// FIX: Added 'dp', 'presence', 'smoke_vape_detected', 'fan_speed', and 'filter_life' to satisfy the Record<Metric, string> type.
const metricLabels: Record<Metric, string> = {
    iaqi: 'IAQI', pm25: 'PM2.5', co2: 'CO₂', temp: 'Temperature', humidity: 'Humidity',
    voc: 'VOC', hcho: 'Formaldehyde (HCHO)', nox: 'NOx', pm03: 'PM0.3', pm1: 'PM1',
    pm5: 'PM5', pm10: 'PM10', pc03: 'PC0.3', pc05: 'PC0.5', pc1: 'PC1',
    pc25: 'PC2.5', pc5: 'PC5', pc10: 'PC10',
    occupancy: 'Occupancy',
    presence: 'Presence',
    dp: 'Differential Pressure',
    smoke_vape_detected: 'Smoke/Vape Detection',
    battery: 'Battery Level',
    fan_speed: 'Fan Speed',
    filter_life: 'Filter Life',
};

const SimpleThresholdEditor: React.FC<{
    currentThresholds: Thresholds;
    onThresholdChange: (level: keyof Thresholds, value: string) => void;
}> = ({ currentThresholds, onThresholdChange }) => (
    <div className="space-y-3">
        <p className="text-slate-400 text-sm">Set the upper bounds for each quality level.</p>
        <div>
            <label htmlFor="good-threshold" className="block text-sm font-medium text-green-400">Good</label>
            <input type="number" id="good-threshold" value={currentThresholds.good} onChange={(e) => onThresholdChange('good', e.target.value)} className="mt-1 w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" />
        </div>
        <div>
            <label htmlFor="moderate-threshold" className="block text-sm font-medium text-yellow-400">Moderate</label>
            <input type="number" id="moderate-threshold" value={currentThresholds.moderate} onChange={(e) => onThresholdChange('moderate', e.target.value)} className="mt-1 w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" />
        </div>
        <div>
            <label htmlFor="poor-threshold" className="block text-sm font-medium text-orange-500">Poor</label>
            <input type="number" id="poor-threshold" value={currentThresholds.poor} onChange={(e) => onThresholdChange('poor', e.target.value)} className="mt-1 w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" />
        </div>
    </div>
);

const IaqiThresholdEditor: React.FC<{
    thresholds: number[];
    onThresholdChange: (index: number, value: string) => void;
}> = ({ thresholds, onThresholdChange }) => {
    const levels = Object.keys(AQI_LEVELS) as AqiLevel[];
    return (
        <div className="space-y-3">
            <p className="text-slate-400 text-sm">Set the upper AQI value for each quality level.</p>
            {levels.slice(0, 5).map((levelName, index) => { // Only need to edit 5 upper bounds
                const levelInfo = AQI_LEVELS[levelName];
                return (
                    <div key={levelName}>
                        <label htmlFor={`${levelName}-threshold`} className="block text-sm font-medium" style={{ color: levelInfo.color }}>
                            {levelName} (up to)
                        </label>
                        <input
                            type="number"
                            id={`${levelName}-threshold`}
                            value={thresholds[index]}
                            onChange={(e) => onThresholdChange(index, e.target.value)}
                            className="mt-1 w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white"
                        />
                    </div>
                );
            })}
             <div className="flex items-center gap-2 p-2 bg-tertiary rounded text-sm">
                <span className="font-semibold" style={{color: AQI_LEVELS['Hazardous'].color}}>Hazardous</span>
                <span className="text-slate-300">({'>'} {thresholds[4]})</span>
             </div>
        </div>
    );
};

const BreakpointEditor: React.FC<{
    breakpointTable: BreakpointTable;
    onTableChange: (newTable: BreakpointTable) => void;
}> = ({ breakpointTable, onTableChange }) => {

    const handleConcentrationChange = (index: number, boundIndex: 0 | 1, value: string) => {
        const numericValue = parseFloat(value);
        if (isNaN(numericValue)) return;

        const newTable = JSON.parse(JSON.stringify(breakpointTable));
        newTable[index][boundIndex] = numericValue;
        
        // If editing an upper bound, update the lower bound of the next level
        if (boundIndex === 1 && index < newTable.length - 1) {
            // A small increment, assuming floating point precision is desired
            const increment = value.includes('.') ? 0.1 : 1;
            newTable[index + 1][0] = parseFloat((numericValue + increment).toFixed(1));
        }

        onTableChange(newTable);
    };

    return (
        <div className="space-y-2">
            <p className="text-slate-400 text-sm">Set the concentration ranges for each AQI level.</p>
             <div className="grid grid-cols-4 gap-x-3 text-xs font-semibold text-slate-400 px-2">
                <span>Level</span>
                <span>AQI Range</span>
                <span className="col-span-2 text-center">Concentration Range</span>
            </div>
            {breakpointTable.map((row, index) => {
                const levelInfo = Object.values(AQI_LEVELS)[index];
                const levelName = Object.keys(AQI_LEVELS)[index] as AqiLevel;
                return (
                    <div key={index} className="grid grid-cols-4 items-center gap-x-3 text-sm p-2 bg-tertiary rounded">
                        <span style={{ color: levelInfo.color }} className="font-semibold">{levelName}</span>
                        <span className="text-slate-300 text-center">{levelInfo.range}</span>
                        <div className="col-span-2 flex items-center gap-2">
                            <input
                                type="number"
                                step="0.1"
                                value={row[0]}
                                onChange={(e) => handleConcentrationChange(index, 0, e.target.value)}
                                className="w-full bg-slate-800 border border-slate-600 rounded-md px-2 py-1 text-white text-center"
                                disabled={index > 0} // Only first lower bound is editable
                            />
                            <span>-</span>
                            <input
                                type="number"
                                step="0.1"
                                value={row[1]}
                                onChange={(e) => handleConcentrationChange(index, 1, e.target.value)}
                                className="w-full bg-slate-800 border border-slate-600 rounded-md px-2 py-1 text-white text-center"
                            />
                        </div>
                    </div>
                );
            })}
        </div>
    );
};

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const { 
      thresholds, updateThresholds,
      unitSystem, setUnitSystem,
      breakpoints, updateBreakpoints,
      iaqiThresholds, updateIaqiThresholds
  } = useSettings();

  const [selectedMetric, setSelectedMetric] = useState<Metric>('iaqi');
  const [isAqiMetric, setIsAqiMetric] = useState(false);
  
  // Local state for editors
  const [localThresholds, setLocalThresholds] = useState<Thresholds>(thresholds[selectedMetric]);
  const [localBreakpoints, setLocalBreakpoints] = useState<BreakpointTable>(breakpoints[selectedMetric]);
  const [localIaqiThresholds, setLocalIaqiThresholds] = useState<number[]>(iaqiThresholds);

  useEffect(() => {
    const isAqi = AQI_POLLUTANTS.includes(selectedMetric);
    setIsAqiMetric(isAqi);
    if (selectedMetric === 'iaqi') {
        setLocalIaqiThresholds(iaqiThresholds);
    } else if (isAqi) {
        setLocalBreakpoints(breakpoints[selectedMetric]);
    } else {
        setLocalThresholds(thresholds[selectedMetric]);
    }
  }, [selectedMetric, thresholds, breakpoints, iaqiThresholds]);

  const handleSave = () => {
      if (selectedMetric === 'iaqi') {
          updateIaqiThresholds(localIaqiThresholds);
      } else if (isAqiMetric) {
          updateBreakpoints(selectedMetric, localBreakpoints);
      } else {
          updateThresholds(selectedMetric, localThresholds);
      }
      // In a real app, you might want to show a success toast here.
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4">
      <div className="bg-secondary rounded-lg shadow-xl w-full max-w-lg animate-fade-in-scale">
        <div className="p-5 border-b border-slate-700 flex justify-between items-center">
          <h2 className="text-xl font-bold text-white">Settings</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>
        <div className="p-5 space-y-6 max-h-[70vh] overflow-y-auto">
            <div>
                <h3 className="text-lg font-semibold text-white mb-2">Unit System</h3>
                <p className="text-slate-400 text-sm mb-3">Select the unit for particle count measurements. This is typically set once per customer.</p>
                <div className="flex gap-4 p-1 bg-tertiary rounded-full">
                    <button onClick={() => setUnitSystem('imperial')} className={`flex-1 text-center py-2 px-4 rounded-full text-sm font-semibold transition-colors ${unitSystem === 'imperial' ? 'bg-accent text-white' : 'hover:bg-slate-600'}`}>
                        Imperial (#/ft³)
                    </button>
                    <button onClick={() => setUnitSystem('metric')} className={`flex-1 text-center py-2 px-4 rounded-full text-sm font-semibold transition-colors ${unitSystem === 'metric' ? 'bg-accent text-white' : 'hover:bg-slate-600'}`}>
                        Metric (#/m³)
                    </button>
                </div>
            </div>

            <div className="border-t border-slate-700 my-4"></div>

            <div>
                <label htmlFor="metric-select" className="block text-lg font-semibold text-white mb-2">
                    Metric Thresholds
                </label>
                <select
                    id="metric-select"
                    value={selectedMetric}
                    onChange={(e) => setSelectedMetric(e.target.value as Metric)}
                    className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-accent-dark focus:outline-none mb-4"
                >
                    {Object.keys(metricLabels).map(key => (
                        <option key={key} value={key}>{metricLabels[key as Metric]}</option>
                    ))}
                </select>

                {selectedMetric === 'iaqi' ? (
                    <IaqiThresholdEditor 
                        thresholds={localIaqiThresholds}
                        onThresholdChange={(index, value) => {
                            const newThresholds = [...localIaqiThresholds];
                            newThresholds[index] = Number(value);
                            setLocalIaqiThresholds(newThresholds);
                        }}
                    />
                ) : isAqiMetric ? (
                    <BreakpointEditor breakpointTable={localBreakpoints} onTableChange={setLocalBreakpoints} />
                ) : (
                    <SimpleThresholdEditor currentThresholds={localThresholds} onThresholdChange={(level, value) => setLocalThresholds(p => ({...p, [level]: Number(value)}))} />
                )}
            </div>

        </div>
        <div className="p-5 border-t border-slate-700 flex justify-end gap-3">
            <button onClick={onClose} className="px-4 py-2 rounded-md text-white bg-slate-600 hover:bg-slate-500 transition-colors">
                Cancel
            </button>
            <button onClick={handleSave} className="px-4 py-2 rounded-md text-white bg-accent hover:bg-accent-dark transition-colors">
                Save Changes
            </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;
