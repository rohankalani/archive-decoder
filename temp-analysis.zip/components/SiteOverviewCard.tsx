import React, { useState } from 'react';
import { Globe, DollarSign, FileText, BarChart2, Biohazard, ArrowUp, ArrowDown, Minus, Zap, Building } from 'lucide-react';
import { MajorPollutant } from '../types';

type ComplianceStandard = 'leed' | 'well' | 'reset';

export interface EnhancedSiteData {
    name: string;
    deviceCount: number;
    avgAqi30d: number;
    aqiQuality: { color: string };
    dominantPollutant30d: MajorPollutant | null;
    aqiTrendVsLastYear: 'improving' | 'steady' | 'worsening';
    cumulativeEnergySavingsKwh: number;
    cumulativeTcoSavings: number;
    compliance: {
        ashrae62: number;
        ashrae241: number;
        leed: number;
        well: number;
        reset: number;
    };
}

export type OverviewData = EnhancedSiteData & { level: 'site' | 'building' };

interface SiteOverviewCardProps {
  data: OverviewData;
  onViewBuildingsClick?: () => void;
  onSiteDetailsClick: () => void;
}

const Tooltip: React.FC<{ text: string }> = ({ text }) => (
    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 p-2 text-xs text-center text-white bg-slate-900 border border-slate-700 rounded-md shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none z-10">
        {text}
    </div>
);

const MetricDisplay: React.FC<{ icon: React.ReactNode; value: string; label: string; tooltipText: string; }> = ({ icon, value, label, tooltipText }) => (
    <div className="relative group flex items-center gap-3">
        <div className="flex-shrink-0 w-6 h-6 flex items-center justify-center text-cyan-400">{icon}</div>
        <div>
            <p className="font-bold text-white leading-tight">{value}</p>
            <p className="text-xs text-slate-400 leading-tight">{label}</p>
        </div>
        <Tooltip text={tooltipText} />
    </div>
);

const SiteOverviewCard: React.FC<SiteOverviewCardProps> = ({ data, onViewBuildingsClick, onSiteDetailsClick }) => {
    const [selectedStandard, setSelectedStandard] = useState<ComplianceStandard>('leed');

    const TrendIcon = {
        improving: <ArrowUp className="w-4 h-4 text-green-400" />,
        steady: <Minus className="w-4 h-4 text-slate-400" />,
        worsening: <ArrowDown className="w-4 h-4 text-red-400" />,
    }[data.aqiTrendVsLastYear];
    
    const standardTooltips: Record<ComplianceStandard, string> = {
        leed: "Leadership in Energy and Environmental Design: A green building certification program focusing on sustainability.",
        well: "A performance-based system for measuring, certifying, and monitoring features of the built environment that impact human health.",
        reset: "A sensor-based standard for monitoring and communicating the health performance of buildings in real-time."
    };

    return (
        <div className="bg-secondary rounded-lg shadow-lg flex p-6 gap-6 relative overflow-hidden border border-slate-800">
            <div className="absolute left-0 top-0 bottom-0 w-1.5" style={{ backgroundColor: data.aqiQuality.color }}></div>
            
            <div className="flex-grow space-y-4 flex flex-col">
                <div className="flex items-center gap-3">
                    {data.level === 'site' 
                        ? <Globe className="w-8 h-8 text-slate-400 flex-shrink-0" />
                        : <Building className="w-8 h-8 text-slate-400 flex-shrink-0" />
                    }
                    <div>
                        <h3 className="text-xl font-bold text-white">{data.name}</h3>
                        <p className="text-sm text-slate-400">{data.deviceCount} Devices</p>
                    </div>
                </div>

                <div className="space-y-4 text-sm flex-grow">
                    <div className="grid grid-cols-2 gap-x-4 gap-y-4">
                        <MetricDisplay icon={<BarChart2 size={20}/>} value={`${data.compliance.ashrae62.toFixed(0)}%`} label="ASHRAE 62.1" tooltipText="Measures ventilation effectiveness based on CO₂ levels and occupant density to ensure occupant comfort and well-being."/>
                        <MetricDisplay icon={<Biohazard size={20} />} value={`${data.compliance.ashrae241.toFixed(0)}%`} label="ASHRAE 241" tooltipText="Assesses a building's readiness to control infectious aerosols through ventilation, filtration, and air cleaning."/>
                        <MetricDisplay icon={<Zap size={20}/>} value={`${data.cumulativeEnergySavingsKwh.toLocaleString(undefined, {maximumFractionDigits: 0})}`} label="Energy Saved (kWh)" tooltipText="Total annual energy saved by using advanced filters compared to standard filters."/>
                        <MetricDisplay icon={<DollarSign size={20}/>} value={`$${data.cumulativeTcoSavings.toLocaleString(undefined, {maximumFractionDigits: 0})}`} label="Annual TCO Saved" tooltipText="Total Cost of Ownership savings, including energy and filter replacement costs, over the last year."/>
                    </div>
                     <div className="pt-2">
                         <div className="relative group">
                            <div className="bg-tertiary p-1 rounded-full flex justify-between text-xs font-semibold">
                                <button onClick={() => setSelectedStandard('leed')} className={`flex-1 text-center py-1 rounded-full transition-colors ${selectedStandard === 'leed' ? 'bg-accent text-white shadow-md' : 'text-slate-300 hover:bg-slate-600'}`}>LEED</button>
                                <button onClick={() => setSelectedStandard('well')} className={`flex-1 text-center py-1 rounded-full transition-colors ${selectedStandard === 'well' ? 'bg-accent text-white shadow-md' : 'text-slate-300 hover:bg-slate-600'}`}>WELL</button>
                                <button onClick={() => setSelectedStandard('reset')} className={`flex-1 text-center py-1 rounded-full transition-colors ${selectedStandard === 'reset' ? 'bg-accent text-white shadow-md' : 'text-slate-300 hover:bg-slate-600'}`}>RESET</button>
                            </div>
                             <Tooltip text={standardTooltips[selectedStandard]} />
                        </div>
                        <div className="flex items-center gap-3 mt-2 pl-1">
                            <FileText size={20} className="text-cyan-400" />
                            <div>
                                <p className="font-bold text-white">{data.compliance[selectedStandard].toFixed(0)}%</p>
                                <p className="text-xs text-slate-400 capitalize">{selectedStandard} Compliance</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="flex items-center gap-2 pt-2">
                    {data.level === 'site' && (
                        <button onClick={onViewBuildingsClick} className="w-full text-center py-2 px-4 rounded-md text-sm font-semibold transition-colors bg-accent hover:bg-accent-dark text-white">
                            View Buildings
                        </button>
                    )}
                    <button onClick={onSiteDetailsClick} className="w-full text-center py-2 px-4 rounded-md text-sm font-semibold transition-colors bg-slate-700 hover:bg-slate-600 text-slate-300">
                        Details
                    </button>
                </div>
            </div>

            <div className="flex flex-col items-center justify-center text-center flex-shrink-0 w-32 space-y-1">
                 <p className="text-6xl font-bold" style={{ color: data.aqiQuality.color }}>{data.avgAqi30d.toFixed(0)}</p>
                 <p className="text-sm text-slate-400">30d Avg. AQI</p>
                 <p className="text-xs text-slate-500 pt-1">Major Pollutant: {data.dominantPollutant30d?.toUpperCase()}</p>
                 <div className="flex items-center gap-1 text-xs text-slate-500">
                    {TrendIcon}
                    <span>vs Last Year</span>
                </div>
            </div>
        </div>
    );
};

export default SiteOverviewCard;