import React, { useState, useEffect } from 'react';
import { getSiteDetails } from '../services/apiService';
import { SiteDetails, GlanceTimePeriod, MajorPollutant } from '../types';
import { X, Loader2, BarChart2 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { format } from 'date-fns';
import { useSettings } from '../contexts/SettingsContext';
import BuildingPerformanceCard from './BuildingPerformanceCard';


interface SiteOverviewModalProps {
    siteName: string;
    timePeriod: GlanceTimePeriod;
    isOpen: boolean;
    onClose: () => void;
}

const POLLUTANT_CONFIG: Record<MajorPollutant, { name: string, color: string, unit: string }> = {
    pm25: { name: 'PM2.5', color: '#f87171', unit: 'µg/m³' },
    co2: { name: 'CO₂', color: '#60a5fa', unit: 'ppm' },
    voc: { name: 'VOC', color: '#facc15', unit: 'index' },
};

const CustomTooltip = ({ active, payload, label, activePollutant }: any) => {
    if (active && payload && payload.length) {
        const value = payload[0].value;
        const config = POLLUTANT_CONFIG[activePollutant as MajorPollutant];
        return (
            <div className="bg-primary/80 backdrop-blur-sm p-3 rounded-md border border-slate-700">
                <p className="text-sm text-slate-300">{label}</p>
                <p style={{ color: payload[0].payload.fill }}>
                    {config.name}: {value.toFixed(1)} {config.unit}
                </p>
            </div>
        );
    }
    return null;
};

const SiteOverviewModal: React.FC<SiteOverviewModalProps> = ({ siteName, timePeriod, isOpen, onClose }) => {
    const [details, setDetails] = useState<SiteDetails | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [activePollutant, setActivePollutant] = useState<MajorPollutant>('pm25');
    const { getMetricQuality } = useSettings();

    useEffect(() => {
        if (isOpen) {
            const fetchDetails = async () => {
                try {
                    setLoading(true);
                    setError(null);
                    const data = await getSiteDetails(siteName, timePeriod);
                    setDetails(data);
                } catch (err) {
                    setError('Failed to load site details.');
                    console.error(err);
                } finally {
                    setLoading(false);
                }
            };
            fetchDetails();
        }
    }, [isOpen, siteName, timePeriod]);
    
    const formatXAxis = (tickItem: string) => {
        const date = new Date(tickItem);
        return timePeriod === '12m' ? format(date, 'MMM yy') : format(date, 'd MMM');
    };

    const renderContent = () => {
        if (loading) {
            return <div className="flex justify-center items-center h-96"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>;
        }
        if (error || !details) {
            return <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error || 'No data available.'}</div>;
        }

        const activeTrend = details.pollutantTrends[activePollutant].map(d => ({
            ...d,
            time: formatXAxis(d.time)
        }));
        const activeConfig = POLLUTANT_CONFIG[activePollutant];

        return (
            <div className="space-y-6">
                <div>
                    <h3 className="text-2xl font-bold text-white flex items-center gap-2"><BarChart2 className="text-accent" /> Site Pollutant Trends</h3>
                    <div className="flex items-center gap-1 bg-tertiary p-1 rounded-full mt-3 w-fit">
                        {Object.entries(POLLUTANT_CONFIG).map(([key, config]) => (
                             <button key={key} onClick={() => setActivePollutant(key as MajorPollutant)} className={`px-3 py-1 text-sm font-semibold rounded-full ${activePollutant === key ? 'bg-accent text-white' : 'hover:bg-slate-600'}`}>
                                {config.name}
                            </button>
                        ))}
                    </div>
                     <div className="h-64 mt-4">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={activeTrend} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#475569" strokeOpacity={0.5} />
                                <XAxis dataKey="time" stroke="#94a3b8" tick={{ fontSize: 12 }} />
                                <YAxis stroke="#94a3b8" tick={{ fontSize: 12 }} domain={['auto', 'dataMax + 10']} unit={activeConfig.unit} />
                                <Tooltip content={<CustomTooltip activePollutant={activePollutant} />} cursor={{fill: 'rgba(100, 116, 139, 0.2)'}} />
                                <Bar dataKey="value" name={activeConfig.name} radius={[4, 4, 0, 0]}>
                                    {activeTrend.map((entry, index) => {
                                        const quality = getMetricQuality(activePollutant, entry.value);
                                        return <Cell key={`cell-${index}`} fill={quality.color} />;
                                    })}
                                </Bar>
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
                <div>
                    <h3 className="text-2xl font-bold text-white mb-4">Building Performance Breakdown</h3>
                    <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                        {details.buildingSummaries.sort((a,b) => a.name.localeCompare(b.name)).map(summary => (
                           <BuildingPerformanceCard
                                key={summary.name}
                                buildingSummary={summary}
                                activePollutant={activePollutant}
                                timePeriod={timePeriod}
                           />
                        ))}
                    </div>
                </div>
            </div>
        );
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4" onClick={onClose}>
            <div className="bg-secondary rounded-lg shadow-xl w-full max-w-6xl animate-fade-in-scale" onClick={e => e.stopPropagation()}>
                <div className="p-5 border-b border-slate-700 flex justify-between items-center">
                    <div>
                        <h2 className="text-2xl font-bold text-white">Site Overview</h2>
                        <p className="text-cyan-400">{siteName}</p>
                    </div>
                    <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
                        <X className="w-6 h-6" />
                    </button>
                </div>
                <div className="p-6 max-h-[80vh] overflow-y-auto">
                    {renderContent()}
                </div>
            </div>
        </div>
    );
};

export default SiteOverviewModal;