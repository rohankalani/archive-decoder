import React, { useMemo } from 'react';
import { ChevronDown } from 'lucide-react';

interface TimezoneSelectorProps {
  value: string;
  onChange: (timezone: string) => void;
}

const commonTimezones = [
    "UTC",
    "America/New_York",
    "America/Chicago",
    "America/Denver",
    "America/Los_Angeles",
    "Europe/London",
    "Europe/Paris",
    "Europe/Moscow",
    "Asia/Tokyo",
    "Asia/Dubai",
    "Asia/Kolkata",
    "Australia/Sydney",
];

const TimezoneSelector: React.FC<TimezoneSelectorProps> = ({ value, onChange }) => {
    const timezones = useMemo(() => {
        const supportedTimezones = new Set(commonTimezones);
        try {
            const currentUserTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
            if (currentUserTimezone) {
                supportedTimezones.add(currentUserTimezone);
            }
        } catch(e) { console.error("Could not get user timezone", e); }
        
        return Array.from(supportedTimezones).sort();
    }, []);

    return (
        <div className="relative">
            <select
                value={value}
                onChange={(e) => onChange(e.target.value)}
                className="appearance-none w-full bg-tertiary border border-slate-600 rounded-full pl-4 pr-8 py-2 text-sm text-white focus:ring-2 focus:ring-accent-dark focus:outline-none"
            >
                {timezones.map(tz => (
                    <option key={tz} value={tz}>
                        {tz}
                    </option>
                ))}
            </select>
            <ChevronDown className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400" />
        </div>
    );
};

export default TimezoneSelector;
