import React, { useState, useEffect, useCallback } from 'react';
import { User, UserRole } from '../types';
import { getUsers, inviteUser, deleteUser } from '../services/apiService';
import { Plus, Trash2, X, Loader2, Mail, Shield } from 'lucide-react';

const UserManagement: React.FC = () => {
    const [users, setUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);

    const [newUserEmail, setNewUserEmail] = useState('');
    const [newUserRole, setNewUserRole] = useState<UserRole>('user');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const fetchUsers = useCallback(async () => {
        try {
            setLoading(true);
            const data = await getUsers();
            setUsers(data);
        } catch (err) {
            setError('Failed to load users.');
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchUsers();
    }, [fetchUsers]);

    const handleInviteSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newUserEmail) {
            alert('Please enter an email address.');
            return;
        }
        setIsSubmitting(true);
        try {
            await inviteUser(newUserEmail, newUserRole);
            setNewUserEmail('');
            setNewUserRole('user');
            setIsModalOpen(false);
            fetchUsers(); // Refresh the list
        } catch (err) {
            console.error('Failed to invite user', err);
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleDeleteUser = async (id: string) => {
        if (window.confirm('Are you sure you want to remove this user?')) {
            try {
                await deleteUser(id);
                fetchUsers(); // Refresh the list
            } catch (err) {
                console.error('Failed to delete user', err);
            }
        }
    };

    if (loading) return <div className="flex justify-center items-center h-48"><Loader2 className="w-6 h-6 text-accent animate-spin" /></div>;
    if (error) return <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error}</div>;

    return (
        <div className="space-y-4">
            <div className="flex justify-between items-center">
                <div>
                    <h2 className="text-xl font-semibold text-white">Manage Users & Invitations</h2>
                    <p className="text-sm text-slate-400">Invite new users and manage existing user roles.</p>
                </div>
                <button onClick={() => setIsModalOpen(true)} className="flex items-center gap-2 px-4 py-2 rounded-md text-white bg-accent hover:bg-accent-dark">
                    <Plus className="w-5 h-5" /> Invite User
                </button>
            </div>
            <div className="bg-tertiary rounded-lg overflow-hidden">
                <table className="w-full text-sm text-left">
                    <thead className="bg-slate-800 text-xs text-slate-400 uppercase">
                        <tr>
                            <th scope="col" className="px-6 py-3">Email</th>
                            <th scope="col" className="px-6 py-3">Role</th>
                            <th scope="col" className="px-6 py-3">Status</th>
                            <th scope="col" className="px-6 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.map(user => (
                            <tr key={user.id} className="border-b border-slate-700 hover:bg-slate-750/50">
                                <td className="px-6 py-4 font-medium text-white">{user.email}</td>
                                <td className="px-6 py-4 text-slate-300 capitalize">{user.role}</td>
                                <td className="px-6 py-4">
                                    <span className={`px-2.5 py-1 text-xs font-semibold rounded-full ${
                                        user.status === 'Active' ? 'bg-green-500/10 text-green-400' : 'bg-yellow-500/10 text-yellow-400'
                                    }`}>
                                        {user.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button onClick={() => handleDeleteUser(user.id)} className="text-slate-400 hover:text-red-500 disabled:text-slate-600 disabled:cursor-not-allowed" title="Remove User" disabled={user.role === 'admin'}>
                                        <Trash2 className="w-5 h-5" />
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                 {users.length === 0 && <p className="text-center text-slate-500 py-8">No users found.</p>}
            </div>

            {isModalOpen && (
                <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4 animate-fade-in-scale">
                    <div className="bg-secondary rounded-lg shadow-xl w-full max-w-md">
                        <form onSubmit={handleInviteSubmit}>
                            <div className="p-5 border-b border-slate-700 flex justify-between items-center">
                                <h2 className="text-xl font-bold text-white">Invite New User</h2>
                                <button type="button" onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white"><X className="w-6 h-6" /></button>
                            </div>
                            <div className="p-5 space-y-4">
                                <div>
                                    <label htmlFor="user-email" className="block text-sm font-medium text-slate-300 mb-1 flex items-center gap-2"><Mail size={14}/> Email Address</label>
                                    <input id="user-email" type="email" value={newUserEmail} onChange={e => setNewUserEmail(e.target.value)} required placeholder="user@example.com" className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" />
                                </div>
                                <div>
                                    <label htmlFor="user-role" className="block text-sm font-medium text-slate-300 mb-1 flex items-center gap-2"><Shield size={14}/> Assign Role</label>
                                    <select id="user-role" value={newUserRole} onChange={e => setNewUserRole(e.target.value as UserRole)} className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white">
                                        <option value="user">Standard User</option>
                                        <option value="admin">Admin</option>
                                    </select>
                                </div>
                            </div>
                            <div className="p-5 border-t border-slate-700 flex justify-end gap-3">
                                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 rounded-md text-white bg-slate-600 hover:bg-slate-500">Cancel</button>
                                <button type="submit" disabled={isSubmitting} className="px-4 py-2 rounded-md text-white bg-accent hover:bg-accent-dark disabled:bg-slate-500 flex items-center gap-2">
                                    {isSubmitting && <Loader2 className="w-4 h-4 animate-spin"/>}
                                    Send Invitation
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default UserManagement;
