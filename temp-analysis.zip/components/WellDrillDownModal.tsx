import React from 'react';
import { WellDrillDownData } from '../types';
import { X, CheckCircle, XCircle, Info } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { format } from 'date-fns';

interface WellDrillDownModalProps {
    isOpen: boolean;
    onClose: () => void;
    data: WellDrillDownData;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-primary/80 backdrop-blur-sm p-3 rounded-md border border-slate-700">
        <p className="text-sm text-slate-300">{format(new Date(label), 'MMM d, HH:mm')}</p>
        <p className="font-semibold" style={{ color: payload[0].stroke }}>
            {`${payload[0].name}: ${payload[0].value.toFixed(2)}`}
        </p>
      </div>
    );
  }
  return null;
};


const WellDrillDownModal: React.FC<WellDrillDownModalProps> = ({ isOpen, onClose, data }) => {
    if (!isOpen) return null;

    const { feature, status, historicalData } = data;
    const metric = feature.metrics[0]; // Assuming one primary metric for simplicity in this chart
    const thresholds = status.thresholds;
    const isCompliant = status.certification === 'Compliant';

    const renderThresholdLines = () => {
        if (!metric) return null;
        const metricThresholds = Object.entries(thresholds).filter(([key]) => key.startsWith(metric));
        return metricThresholds.map(([key, value]) => {
            const label = key.includes('_min') ? 'Min Threshold' : 'Max Threshold';
            const color = isCompliant ? '#4ade80' : '#ef4444';
            return <ReferenceLine key={key} y={value} label={{ value: label, fill: color, fontSize: 12, position: 'insideTopLeft' }} stroke={color} strokeDasharray="3 3" strokeWidth={2} />
        })
    }

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4 animate-fade-in-scale" onClick={onClose}>
            <div className="bg-secondary rounded-lg shadow-xl w-full max-w-4xl" onClick={e => e.stopPropagation()}>
                <div className="p-5 border-b border-slate-700 flex justify-between items-center">
                    <div>
                        <h2 className="text-xl font-bold text-white">{feature.id}: {feature.name}</h2>
                        <p className="text-cyan-400 text-sm">{feature.description}</p>
                    </div>
                    <button type="button" onClick={onClose} className="text-slate-400 hover:text-white"><X size={24} /></button>
                </div>
                <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="md:col-span-2">
                        <h3 className="font-semibold text-white mb-2">Metric Performance</h3>
                        <div className="h-72">
                            <ResponsiveContainer width="100%" height="100%">
                                <LineChart data={historicalData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#475569" strokeOpacity={0.5} />
                                    <XAxis dataKey="timestamp" tickFormatter={(ts) => format(new Date(ts), 'MMM d')} stroke="#94a3b8" tick={{ fontSize: 12 }} />
                                    <YAxis stroke="#94a3b8" tick={{ fontSize: 12 }} domain={['auto', 'dataMax + 10']} />
                                    <Tooltip content={<CustomTooltip />} />
                                    {renderThresholdLines()}
                                    <Line type="monotone" dataKey={metric} name={metric.toUpperCase()} stroke="#38bdf8" strokeWidth={2} dot={false} activeDot={{ r: 5 }} />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                    <div className="space-y-4">
                        <h3 className="font-semibold text-white">Compliance Breakdown</h3>
                        <div className={`p-4 rounded-lg text-center ${isCompliant ? 'bg-green-500/10' : 'bg-red-500/10'}`}>
                            <div className={`mx-auto w-12 h-12 rounded-full flex items-center justify-center ${isCompliant ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                                {isCompliant ? <CheckCircle size={32}/> : <XCircle size={32}/>}
                            </div>
                            <p className={`text-2xl font-bold mt-2 ${isCompliant ? 'text-green-400' : 'text-red-400'}`}>{status.certification}</p>
                        </div>
                         <div className="bg-tertiary p-4 rounded-lg space-y-3 text-sm">
                            <div className="flex justify-between">
                                <span className="text-slate-400">Compliance Rule</span>
                                <span className="font-semibold text-white">&ge; 90% in tolerance</span>
                            </div>
                             <div className="flex justify-between">
                                <span className="text-slate-400">Your Performance</span>
                                <span className="font-semibold text-white">{status.compliancePercentage.toFixed(1)}%</span>
                            </div>
                            <div className="w-full bg-slate-700 rounded-full h-2.5">
                                <div className={`${isCompliant ? 'bg-green-500' : 'bg-red-500'} h-2.5 rounded-full`} style={{width: `${status.compliancePercentage}%`}}></div>
                            </div>
                            <div className="text-xs text-slate-500 text-center pt-1">
                                {status.compliantPoints} of {status.totalPoints} data points from occupied hours were compliant.
                            </div>
                        </div>
                         <div className="bg-tertiary p-4 rounded-lg space-y-2 text-sm">
                             <h4 className="font-semibold text-slate-300">Thresholds Applied</h4>
                             {Object.entries(thresholds).map(([key, value]) => (
                                <div key={key} className="flex justify-between">
                                    <span className="text-slate-400 capitalize">{key.replace('_',' ')}</span>
                                    <span className="font-semibold text-white">{value}</span>
                                </div>
                             ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default WellDrillDownModal;
