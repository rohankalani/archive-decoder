import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { getZones, getDevices, addZone, updateZone, deleteZone } from '../services/apiService';
import { Zone, DeviceWithData } from '../types';
import { Loader2, Plus, Edit, Trash2, X, Check } from 'lucide-react';

const ZoneModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSave: (name: string, deviceIds: string[]) => Promise<void>;
    zone: Zone | null;
    allDevices: DeviceWithData[];
}> = ({ isOpen, onClose, onSave, zone, allDevices }) => {
    const [name, setName] = useState('');
    const [selectedDeviceIds, setSelectedDeviceIds] = useState<Set<string>>(new Set());
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        if (zone) {
            setName(zone.name);
            setSelectedDeviceIds(new Set(zone.deviceIds));
        } else {
            setName('');
            setSelectedDeviceIds(new Set());
        }
    }, [zone, isOpen]);

    const handleDeviceToggle = (deviceId: string) => {
        setSelectedDeviceIds(prev => {
            const newSet = new Set(prev);
            if (newSet.has(deviceId)) {
                newSet.delete(deviceId);
            } else {
                newSet.add(deviceId);
            }
            return newSet;
        });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!name) return;
        setIsSubmitting(true);
        await onSave(name, Array.from(selectedDeviceIds));
        setIsSubmitting(false);
        onClose();
    };

    const devicesByLocation = useMemo(() => {
        return allDevices.reduce((acc, device) => {
            const locationName = device.location?.name || 'Unassigned';
            if (!acc[locationName]) {
                acc[locationName] = [];
            }
            acc[locationName].push(device);
            return acc;
        }, {} as Record<string, DeviceWithData[]>);
    }, [allDevices]);

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4">
            <div className="bg-secondary rounded-lg shadow-xl w-full max-w-lg">
                <form onSubmit={handleSubmit}>
                    <div className="p-5 border-b border-slate-700 flex justify-between items-center">
                        <h2 className="text-xl font-bold text-white">{zone ? 'Edit Zone' : 'Create New Zone'}</h2>
                        <button type="button" onClick={onClose} className="text-slate-400 hover:text-white"><X size={24} /></button>
                    </div>
                    <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                        <div>
                            <label htmlFor="zone-name" className="block text-sm font-medium text-slate-300 mb-1">Zone Name</label>
                            <input id="zone-name" type="text" value={name} onChange={e => setName(e.target.value)} required className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" placeholder="e.g., West Wing - Open Office" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-300 mb-1">Assign Sensors</label>
                            <div className="bg-tertiary border border-slate-600 rounded-md p-3 space-y-3 max-h-60 overflow-y-auto">
                                {/* FIX: Explicitly cast the result of Object.entries to an array of tuples to resolve the 'map does not exist on type unknown' TypeScript error. */}
                                {(Object.entries(devicesByLocation) as [string, DeviceWithData[]][]).map(([locationName, devices]) => (
                                    <div key={locationName}>
                                        <h4 className="font-semibold text-cyan-400 text-sm mb-1">{locationName}</h4>
                                        <div className="space-y-1 pl-2">
                                            {devices.map(device => (
                                                <label key={device.id} className="flex items-center gap-3 p-2 hover:bg-slate-700 rounded-md cursor-pointer">
                                                    <input type="checkbox" checked={selectedDeviceIds.has(device.id)} onChange={() => handleDeviceToggle(device.id)} className="w-5 h-5 accent-accent" />
                                                    <span className="text-white font-medium">{device.name}</span>
                                                </label>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                    <div className="p-5 border-t border-slate-700 flex justify-end gap-3">
                        <button type="button" onClick={onClose} className="px-4 py-2 rounded-md bg-slate-600">Cancel</button>
                        <button type="submit" disabled={isSubmitting} className="px-4 py-2 rounded-md bg-accent hover:bg-accent-dark disabled:bg-slate-500 flex items-center gap-2">
                            {isSubmitting && <Loader2 className="animate-spin" size={16} />} {zone ? 'Save Changes' : 'Create Zone'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};


const ZoneManagement: React.FC<{ onDataChanged: () => void }> = ({ onDataChanged }) => {
    const [zones, setZones] = useState<Zone[]>([]);
    const [allDevices, setAllDevices] = useState<DeviceWithData[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingZone, setEditingZone] = useState<Zone | null>(null);

    const fetchData = useCallback(async () => {
        setLoading(true);
        try {
            const [zonesData, devicesData] = await Promise.all([getZones(), getDevices()]);
            setZones(zonesData);
            setAllDevices(devicesData.filter(d => d.type === 'standard'));
        } catch (err) {
            setError("Failed to load zone data.");
            console.error(err);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const handleOpenModal = (zone: Zone | null) => {
        setEditingZone(zone);
        setIsModalOpen(true);
    };

    const handleSaveZone = async (name: string, deviceIds: string[]) => {
        if (editingZone) {
            await updateZone(editingZone.id, name, deviceIds);
        } else {
            await addZone(name, deviceIds);
        }
        onDataChanged();
        fetchData();
    };

    const handleDeleteZone = async (id: string) => {
        if (window.confirm("Are you sure you want to delete this zone? This will not delete the sensors themselves.")) {
            await deleteZone(id);
            onDataChanged();
            fetchData();
        }
    };

    if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>;
    if (error) return <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error}</div>;

    return (
        <div className="bg-tertiary p-6 rounded-lg shadow-inner">
             <ZoneModal 
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSaveZone}
                zone={editingZone}
                allDevices={allDevices}
            />
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-white">Compliance Zones</h2>
                <button onClick={() => handleOpenModal(null)} className="flex items-center gap-2 px-4 py-2 rounded-md text-white bg-accent hover:bg-accent-dark">
                    <Plus size={20} /> Create Zone
                </button>
            </div>
            <p className="text-sm text-slate-400 mb-4 max-w-2xl">
                Group one or more sensors into a single zone. Compliance for the zone will be calculated based on the worst reading from any sensor within it.
            </p>
            <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
                {zones.map(zone => {
                    const assignedDevices = zone.deviceIds.map(id => allDevices.find(d => d.id === id)).filter(Boolean);
                    return (
                        <div key={zone.id} className="bg-secondary p-4 rounded-md">
                            <div className="flex justify-between items-center">
                                <p className="font-semibold text-lg text-cyan-400">{zone.name}</p>
                                <div className="flex items-center gap-3">
                                    <button onClick={() => handleOpenModal(zone)} className="text-slate-400 hover:text-white"><Edit size={18}/></button>
                                    <button onClick={() => handleDeleteZone(zone.id)} className="text-slate-400 hover:text-red-500"><Trash2 size={18}/></button>
                                </div>
                            </div>
                            <div className="text-sm text-slate-400 mt-2 border-t border-slate-700 pt-2">
                                <p className="font-semibold text-slate-300 mb-1">{assignedDevices.length} Assigned Sensor(s):</p>
                                {assignedDevices.length > 0 ? (
                                    <ul className="list-disc list-inside">
                                        {assignedDevices.map(device => device && <li key={device.id}>{device.name}</li>)}
                                    </ul>
                                ) : <p>No sensors assigned.</p>}
                            </div>
                        </div>
                    );
                })}
                 {zones.length === 0 && <p className="text-slate-400 text-center py-8">No zones configured. Create a zone to begin.</p>}
            </div>
        </div>
    );
};

export default ZoneManagement;