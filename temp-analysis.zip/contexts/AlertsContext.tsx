import React, { createContext, useContext, useState, ReactNode, useEffect, useRef } from 'react';
// FIX: Corrected import path for types.
import { Alert, Device } from '../types';
import { useRealtimeData } from './RealtimeDataContext';
import { useSettings } from './SettingsContext';
// FIX: Corrected import path for apiService.
import { getDevices } from '../services/apiService';

interface AlertsContextType {
  alerts: Alert[];
  acknowledgeAlert: (alertId: string) => void;
}

const AlertsContext = createContext<AlertsContextType | undefined>(undefined);

const LOW_BATTERY_THRESHOLD = 35;
const OFFLINE_ALERT_DELAY = 15000; // Generate offline alert after 15 seconds
const VAPE_VOC_THRESHOLD = 450;
const SMOKE_PM25_THRESHOLD = 100;

export const AlertsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const { realtimeData } = useRealtimeData();
  const { getMetricQuality } = useSettings();
  const devicesRef = useRef<Device[]>([]);

  useEffect(() => {
    const fetchAndSetDevices = async () => {
        try {
            devicesRef.current = await getDevices();
        } catch (error) {
            console.error("Failed to fetch device list for alerts context:", error);
        }
    };
    fetchAndSetDevices();
  }, []);
  
  useEffect(() => {
    const now = Date.now();
    
    if (devicesRef.current.length === 0) return;

    devicesRef.current.forEach(device => {
        const currentData = realtimeData[device.id];
        const lastUpdate = currentData ? new Date(currentData.timestamp).getTime() : 0;
        const isOffline = (now - lastUpdate) > OFFLINE_ALERT_DELAY;

        const offlineAlertId = `offline-${device.id}`;
        const existingOfflineAlert = alerts.find(a => a.id === offlineAlertId);

        if (isOffline && !existingOfflineAlert) {
            setAlerts(prev => [...prev, {
                id: offlineAlertId, type: 'device-offline', severity: 'critical', status: 'active',
                title: 'Device Offline', description: `Sensor "${device.name}" has not reported data.`,
                deviceId: device.id, deviceName: device.name, locationName: device.location.name,
                timestamp: new Date().toISOString()
            }]);
        } else if (!isOffline && existingOfflineAlert?.status === 'active') {
            setAlerts(prev => prev.map(a => a.id === offlineAlertId ? { ...a, status: 'resolved', resolvedTimestamp: new Date().toISOString() } : a));
        }

        if (currentData && !isOffline) {
            // --- Low Battery Check (Auto-resolves) ---
            const batteryAlertId = `battery-${device.id}`;
            const existingBatteryAlert = alerts.find(a => a.id === batteryAlertId);
            if (currentData.battery && currentData.battery < LOW_BATTERY_THRESHOLD && !existingBatteryAlert) {
                setAlerts(prev => [...prev, { id: batteryAlertId, type: 'low-battery', severity: 'warning', status: 'active', title: 'Low Battery', description: `Battery at ${currentData.battery}%`, deviceId: device.id, deviceName: device.name, locationName: device.location.name, timestamp: new Date().toISOString() }]);
            } else if (currentData.battery && currentData.battery >= LOW_BATTERY_THRESHOLD && existingBatteryAlert?.status === 'active') {
                setAlerts(prev => prev.map(a => a.id === batteryAlertId ? { ...a, status: 'resolved', resolvedTimestamp: new Date().toISOString() } : a));
            }
            
            // --- Vape/Smoke Device Specific Alerts (Requires Manual Acknowledgment) ---
            if (device.type === 'vape-smoke') {
                const vapeAlertId = `vape-${device.id}`;
                const smokeAlertId = `smoke-${device.id}`;
                
                // Vape Detection Logic
                const vocValue = currentData.voc;
                const presence = currentData.presence;
                const isVapingCondition = vocValue && vocValue > VAPE_VOC_THRESHOLD && presence === 1;

                if (isVapingCondition) {
                    const existingVapeAlert = alerts.find(a => a.id === vapeAlertId);
                    if (!existingVapeAlert) {
                        setAlerts(prev => [...prev, { id: vapeAlertId, type: 'vape-detected', severity: 'critical', status: 'active', title: 'Vaping Signature Detected', description: `High VOC level (${vocValue}) with presence detected.`, deviceId: device.id, deviceName: device.name, locationName: device.location.name, timestamp: new Date().toISOString() }]);
                    } else if (existingVapeAlert.status === 'resolved') {
                        // Reactivate for a new event
                        setAlerts(prev => prev.map(a => a.id === vapeAlertId ? { ...a, status: 'active', timestamp: new Date().toISOString(), resolvedTimestamp: undefined, description: `High VOC level (${vocValue}) with presence detected.` } : a));
                    }
                }

                // Smoke Detection Logic
                const pm25Value = currentData.pm25;
                const isSmokeCondition = pm25Value && pm25Value > SMOKE_PM25_THRESHOLD;

                if(isSmokeCondition) {
                    const existingSmokeAlert = alerts.find(a => a.id === smokeAlertId);
                    if (!existingSmokeAlert) {
                        setAlerts(prev => [...prev, { id: smokeAlertId, type: 'smoke-detected', severity: 'critical', status: 'active', title: 'Smoke Detected', description: `High Particulate Matter (${pm25Value.toFixed(1)} µg/m³) detected.`, deviceId: device.id, deviceName: device.name, locationName: device.location.name, timestamp: new Date().toISOString() }]);
                    } else if (existingSmokeAlert.status === 'resolved') {
                        // Reactivate for a new event
                        setAlerts(prev => prev.map(a => a.id === smokeAlertId ? { ...a, status: 'active', timestamp: new Date().toISOString(), resolvedTimestamp: undefined, description: `High Particulate Matter (${pm25Value.toFixed(1)} µg/m³) detected.` } : a));
                    }
                }

            } else { // Standard IAQ device alerts
                // --- General Smoke/Vape Alert (Requires Manual Acknowledgment) ---
                const smokeVapeAlertId = `smoke-vape-${device.id}`;
                const isSmokeVapeCondition = currentData.smoke_vape_detected === 1;
                
                if (isSmokeVapeCondition) {
                    const existingAlert = alerts.find(a => a.id === smokeVapeAlertId);
                    if (!existingAlert) {
                         setAlerts(prev => [...prev, { id: smokeVapeAlertId, type: 'smoke-vape-detected', severity: 'critical', status: 'active', title: 'Smoke/Vape Detected', description: `A smoke or vape signature was detected by the sensor.`, deviceId: device.id, deviceName: device.name, locationName: device.location.name, timestamp: new Date().toISOString() }]);
                    } else if (existingAlert.status === 'resolved') {
                        // Reactivate for new event
                        setAlerts(prev => prev.map(a => a.id === smokeVapeAlertId ? { ...a, status: 'active', timestamp: new Date().toISOString(), resolvedTimestamp: undefined } : a));
                    }
                }

                // --- Standard IAQ Threshold Alert (Auto-resolves) ---
                const pm25AlertId = `pm25-${device.id}`;
                const existingPm25Alert = alerts.find(a => a.id === pm25AlertId);
                const pm25Value = currentData.pm25;
                if (pm25Value) {
                    const quality = getMetricQuality('pm25', pm25Value);
                    if (quality.label === 'Unhealthy for Sensitive Groups' && !existingPm25Alert) {
                         setAlerts(prev => [...prev, { id: pm25AlertId, type: 'threshold-exceeded', severity: 'warning', status: 'active', title: 'Air Quality Threshold Exceeded', description: `PM2.5 levels (${pm25Value.toFixed(1)} µg/m³) are moderate.`, deviceId: device.id, deviceName: device.name, locationName: device.location.name, timestamp: new Date().toISOString() }]);
                    } else if (quality.label === 'Good' && existingPm25Alert?.status === 'active') {
                        setAlerts(prev => prev.map(a => a.id === pm25AlertId ? { ...a, status: 'resolved', resolvedTimestamp: new Date().toISOString() } : a));
                    }
                }
            }
        }
    });

  }, [realtimeData, getMetricQuality, alerts]);

  const acknowledgeAlert = (alertId: string) => {
    setAlerts(alerts => alerts.map(alert =>
      alert.id === alertId ? { ...alert, status: 'resolved', resolvedTimestamp: new Date().toISOString() } : alert
    ));
  };

  const sortedAlerts = alerts.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  return (
    <AlertsContext.Provider value={{ alerts: sortedAlerts, acknowledgeAlert }}>
      {children}
    </AlertsContext.Provider>
  );
};

export const useAlerts = () => {
  const context = useContext(AlertsContext);
  if (context === undefined) {
    throw new Error('useAlerts must be used within an AlertsProvider');
  }
  return context;
};