import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
// FIX: Corrected import path for types.
import { RealtimeData } from '../types';
import { useSettings } from './SettingsContext';

interface RealtimeDataContextType {
  realtimeData: Record<string, RealtimeData>;
}

const RealtimeDataContext = createContext<RealtimeDataContextType | undefined>(undefined);

const SIMULATION_INTERVAL = 5000; // 5 seconds

// --- Frontend Data Simulator ---
const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(value, max));
const getRandom = (min: number, max: number, decimals = 1) => parseFloat((Math.random() * (max - min) + min).toFixed(decimals));

const DEVICE_PROFILES: Record<string, {
    state: Record<string, any>;
    update: (s: Record<string, any>, allStates: Record<string, any>) => void;
}> = {
    'sim-device-01': { // Conference Room Sensor
        state: { co2: 500, temp: 21.5, humidity: 45, voc: 75, pm25: 8, occupancy: 0 },
        update: (s) => {
            const hour = new Date().getHours();
            const isMeetingTime = (hour >= 9 && hour < 12) || (hour >= 14 && hour < 17);
            if (isMeetingTime) { s.co2 += getRandom(20, 50); s.occupancy = Math.min(s.occupancy + 1, 10); } 
            else { s.co2 -= getRandom(10, 30); s.occupancy = Math.max(s.occupancy - 2, 0); }
            s.co2 = clamp(s.co2, 400, 1500);
            s.voc = s.co2 > 1000 ? getRandom(150, 250) : getRandom(50, 100);
            s.temp += (s.occupancy > 0 ? 0.1 : -0.1) + getRandom(-0.2, 0.2);
            s.pm25 += getRandom(-0.5, 0.5);
        }
    },
    'sim-device-02': { // Lab
        state: { co2: 600, temp: 22.0, humidity: 50, voc: 250, pm25: 18 },
        update: (s) => {
            s.co2 += getRandom(-20, 20); s.voc += getRandom(-15, 15); s.pm25 += getRandom(-2, 2);
            s.voc = clamp(s.voc, 200, 400); s.pm25 = clamp(s.pm25, 15, 35);
        }
    },
    'sim-device-03': { // AHU Duct
        state: { co2: 410, temp: 18.0, humidity: 55, voc: 20, pm25: 2 },
        update: (s) => {
             s.co2 += getRandom(-5, 5); s.temp += getRandom(-0.1, 0.1); s.pm25 += getRandom(-0.1, 0.2);
             s.co2 = clamp(s.co2, 400, 450); s.pm25 = clamp(s.pm25, 1, 5);
        }
    },
    'sim-device-04': { // CEO Office Sensor
        state: { co2: 450, temp: 22.5, humidity: 48, voc: 60, pm25: 10, occupancy: 1 },
        update: (s) => {
            s.co2 += getRandom(-10, 10); s.temp += getRandom(-0.2, 0.2); s.humidity += getRandom(-1, 1);
            s.voc += getRandom(-5, 5); s.pm25 += getRandom(-1, 1);
        }
    },
     'sim-device-21': { // Factory Floor
        state: { co2: 700, temp: 25.0, humidity: 60, voc: 150, pm25: 25 },
        update: (s) => {
            s.co2 += getRandom(-15, 15); s.voc += getRandom(-10, 10); s.pm25 += getRandom(-3, 3);
            s.voc = clamp(s.voc, 100, 300); s.pm25 = clamp(s.pm25, 20, 45);
        }
    },
    'sim-device-11': { // Restroom (Vape Detector)
        state: { voc: 55, pm25: 6, presence: 0 },
        update: (s) => {
            const isOccupied = Math.random() > 0.8;
            s.presence = isOccupied ? 1 : 0;
            if (isOccupied && Math.random() > 0.9) { // 10% chance of vaping if occupied
                s.voc = getRandom(500, 800);
                s.pm25 = getRandom(50, 150);
            } else {
                s.voc = Math.max(50, s.voc - getRandom(10, 30));
                s.pm25 = Math.max(5, s.pm25 - getRandom(2, 5));
            }
        }
    },
    'purifier-01': { // Conference Room Purifier
        state: { mode: 'auto', fan_speed: 0, filter_life: 98.5 },
        update: (s, allStates) => {
            const sensorState = allStates['sim-device-01'];
            if(s.mode === 'auto' && sensorState) {
                const needsPurifying = sensorState.occupancy > 0 && (sensorState.pm25 > 12 || sensorState.voc > 200);
                if(needsPurifying) {
                    s.fan_speed = Math.min(100, s.fan_speed + 20);
                } else {
                    s.fan_speed = Math.max(0, s.fan_speed - 10);
                }
            }
             if (s.fan_speed > 0) {
                s.filter_life -= (0.01 * (s.fan_speed / 100)); // Degrade filter life based on usage
            }
            s.filter_life = clamp(s.filter_life, 0, 100);
        }
    },
    'purifier-02': { // CEO Office Purifier
        state: { mode: 'auto', fan_speed: 0, filter_life: 89.2 },
        update: (s, allStates) => {
            const sensorState = allStates['sim-device-04'];
            if(s.mode === 'auto' && sensorState) {
                const needsPurifying = (sensorState.pm25 > 10 || sensorState.voc > 150);
                if(needsPurifying) {
                    s.fan_speed = Math.min(100, s.fan_speed + 25);
                } else {
                    s.fan_speed = Math.max(0, s.fan_speed - 15);
                }
            }
            if (s.fan_speed > 0) {
                s.filter_life -= (0.012 * (s.fan_speed / 100));
            }
            s.filter_life = clamp(s.filter_life, 0, 100);
        }
    }
};

export const RealtimeDataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [realtimeData, setRealtimeData] = useState<Record<string, RealtimeData>>({});
  const { calculateOverallAqi } = useSettings();

  useEffect(() => {
    const generateData = (deviceId: string, allStates: Record<string, any>): RealtimeData | undefined => {
      const profile = DEVICE_PROFILES[deviceId];
      if (!profile) return;
      
      profile.update(profile.state, allStates);

      const s = profile.state;
      const pm25 = clamp(s.pm25, 0, 500);
      
      const baseData = {
        co2: clamp(s.co2, 400, 5000),
        temp: clamp(s.temp, 15, 35),
        humidity: clamp(s.humidity, 20, 80),
        voc: clamp(s.voc, 10, 1000),
        pm25: pm25,
        occupancy: s.occupancy,
        presence: s.presence,
        hcho: getRandom(10, 100),
        nox: getRandom(10, 150),
        pm10: clamp(pm25 * 1.5 + getRandom(-5, 5), 0, 600),
        pm1: clamp(pm25 * 0.8 + getRandom(-2, 2), 0, 400),
        pm03: clamp(pm25 * 0.5 + getRandom(-1, 1), 0, 250),
        pm5: clamp(pm25 * 1.2 + getRandom(-3, 3), 0, 550),
        pc03: getRandom(30000, 40000, 0),
        pc05: getRandom(8000, 11000, 0),
        pc1: getRandom(1200, 1700, 0),
        pc25: getRandom(250, 350, 0),
        pc5: getRandom(70, 100, 0),
        pc10: getRandom(20, 30, 0),
        battery: clamp(s.battery ?? 100, 0, 100),
        smoke_vape_detected: (Math.random() > 0.99 ? 1 : 0) as (0 | 1),
        mode: s.mode,
        fan_speed: clamp(s.fan_speed, 0, 100),
        filter_life: s.filter_life,
      };

      s.battery = (s.battery ?? 100) - 0.01;
      const { aqi } = calculateOverallAqi(baseData);

      const data: RealtimeData = {
        deviceId,
        timestamp: new Date().toISOString(),
        ...baseData,
        iaqi: aqi,
      };

      return data;
    };
    
    const allCurrentStates = Object.entries(DEVICE_PROFILES).reduce((acc, [id, profile]) => {
        acc[id] = profile.state;
        return acc;
    }, {} as Record<string, any>);


    const intervalId = setInterval(() => {
        const newData: Record<string, RealtimeData> = {};
        Object.keys(DEVICE_PROFILES).forEach(deviceId => {
            const data = generateData(deviceId, allCurrentStates);
            if (data) {
                newData[deviceId] = data;
            }
        });
        setRealtimeData(prevData => ({ ...prevData, ...newData }));
    }, SIMULATION_INTERVAL);
    
    const initialData: Record<string, RealtimeData> = {};
    Object.keys(DEVICE_PROFILES).forEach(deviceId => {
        const data = generateData(deviceId, allCurrentStates);
        if(data) {
             initialData[deviceId] = data;
        }
    });
    setRealtimeData(initialData);


    return () => clearInterval(intervalId);
  }, [calculateOverallAqi]);

  return (
    <RealtimeDataContext.Provider value={{ realtimeData }}>
      {children}
    </RealtimeDataContext.Provider>
  );
};

export const useRealtimeData = () => {
  const context = useContext(RealtimeDataContext);
  if (context === undefined) {
    throw new Error('useRealtimeData must be used within a RealtimeDataProvider');
  }
  return context;
};