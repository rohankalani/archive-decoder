import React, { createContext, useContext, useState, ReactNode, useCallback } from 'react';
// FIX: Corrected import path for types.
import type { Metric, Thresholds, AqiLevel, UnitSystem, BreakpointTable } from '../types';

// --- ROSAIQ Standard AQI Calculation ---

const PARTICLE_COUNT_CONVERSION = 35.3147; // #/ft³ to #/m³

// FIX: Added 'dp', 'presence', 'smoke_vape_detected', 'battery', 'fan_speed', and 'filter_life' to satisfy the Record<Metric, BreakpointTable> type.
export const initialBreakpoints: Record<Metric, BreakpointTable> = {
  pm25: [
    [0.0, 50.4, 0, 50], [50.5, 60.4, 51, 100], [60.5, 75.4, 101, 150], [75.5, 150.4, 151, 200], [150.5, 250.4, 201, 300], [250.5, 500.4, 301, 500],
  ],
  pm10: [
    [0.0, 75.0, 0, 50], [75.1, 150.0, 51, 100], [150.1, 250.0, 101, 150], [250.1, 350.0, 151, 200], [350.1, 420.0, 201, 300], [420.1, 600.0, 301, 500],
  ],
  hcho: [
    [0.0, 30.0, 0, 50], [30.1, 80.0, 51, 100], [80.1, 120.0, 101, 150], [120.1, 200.0, 151, 200], [200.1, 300.0, 201, 300], [300.1, 500.0, 301, 500],
  ],
  voc: [ 
    [0.0, 100.0, 0, 50], [100.1, 200.0, 51, 100], [200.1, 300.0, 101, 150], [300.1, 400.0, 151, 200], [400.1, 450.0, 201, 300], [450.1, 500.0, 301, 500],
  ],
  nox: [
    [0.0, 100.0, 0, 50], [100.1, 200.0, 51, 100], [200.1, 300.0, 101, 150], [300.1, 400.0, 151, 200], [400.1, 450.0, 201, 300], [450.1, 500.0, 301, 500],
  ],
  co2: [], iaqi: [], temp: [], humidity: [], pm03: [], pm1: [], pm5: [],
  pc03: [], pc05: [], pc1: [], pc25: [], pc5: [], pc10: [],
  occupancy: [],
  presence: [],
  dp: [],
  smoke_vape_detected: [],
  battery: [],
  fan_speed: [],
  filter_life: [],
};

export const AQI_POLLUTANTS: Metric[] = ['pm25', 'pm10', 'hcho', 'voc', 'nox'];

export interface QualityInfo {
  label: AqiLevel | 'N/A' | 'Comfort' | 'Warm' | 'Hot' | 'Very Hot' | 'Cold' | 'Ideal' | 'Dry' | 'Very Dry' | 'Humid';
  color: string;
}

export const AQI_LEVELS: Record<AqiLevel, { color: string; range: string }> = {
  'Good': { color: '#4ade80', range: '0-50' },
  'Moderate': { color: '#facc15', range: '51-100' },
  'Unhealthy for Sensitive Groups': { color: '#f97316', range: '101-150' },
  'Unhealthy': { color: '#ef4444', range: '151-200' },
  'Very Unhealthy': { color: '#a855f7', range: '201-300' },
  'Hazardous': { color: '#881337', range: '301-500' },
};

// --- Fallback thresholds for non-standard metrics ---
// FIX: Added 'dp', 'presence', 'smoke_vape_detected', 'battery', 'fan_speed', and 'filter_life' to satisfy the Record<Metric, Thresholds> type.
const defaultThresholds: Record<Metric, Thresholds> = {
  iaqi: { good: 50, moderate: 100, poor: 150 },
  pm25: { good: 50.4, moderate: 150.4, poor: 250.4 },
  pm10: { good: 75, moderate: 250, poor: 350 },
  co2: { good: 1000, moderate: 2000, poor: 5000 },
  voc: { good: 100, moderate: 300, poor: 400 },
  hcho: { good: 30, moderate: 120, poor: 200 },
  nox: { good: 100, moderate: 300, poor: 400 },
  temp: { good: 26, moderate: 30, poor: 34 },
  humidity: { good: 60, moderate: 70, poor: 80 },
  pm03: { good: 10, moderate: 25, poor: 40 },
  pm1: { good: 10, moderate: 30, poor: 50 },
  pm5: { good: 25, moderate: 75, poor: 125 },
  pc03: { good: 35000, moderate: 100000, poor: 250000 },
  pc05: { good: 10000, moderate: 30000, poor: 75000 },
  pc1: { good: 1500, moderate: 4500, poor: 10000 },
  pc25: { good: 300, moderate: 900, poor: 2000 },
  pc5: { good: 80, moderate: 250, poor: 500 },
  pc10: { good: 30, moderate: 100, poor: 200 },
  occupancy: { good: 5, moderate: 15, poor: 25 },
  presence: { good: 0, moderate: 1, poor: 2 }, // 0 = no, 1 = yes
  dp: { good: 100, moderate: 200, poor: 250 },
  smoke_vape_detected: { good: 0, moderate: 1, poor: 1 }, // 0 = no, 1 = yes
  battery: { good: 35, moderate: 20, poor: 10},
  fan_speed: { good: 40, moderate: 70, poor: 90 },
  filter_life: { good: 80, moderate: 40, poor: 10 },
};

const tempQualityMap: Record<string, QualityInfo> = { good: { label: 'Comfort', color: '#4ade80' }, moderate: { label: 'Warm', color: '#facc15' }, poor: { label: 'Hot', color: '#f97316' }, severe: { label: 'Very Hot', color: '#ef4444' }, cold: { label: 'Cold', color: '#60a5fa' } };
const humidityQualityMap: Record<string, QualityInfo> = { good: { label: 'Ideal', color: '#4ade80' }, moderate: { label: 'Dry', color: '#facc15' }, poor: { label: 'Very Dry', color: '#f97316' }, severe: { label: 'Humid', color: '#ef4444' } };

interface SettingsContextType {
  unitSystem: UnitSystem;
  setUnitSystem: (system: UnitSystem) => void;
  breakpoints: Record<Metric, BreakpointTable>;
  updateBreakpoints: (metric: Metric, newTable: BreakpointTable) => void;
  iaqiThresholds: number[];
  updateIaqiThresholds: (newThresholds: number[]) => void;
  convertValue: (metric: Metric, value: number) => number;
  thresholds: Record<Metric, Thresholds>;
  getMetricQuality: (metric: Metric, value: number) => QualityInfo;
  calculateOverallAqi: (data: any) => { aqi: number; quality: QualityInfo; dominantPollutant: Metric | null };
  calculateAllSubIndices: (data: any) => Partial<Record<Metric, number>>;
  updateThresholds: (metric: Metric, newThresholds: Thresholds) => void;
  // FIX: Added getQualityFromAqi to the context type to make it available to consumers.
  getQualityFromAqi: (aqi: number) => QualityInfo;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>('imperial');
  const [breakpoints, setBreakpoints] = useState(initialBreakpoints);
  const [thresholds, setThresholds] = useState(defaultThresholds);
  const [iaqiThresholds, setIaqiThresholds] = useState<number[]>([50, 100, 150, 200, 300]);

  const updateIaqiThresholds = (newThresholds: number[]) => {
    setIaqiThresholds(newThresholds);
  };

  const getQualityFromAqi = useCallback((aqi: number): QualityInfo => {
      if (aqi <= iaqiThresholds[0]) return { label: 'Good', color: AQI_LEVELS['Good'].color };
      if (aqi <= iaqiThresholds[1]) return { label: 'Moderate', color: AQI_LEVELS['Moderate'].color };
      if (aqi <= iaqiThresholds[2]) return { label: 'Unhealthy for Sensitive Groups', color: AQI_LEVELS['Unhealthy for Sensitive Groups'].color };
      if (aqi <= iaqiThresholds[3]) return { label: 'Unhealthy', color: AQI_LEVELS['Unhealthy'].color };
      if (aqi <= iaqiThresholds[4]) return { label: 'Very Unhealthy', color: AQI_LEVELS['Very Unhealthy'].color };
      return { label: 'Hazardous', color: AQI_LEVELS['Hazardous'].color };
  }, [iaqiThresholds]);

  const calculateSubIndex = useCallback((metric: Metric, value: number): number => {
      const table = breakpoints[metric];
      if (!table || table.length === 0) return 0;
      
      // Round the value to one decimal place to match the precision of the breakpoint table.
      // This prevents floating point gaps (e.g., 50.45).
      const roundedValue = parseFloat(value.toFixed(1));
  
      const breakpoint = table.find(b => roundedValue >= b[0] && roundedValue <= b[1]);
      if (!breakpoint) {
        if(roundedValue > table[table.length - 1][1]) return table[table.length - 1][3];
        return 0;
      }
  
      const [c_lo, c_hi, i_lo, i_hi] = breakpoint;
      if (c_hi - c_lo === 0) return i_lo;
  
      const aqi = ((i_hi - i_lo) / (c_hi - c_lo)) * (roundedValue - c_lo) + i_lo;
      return Math.round(aqi);
  }, [breakpoints]);

  const convertValue = useCallback((metric: Metric, value: number) => {
    if (unitSystem === 'metric' && metric.startsWith('pc')) {
      return value * PARTICLE_COUNT_CONVERSION;
    }
    return value;
  }, [unitSystem]);

  const getMetricQuality = useCallback((metric: Metric, value: number): QualityInfo => {
    if (value === undefined || value === null || isNaN(value)) {
        return { label: 'N/A', color: '#64748b' };
    }

    if (AQI_POLLUTANTS.includes(metric)) {
        const subIndex = calculateSubIndex(metric, value);
        return getQualityFromAqi(subIndex);
    }
    
    if (metric === 'temp') {
      if (value < 18) return tempQualityMap.cold; if (value <= thresholds.temp.good) return tempQualityMap.good; if (value <= thresholds.temp.moderate) return tempQualityMap.moderate; if (value <= thresholds.temp.poor) return tempQualityMap.poor; return tempQualityMap.severe;
    }
    if (metric === 'humidity') {
      if (value < 30) return humidityQualityMap.moderate; if (value <= thresholds.humidity.good) return humidityQualityMap.good; if (value <= thresholds.humidity.moderate) return humidityQualityMap.moderate; if (value <= thresholds.humidity.poor) return humidityQualityMap.poor; return humidityQualityMap.severe;
    }
    
    const metricThresholds = thresholds[metric];
    if (!metricThresholds) return { label: 'N/A', color: '#64748b' };
    if (value <= metricThresholds.good) return { label: 'Good', color: AQI_LEVELS.Good.color };
    if (value <= metricThresholds.moderate) return { label: 'Moderate', color: AQI_LEVELS.Moderate.color };
    if (value <= metricThresholds.poor) return { label: 'Unhealthy', color: AQI_LEVELS.Unhealthy.color };
    return { label: 'Very Unhealthy', color: AQI_LEVELS['Very Unhealthy'].color };
  }, [thresholds, calculateSubIndex, getQualityFromAqi]);

  const calculateOverallAqi = useCallback((data: any | null): { aqi: number; quality: QualityInfo; dominantPollutant: Metric | null } => {
    if (!data) {
      return { aqi: 0, quality: { label: 'N/A', color: '#64748b' }, dominantPollutant: null };
    }

    let maxAqi = -1;
    let dominantPollutant: Metric | null = null;

    AQI_POLLUTANTS.forEach(metric => {
        const value = data[metric];
        if (value !== undefined && value !== null) {
            const aqi = calculateSubIndex(metric, value);
            if (aqi > maxAqi) {
                maxAqi = aqi;
                dominantPollutant = metric;
            }
        }
    });
    
    if (maxAqi === -1) {
       return { aqi: 0, quality: { label: 'N/A', color: '#64748b' }, dominantPollutant: null };
    }

    return { aqi: maxAqi, quality: getQualityFromAqi(maxAqi), dominantPollutant };
  }, [calculateSubIndex, getQualityFromAqi]);

  const calculateAllSubIndices = useCallback((data: any | null): Partial<Record<Metric, number>> => {
    if (!data) return {};
    const indices: Partial<Record<Metric, number>> = {};
    AQI_POLLUTANTS.forEach(metric => {
        const value = data[metric];
        if (value !== undefined && value !== null) {
            indices[metric] = calculateSubIndex(metric, value);
        }
    });
    return indices;
  }, [calculateSubIndex]);

  const updateThresholds = (metric: Metric, newThresholds: Thresholds) => {
    setThresholds(prev => ({ ...prev, [metric]: newThresholds }));
  };
  
  const updateBreakpoints = (metric: Metric, newTable: BreakpointTable) => {
    setBreakpoints(prev => ({ ...prev, [metric]: newTable }));
  };

  return (
    <SettingsContext.Provider value={{ 
        unitSystem, setUnitSystem, 
        breakpoints, updateBreakpoints,
        iaqiThresholds, updateIaqiThresholds,
        convertValue,
        thresholds, updateThresholds, 
        getMetricQuality, 
        calculateOverallAqi, calculateAllSubIndices,
        // FIX: Added getQualityFromAqi to the context provider value.
        getQualityFromAqi,
    }}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};