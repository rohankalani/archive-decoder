import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { SettingsProvider } from './contexts/SettingsContext';
import { RealtimeDataProvider } from './contexts/RealtimeDataContext';
import { AlertsProvider } from './contexts/AlertsContext';
import { AuthProvider } from './contexts/AuthContext';

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <SettingsProvider>
      <RealtimeDataProvider>
        <AlertsProvider>
          <AuthProvider>
            <App />
          </AuthProvider>
        </AlertsProvider>
      </RealtimeDataProvider>
    </SettingsProvider>
  </React.StrictMode>
);