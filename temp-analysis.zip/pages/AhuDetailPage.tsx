import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useParams, Link, useLocation } from 'react-router-dom';
import { Loader2, ArrowLeft, DollarSign, Zap, Calendar, TrendingUp } from 'lucide-react';
import { AhuReport } from '../types';
import { getAhuReportById } from '../services/apiService';
import AhuPerformanceChart from '../components/DualAxisChart';
import AhuEnergyChart from '../components/AhuEnergyChart';
import AhuCostAnalysisChart from '../components/AhuCostAnalysisChart';
import FilterLifeSummary from '../components/FilterLifeSummary';

const StatCard: React.FC<{ icon: React.ReactNode; title: string; value: string; subtitle: string; colorClass: string }> = ({ icon, title, value, subtitle, colorClass }) => (
    <div className="bg-tertiary p-4 rounded-lg flex gap-4">
        <div className={`p-3 rounded-full bg-slate-800 ${colorClass}`}>
            {icon}
        </div>
        <div>
            <p className="text-sm text-slate-400">{title}</p>
            <p className="text-2xl font-bold text-white">{value}</p>
            <p className="text-xs text-slate-500">{subtitle}</p>
        </div>
    </div>
);

const AhuDetailPage: React.FC = () => {
    const { ahuId } = useParams<{ ahuId: string }>();
    const location = useLocation();
    const electricityCost = location.state?.electricityCost || 0.15;

    const [ahuData, setAhuData] = useState<AhuReport | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [viewMode, setViewMode] = useState<'overall' | string>('overall'); // 'overall' or stage.id
    
    useEffect(() => {
        const fetchData = async () => {
            if (!ahuId) return;
            try {
                setLoading(true);
                const data = await getAhuReportById(ahuId);
                if (data) {
                    setAhuData(data);
                } else {
                    setError('AHU not found.');
                }
            } catch (err) {
                setError('Failed to load AHU data.');
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [ahuId]);
    
    const analysisData = useMemo(() => {
        if (!ahuData) return null;
        
        const { historicalData, airflowRate, fanEfficiency, filterStages } = ahuData;
        const daysOfData = historicalData.length;
        if (daysOfData === 0) return null;
        
        const perStageAnalysis = filterStages.map((stage, stageIndex) => {
            let daysInUse = 0;
            let cycleEfficiencySum = 0;
            let cycleDataPoints = 0;

            for(let i = historicalData.length - 1; i >= 0; i--) {
                daysInUse++;
                cycleEfficiencySum += historicalData[i].stageData[stageIndex].efficiency;
                cycleDataPoints++;
                
                if(i > 0 && historicalData[i].stageData[stageIndex].dp < historicalData[i-1].stageData[stageIndex].dp) {
                    break; 
                }
            }
            const averageEfficiency = cycleDataPoints > 0 ? cycleEfficiencySum / cycleDataPoints : 0;
            
            const latestData = historicalData[daysOfData - 1];
            const latestDp = latestData.stageData[stageIndex].dp;
            const life_dp = (latestDp - stage.initialDp) / (250 - stage.initialDp);
            const life_eff = (99.9 - latestData.particleEfficiency) / (99.9 - 95);
            const effectiveLifeConsumed = Math.max(life_dp, life_eff, 0);
            const avgDailyConsumption = effectiveLifeConsumed > 0 ? effectiveLifeConsumed / daysInUse : 0;
            const estimatedDaysRemaining = avgDailyConsumption > 0 ? (1 - effectiveLifeConsumed) / avgDailyConsumption : stage.lifespanDays;
            const predictedTotalLife = daysInUse + estimatedDaysRemaining;
            
            return { daysInUse, averageEfficiency, predictedTotalLife };
        });

        // --- Corrected TCO Calculation Logic ---
        let cumulativeEnergyCost = 0;
        let cumulativeEnergyCostStandard = 0;
        let cumulativeFilterCost = 0;
        let cumulativeFilterCostStandard = 0;

        // Initialize with initial filter costs
        filterStages.forEach(stage => {
            cumulativeFilterCost += stage.cost;
            cumulativeFilterCostStandard += stage.standardFilterCost;
        });
        
        const tcoData = historicalData.map((day, index) => {
            // 1. Calculate and accumulate daily energy costs
            if (fanEfficiency > 0) {
                const powerKw = (airflowRate * 0.000471947 * day.totalDifferentialPressure) / (fanEfficiency / 100) / 1000;
                cumulativeEnergyCost += (powerKw * 24 * electricityCost);
                
                const standardTotalDp = day.standardStageData.reduce((sum, s) => sum + s.dp, 0);
                const powerKwStandard = (airflowRate * 0.000471947 * standardTotalDp) / (fanEfficiency / 100) / 1000;
                cumulativeEnergyCostStandard += (powerKwStandard * 24 * electricityCost);
            }
            
            // 2. Check for filter replacements and add to filter costs
            if (index > 0) {
                const prevDay = historicalData[index - 1];
                filterStages.forEach((stage, stageIndex) => {
                    // Advanced filter replacement
                    if (day.stageData[stageIndex].dp < prevDay.stageData[stageIndex].dp) {
                        cumulativeFilterCost += stage.cost;
                    }
                    // Standard filter replacement
                    if (day.standardStageData[stageIndex].dp < prevDay.standardStageData[stageIndex].dp) {
                        cumulativeFilterCostStandard += stage.standardFilterCost;
                    }
                });
            }

            return {
                timestamp: day.timestamp,
                cumulativeEnergyCost,
                cumulativeEnergyCostStandard,
                cumulativeFilterCost,
                cumulativeFilterCostStandard,
                cumulativeCost: cumulativeEnergyCost + cumulativeFilterCost,
                cumulativeCostStandard: cumulativeEnergyCostStandard + cumulativeFilterCostStandard,
            };
        });

        const totalSavings = tcoData[daysOfData - 1].cumulativeCostStandard - tcoData[daysOfData - 1].cumulativeCost;
        const annualSavings = (totalSavings / daysOfData) * 365;
        
        // This part is for the daily energy chart, separate from TCO
        const dailyEnergyChartData = historicalData.map(day => {
            let dailyEnergyCost = 0;
            let dailyEnergyCostStandard = 0;
            if (fanEfficiency > 0) {
                const powerKw = (airflowRate * 0.000471947 * day.totalDifferentialPressure) / (fanEfficiency / 100) / 1000;
                dailyEnergyCost = powerKw * 24 * electricityCost;
                const standardTotalDp = day.standardStageData.reduce((sum, s) => sum + s.dp, 0);
                const powerKwStandard = (airflowRate * 0.000471947 * standardTotalDp) / (fanEfficiency / 100) / 1000;
                dailyEnergyCostStandard = powerKwStandard * 24 * electricityCost;
            }
            return { timestamp: day.timestamp, dailyEnergyCost, dailyEnergyCostStandard };
        });
        
        return { tcoData, dailyEnergyChartData, annualSavings, perStageAnalysis };
    }, [ahuData, electricityCost]);
    
    if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>;
    if (error) return <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error}</div>;
    if (!ahuData || !analysisData) return <div className="text-center py-10 text-slate-400">No data available for this AHU.</div>;

    const { tcoData, dailyEnergyChartData, annualSavings, perStageAnalysis } = analysisData;
    const latestOverallData = tcoData[tcoData.length - 1];

    return (
        <div className="space-y-6">
            <div>
                <Link to="/ahu-monitoring" className="flex items-center gap-2 text-slate-400 hover:text-white mb-4 transition-colors w-fit">
                    <ArrowLeft className="w-5 h-5" /> Back to AHU Overview
                </Link>
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                    <h1 className="text-3xl sm:text-4xl font-bold text-cyan-400">{ahuData.name}</h1>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                 <StatCard 
                    icon={<DollarSign size={24}/>} 
                    title="Projected Annual Savings"
                    value={`$${annualSavings.toLocaleString(undefined, {maximumFractionDigits: 0})}`}
                    subtitle="Compared to standard filters"
                    colorClass="text-green-400"
                />
                 <StatCard 
                    icon={<Zap size={24}/>} 
                    title="Daily Energy Cost"
                    value={`$${(latestOverallData.cumulativeEnergyCost - (tcoData[tcoData.length - 2]?.cumulativeEnergyCost || 0)).toFixed(2)}`}
                    subtitle={`vs. $${(latestOverallData.cumulativeEnergyCostStandard - (tcoData[tcoData.length - 2]?.cumulativeEnergyCostStandard || 0)).toFixed(2)} standard`}
                    colorClass="text-yellow-400"
                />
                 <StatCard 
                    icon={<TrendingUp size={24}/>} 
                    title="Current Particle Efficiency"
                    value={`${ahuData.historicalData[ahuData.historicalData.length-1].particleEfficiency.toFixed(1)}%`}
                    subtitle={`@ ${ahuData.rosaiqMonitor.targetParticleSize.toUpperCase()}`}
                    colorClass="text-sky-400"
                />
                <StatCard 
                    icon={<Calendar size={24}/>} 
                    title="Data Points Analyzed"
                    value={ahuData.historicalData.length.toString()}
                    subtitle="Over the past year"
                    colorClass="text-slate-400"
                />
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-secondary p-6 rounded-lg">
                    <h2 className="text-xl font-bold text-white mb-4">Total Cost of Ownership (TCO) Analysis</h2>
                     <AhuCostAnalysisChart data={tcoData} />
                </div>
                 <div className="lg:col-span-1 bg-secondary p-6 rounded-lg">
                    <h2 className="text-xl font-bold text-white mb-4">Daily Energy Cost Comparison</h2>
                     <AhuEnergyChart data={dailyEnergyChartData} />
                </div>
            </div>
             <div className="bg-secondary p-6 rounded-lg">
                 <h2 className="text-xl font-bold text-white mb-4">Filter Stage Analysis</h2>
                 <FilterLifeSummary 
                    filterStages={ahuData.filterStages} 
                    perStageAnalysis={perStageAnalysis}
                    targetParticleSize={ahuData.rosaiqMonitor.targetParticleSize}
                />
            </div>

        </div>
    );
};

export default AhuDetailPage;