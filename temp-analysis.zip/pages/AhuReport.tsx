import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2, DollarSign, ArrowDownRight, TrendingUp, Plus, Edit, Trash2, ShieldCheck, Zap } from 'lucide-react';
import { AhuReportData, AhuReport, FilterStage, RosaiqAhsMonitor } from '../types';
import { getAhuFilterReportData, addAhu, updateAhu, deleteAhu } from '../services/apiService';
import AhuConfigModal from '../components/AhuConfigModal';

const SummaryCard: React.FC<{ icon: React.ReactNode; title: string; value: string; unit?: string; color?: string; }> = ({ icon, title, value, unit, color }) => (
  <div className="bg-tertiary p-4 rounded-lg shadow-md flex items-center gap-4">
    <div className="p-3 rounded-full bg-slate-700" style={color ? { color, backgroundColor: `${color}20` } : {}}>
      {icon}
    </div>
    <div>
      <p className="text-2xl font-bold text-white flex items-baseline">
        {value}
        {unit && <span className="text-sm text-slate-400 ml-1">{unit}</span>}
      </p>
      <p className="text-sm text-slate-400">{title}</p>
    </div>
  </div>
);

const EnergyInput: React.FC<{ label: string; value: number; onChange: (value: number) => void; unit: string; }> = ({ label, value, onChange, unit }) => (
    <div>
        <label className="block text-sm font-medium text-slate-300 mb-1">{label}</label>
        <div className="relative">
            <input
                type="number"
                value={value}
                onChange={e => onChange(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded-md pl-3 pr-12 py-2 text-white focus:ring-2 focus:ring-accent-dark focus:outline-none"
            />
            <span className="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-400 text-sm">{unit}</span>
        </div>
    </div>
);

const AhuCard: React.FC<{ 
    ahu: AhuReport; 
    onCardClick: () => void;
    onEdit: () => void;
    onDelete: () => void;
}> = ({ ahu, onCardClick, onEdit, onDelete }) => {
    const latestData = ahu.historicalData[ahu.historicalData.length - 1];
    if (!latestData) return null; // Or some fallback UI
    
    const pressurePercent = Math.min((latestData.totalDifferentialPressure / ahu.totalDpChangeThreshold) * 100, 100);

    const getPressureColor = (percent: number) => {
        if (percent >= 90) return 'bg-red-500';
        if (percent >= 70) return 'bg-yellow-500';
        return 'bg-green-500';
    };

    return (
        <div className="bg-tertiary p-5 rounded-lg shadow-lg flex flex-col group transition-all">
            <div className="flex justify-between items-start mb-4">
                <h3 onClick={onCardClick} className="text-xl font-bold text-white truncate cursor-pointer flex-grow">{ahu.name}</h3>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={(e) => { e.stopPropagation(); onEdit(); }} className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-full"><Edit size={16}/></button>
                    <button onClick={(e) => { e.stopPropagation(); onDelete(); }} className="p-2 text-slate-400 hover:text-red-400 hover:bg-slate-700 rounded-full"><Trash2 size={16}/></button>
                </div>
            </div>
            <div onClick={onCardClick} className="cursor-pointer flex-grow flex flex-col">
                 <div className="my-4">
                    <div className="flex justify-between items-baseline text-xs text-slate-400 mb-1">
                        <span>Total Filter Pressure</span>
                        <span>{latestData.totalDifferentialPressure.toFixed(1)} / {ahu.totalDpChangeThreshold} Pa</span>
                    </div>
                    <div className="w-full bg-slate-700 rounded-full h-2.5">
                        <div className={`h-2.5 rounded-full ${getPressureColor(pressurePercent)}`} style={{ width: `${pressurePercent}%` }}></div>
                    </div>
                </div>
                <div className="grid grid-cols-2 gap-4 text-center border-t border-slate-700 pt-4 mt-auto">
                    <div>
                        <p className="text-2xl font-bold text-white">{pressurePercent.toFixed(0)}<span className="text-lg text-slate-400">%</span></p>
                        <p className={`text-sm font-semibold ${getPressureColor(pressurePercent).replace('bg-','text-')}`}>Pressure Load</p>
                    </div>
                    <div className="flex flex-col items-center">
                        <div className="flex items-baseline">
                            <p className="text-2xl font-bold text-white">{latestData.particleEfficiency.toFixed(1)}<span className="text-lg text-slate-400">%</span></p>
                        </div>
                        <p className="text-sm text-slate-400">Efficiency @ {ahu.rosaiqMonitor.targetParticleSize.toUpperCase()}</p>
                    </div>
                </div>
            </div>
        </div>
    );
};


const AhuReportPage: React.FC = () => {
    const [allAhuData, setAllAhuData] = useState<AhuReportData | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    
    const [configAhu, setConfigAhu] = useState<AhuReport | null>(null);
    const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);

    const [electricityCost, setElectricityCost] = useState(0.15); // $/kWh
    const navigate = useNavigate();

    const fetchData = useCallback(async () => {
        try {
            setLoading(true);
            setError(null);
            const data = await getAhuFilterReportData();
            setAllAhuData(data);
        } catch (err) {
            console.error(err);
            setError("Failed to load AHU monitoring data.");
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchData();
    }, [fetchData]);
    
    const calculateAhuTco = useCallback((ahu: AhuReport) => {
        if (!ahu.airflowRate || !ahu.fanEfficiency || !electricityCost || ahu.fanEfficiency === 0) return { annualSavings: 0 };
        const daysOfData = ahu.historicalData.length;
        if (daysOfData === 0) return { annualSavings: 0 };

        const totalEnergyCostAdvanced = ahu.historicalData.reduce((sum, dayData) => {
            const powerKw = (ahu.airflowRate * 0.000471947 * dayData.totalDifferentialPressure) / (ahu.fanEfficiency / 100) / 1000;
            return sum + (powerKw * 24 * electricityCost);
        }, 0);
        
        const totalFilterReplacementsAdvanced = ahu.filterStages.reduce((sum, stage) => {
            if (stage.lifespanDays <= 0) return sum;
            return sum + (Math.floor(daysOfData / stage.lifespanDays) * stage.cost);
        }, 0);

        const initialCostAdvanced = ahu.filterStages.reduce((sum, stage) => sum + stage.cost, 0);
        const tcoAdvanced = totalEnergyCostAdvanced + totalFilterReplacementsAdvanced + initialCostAdvanced;

        let dailyEnergyCostStandard = 0;
        ahu.filterStages.forEach(stage => {
            const avgDpStandardForStage = (stage.standardFilterInitialDp + stage.standardFilterFinalDp) / 2;
            const powerKwForStage = (ahu.airflowRate * 0.000471947 * avgDpStandardForStage) / (ahu.fanEfficiency / 100) / 1000;
            dailyEnergyCostStandard += (powerKwForStage * 24 * electricityCost);
        });
        
        const totalEnergyCostStandard = dailyEnergyCostStandard * daysOfData;
        
        const totalFilterReplacementsStandard = ahu.filterStages.reduce((sum, stage) => {
             if (stage.standardFilterLifespanDays <= 0) return sum;
             return sum + (Math.floor(daysOfData / stage.standardFilterLifespanDays) * stage.standardFilterCost);
        }, 0);

        const initialCostStandard = ahu.filterStages.reduce((sum, stage) => sum + stage.standardFilterCost, 0);
        const tcoStandard = totalEnergyCostStandard + totalFilterReplacementsStandard + initialCostStandard;

        const totalSavings = tcoStandard - tcoAdvanced;
        const annualSavings = (totalSavings / daysOfData) * 365;

        return { annualSavings };
    }, [electricityCost]);
    
    const aggregatedSummary = useMemo(() => {
        if (!allAhuData) return { totalSavings: 0, dailyConsumption: 0, attentionCount: 0 };

        let totalAnnualSavings = 0;
        let totalDailyEnergyKwh = 0;
        let attentionCount = 0;

        allAhuData.forEach(ahu => {
            if (!ahu.historicalData || ahu.historicalData.length === 0) return;
            
            const { annualSavings } = calculateAhuTco(ahu);
            totalAnnualSavings += annualSavings;
            
            const latestDp = ahu.historicalData[ahu.historicalData.length - 1].totalDifferentialPressure;
            if (ahu.fanEfficiency > 0) {
                 const powerKw = (ahu.airflowRate * 0.000471947 * latestDp) / (ahu.fanEfficiency / 100) / 1000;
                 totalDailyEnergyKwh += (powerKw * 24);
            }

            const pressurePercent = (latestDp / ahu.totalDpChangeThreshold) * 100;
            if (pressurePercent >= 70) {
                attentionCount++;
            }
        });

        return {
            totalSavings: totalAnnualSavings,
            dailyConsumption: totalDailyEnergyKwh,
            attentionCount: attentionCount,
        };
    }, [allAhuData, electricityCost, calculateAhuTco]);

    const handleOpenDetail = (ahu: AhuReport) => {
        navigate(`/ahu-monitoring/${ahu.id}`, { state: { electricityCost } });
    };
    
    const handleOpenConfigModal = (ahu: AhuReport | null) => {
        setConfigAhu(ahu);
        setIsConfigModalOpen(true);
    };

    const handleSaveAhu = async (data: {
        name: string;
        totalDpChangeThreshold: number;
        airflowRate: number;
        fanEfficiency: number;
        filterStages: FilterStage[];
        rosaiqMonitor: RosaiqAhsMonitor;
    }) => {
        if (configAhu) {
            await updateAhu(configAhu.id, data.name, data.totalDpChangeThreshold, data.airflowRate, data.fanEfficiency, data.filterStages, data.rosaiqMonitor);
        } else {
            await addAhu(data.name, data.totalDpChangeThreshold, data.airflowRate, data.fanEfficiency, data.filterStages, data.rosaiqMonitor);
        }
        fetchData();
    };
    
    const handleDeleteAhu = async (ahuId: string) => {
        if (window.confirm("Are you sure you want to delete this AHU? This action is permanent and cannot be undone.")) {
            await deleteAhu(ahuId);
            fetchData();
        }
    };

    if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>;
    if (error) return <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error}</div>;

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold text-white">AHU Filter & Energy Monitoring</h1>
                <p className="text-slate-400 mt-1">Analyze filter lifecycle, energy consumption, and total cost of ownership.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <SummaryCard icon={<DollarSign />} title="Projected Annual Savings" value={`$${aggregatedSummary.totalSavings.toLocaleString(undefined, {maximumFractionDigits: 0})}`} color="#4ade80" />
                <SummaryCard icon={<Zap />} title="Current Daily Consumption" value={aggregatedSummary.dailyConsumption.toLocaleString(undefined, {maximumFractionDigits: 0})} unit="kWh" color="#facc15" />
                <SummaryCard icon={<TrendingUp />} title="Units Monitored" value={allAhuData?.length.toString() || '0'} />
                <SummaryCard icon={<ShieldCheck />} title="Units Needing Attention" value={aggregatedSummary.attentionCount.toString()} color={aggregatedSummary.attentionCount > 0 ? '#ef4444' : '#4ade80'} />
            </div>
            
            <div className="bg-secondary p-4 rounded-lg flex flex-col md:flex-row justify-between md:items-center gap-4">
                <div className="flex items-center gap-4">
                    <EnergyInput label="Electricity Cost" value={electricityCost} onChange={setElectricityCost} unit="$/kWh" />
                </div>
                <button onClick={() => handleOpenConfigModal(null)} className="flex items-center gap-2 px-4 py-2 rounded-md text-white bg-accent hover:bg-accent-dark">
                    <Plus className="w-5 h-5" /> Add New AHU
                </button>
            </div>

            {allAhuData && allAhuData.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                    {allAhuData.map(ahu => (
                        <AhuCard 
                            key={ahu.id} 
                            ahu={ahu}
                            onCardClick={() => handleOpenDetail(ahu)}
                            onEdit={() => handleOpenConfigModal(ahu)}
                            onDelete={() => handleDeleteAhu(ahu.id)}
                        />
                    ))}
                </div>
            ) : (
                <div className="text-center py-16 bg-secondary rounded-lg">
                    <h3 className="text-xl font-semibold text-slate-300">No AHUs Configured</h3>
                    <p className="text-slate-400 mt-2">Add an Air Handling Unit to begin monitoring filter performance.</p>
                </div>
            )}
            
            {isConfigModalOpen && (
                <AhuConfigModal
                    isOpen={isConfigModalOpen}
                    onClose={() => setIsConfigModalOpen(false)}
                    onSave={handleSaveAhu}
                    ahu={configAhu}
                />
            )}
        </div>
    );
};

export default AhuReportPage;