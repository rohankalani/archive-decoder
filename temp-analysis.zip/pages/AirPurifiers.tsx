import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { getDevices } from '../services/apiService';
import { useRealtimeData } from '../contexts/RealtimeDataContext';
import { DeviceWithData } from '../types';
import { Loader2 } from 'lucide-react';
import AirPurifierCard from '../components/AirPurifierCard';


const OFFLINE_THRESHOLD = 30 * 1000;

const AirPurifiers: React.FC = () => {
    const [allDevices, setAllDevices] = useState<DeviceWithData[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const { realtimeData } = useRealtimeData();
    
    const fetchData = useCallback(async () => {
        try {
            setLoading(true);
            const devices = await getDevices();
            setAllDevices(devices);
        } catch (err) {
            setError("Failed to load air purifier data.");
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchData();
    }, [fetchData]);
    
    const purifiers = useMemo(() => {
        const now = Date.now();
        return allDevices
            .filter(d => d.type === 'air-purifier')
            .map(d => {
                const latest_data = realtimeData[d.id] || d.latest_data;
                const lastUpdate = latest_data ? new Date(latest_data.timestamp).getTime() : 0;
                const status: 'online' | 'offline' = (now - lastUpdate) < OFFLINE_THRESHOLD ? 'online' : 'offline';
                return { ...d, latest_data, status };
            });
    }, [allDevices, realtimeData]);

    
    const renderContent = () => {
        if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>;
        if (error) return <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error}</div>;
        
        if (purifiers.length === 0) {
             return (
                <div className="text-center py-16 bg-secondary rounded-lg">
                    <h3 className="text-xl font-semibold text-slate-300">No Air Purifiers Found</h3>
                    <p className="text-slate-400 mt-2">Add and configure purifiers in the Management Console.</p>
                </div>
            );
        }

        return (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {purifiers.map(purifier => (
                    <AirPurifierCard key={purifier.id} purifier={purifier} />
                ))}
            </div>
        );
    };
    
    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold text-white">Connected Air Purifiers</h1>
                <p className="text-slate-400 mt-1">Live operational status of on-demand air purification systems.</p>
            </div>
            
            {renderContent()}
        </div>
    );
};

export default AirPurifiers;