import React, { useMemo } from 'react';
import { useAlerts } from '../contexts/AlertsContext';
import { AlertTriangle, XCircle, Info, CheckCircle } from 'lucide-react';
// FIX: Corrected import path for types.
import { Alert } from '../types';
import AlertCard from '../components/AlertCard';

const SummaryCard: React.FC<{
  icon: React.ReactNode;
  title: string;
  count: number;
  color: string;
}> = ({ icon, title, count, color }) => (
  <div className="bg-secondary p-4 rounded-lg shadow-md flex items-center gap-4">
    <div className={`p-3 rounded-full`} style={{ backgroundColor: `${color}20`, color }}>
      {icon}
    </div>
    <div>
      <p className="text-3xl font-bold text-white">{count}</p>
      <p className="text-sm text-slate-400">{title}</p>
    </div>
  </div>
);

const Alerts: React.FC = () => {
  const { alerts, acknowledgeAlert } = useAlerts();

  const summary = useMemo(() => {
    const counts = {
      critical: 0,
      warning: 0,
      info: 0,
      resolved: 0,
    };
    alerts.forEach(alert => {
      if (alert.status === 'resolved') {
        counts.resolved++;
      } else {
        if (alert.severity in counts) {
          counts[alert.severity]++;
        }
      }
    });
    return counts;
  }, [alerts]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white">Alerts & Notifications</h1>
        <p className="text-slate-400 mt-1">Monitor and manage system alerts and notifications.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <SummaryCard icon={<XCircle />} title="Critical" count={summary.critical} color="#ef4444" />
        <SummaryCard icon={<AlertTriangle />} title="Warning" count={summary.warning} color="#facc15" />
        <SummaryCard icon={<Info />} title="Info" count={summary.info} color="#38bdf8" />
        <SummaryCard icon={<CheckCircle />} title="Resolved" count={summary.resolved} color="#4ade80" />
      </div>

      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-white">Recent Alerts</h2>
        {alerts.length > 0 ? (
          <div className="space-y-4">
            {alerts.map(alert => (
              <AlertCard key={alert.id} alert={alert} onAcknowledge={acknowledgeAlert} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-secondary rounded-lg">
            <h3 className="text-xl font-semibold text-slate-300">All Systems Normal</h3>
            <p className="text-slate-400 mt-2">There are no recent alerts to display.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Alerts;