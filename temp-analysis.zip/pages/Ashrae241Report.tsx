import React, { useState, useEffect, useMemo } from 'react';
import { getAshrae241ReportData, getLocations, getAshrae241Configs, updateAshrae241Config } from '../services/apiService';
import { Ashrae241ReportData, Ashrae241ZoneData, Location, Ashrae241Config } from '../types';
import { Loader2, CheckCircle, XCircle, Shield, Wind, Sun, Filter as FilterIcon, Settings, Edit2, AlertTriangle } from 'lucide-react';
import Ashrae241ConfigModal from '../components/Ashrae241ConfigModal';

const StatCard: React.FC<{ title: string; value: string; color: string; }> = ({ title, value, color }) => (
    <div className="bg-secondary p-4 rounded-lg shadow-md text-center">
        <p className="text-3xl font-bold text-white">{value}</p>
        <p className={`text-sm font-semibold ${color}`}>{title}</p>
    </div>
);

const ZoneCard: React.FC<{ zone: Ashrae241ZoneData; onConfigure: () => void; }> = ({ zone, onConfigure }) => {
    const { isCompliant, infectionRisk, equivalentCleanAirflow, contribution } = zone;
    const progress = equivalentCleanAirflow.target > 0 ? Math.min((equivalentCleanAirflow.current / equivalentCleanAirflow.target) * 100, 100) : 0;

    const getProgressColor = () => {
        if (infectionRisk === 'High') return 'bg-red-500';
        if (infectionRisk === 'Moderate') return 'bg-yellow-500';
        return 'bg-green-500';
    };
    
    const riskConfig = {
        'Low': { color: 'text-green-400', bgColor: 'bg-green-500/10', borderColor: '#4ade80' },
        'Moderate': { color: 'text-yellow-400', bgColor: 'bg-yellow-500/10', borderColor: '#facc15' },
        'High': { color: 'text-red-400', bgColor: 'bg-red-500/10', borderColor: '#ef4444' },
        'Not Configured': { color: 'text-slate-400', bgColor: 'bg-slate-500/10', borderColor: '#64748b' }
    };

    const currentRisk = riskConfig[infectionRisk];

    return (
        <div className="bg-secondary p-6 rounded-lg shadow-lg border-l-4 group" style={{ borderColor: currentRisk.borderColor }}>
            <div className="flex justify-between items-start mb-4">
                <div>
                    <h3 className="text-xl font-bold text-white">{zone.locationName}</h3>
                    <div className={`mt-1 inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-semibold ${currentRisk.bgColor} ${currentRisk.color}`}>
                        {infectionRisk === 'Not Configured' ? <Settings size={14}/> : <Shield size={14} />}
                        {infectionRisk} {infectionRisk !== 'Not Configured' && "Infection Risk"}
                    </div>
                </div>
                <button onClick={onConfigure} className="p-2 text-slate-500 hover:text-white hover:bg-slate-700 rounded-full transition-colors opacity-0 group-hover:opacity-100">
                    <Edit2 className="w-5 h-5"/>
                </button>
            </div>

            {infectionRisk !== 'Not Configured' ? (
                <>
                    <div>
                        <div className="flex justify-between items-baseline text-sm text-slate-300 mb-1">
                            <span>Equivalent Clean Airflow</span>
                            <span>
                                <span className="font-bold text-white text-base">{equivalentCleanAirflow.current}</span> / {equivalentCleanAirflow.target} {equivalentCleanAirflow.unit}
                            </span>
                        </div>
                        <div className="w-full bg-slate-700 rounded-full h-3">
                            <div className={`h-3 rounded-full ${getProgressColor()}`} style={{ width: `${progress}%` }}></div>
                        </div>
                    </div>

                    <div className="mt-6 border-t border-slate-700 pt-4">
                        <h4 className="font-semibold text-slate-300 mb-2">eCACH Contribution</h4>
                        <div className="grid grid-cols-3 gap-4 text-center text-xs">
                            <div className="bg-tertiary p-2 rounded-md">
                                <p className="font-bold text-lg text-white">{contribution.outdoorAir}</p>
                                <p className="text-slate-400 flex items-center justify-center gap-1"><Wind size={12}/>Outdoor Air</p>
                            </div>
                            <div className="bg-tertiary p-2 rounded-md">
                                <p className="font-bold text-lg text-white">{contribution.filtration}</p>
                                <p className="text-slate-400 flex items-center justify-center gap-1"><FilterIcon size={12}/>Filtration</p>
                            </div>
                            <div className="bg-tertiary p-2 rounded-md">
                                <p className="font-bold text-lg text-white">{contribution.inRoomCleaning}</p>
                                <p className="text-slate-400 flex items-center justify-center gap-1"><Sun size={12}/>In-Room</p>
                            </div>
                        </div>
                    </div>
                </>
            ) : (
                <div className="text-center py-8 bg-tertiary rounded-lg">
                    <p className="font-semibold text-slate-300">This zone has not been configured.</p>
                    <button onClick={onConfigure} className="mt-2 text-sm text-accent hover:underline">Configure Now</button>
                </div>
            )}
        </div>
    );
};

const Ashrae241Report: React.FC = () => {
    const [reportData, setReportData] = useState<Ashrae241ReportData | null>(null);
    const [allLocations, setAllLocations] = useState<Location[]>([]);
    const [allConfigs, setAllConfigs] = useState<Ashrae241Config[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [filters, setFilters] = useState({ site: 'all', building: 'all', floor: 'all' });
    
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedLocationId, setSelectedLocationId] = useState<number | null>(null);

    const fetchData = async () => {
        try {
            setLoading(true);
            const [data, locations, configs] = await Promise.all([
                getAshrae241ReportData(),
                getLocations(),
                getAshrae241Configs()
            ]);
            setReportData(data);
            setAllLocations(locations);
            setAllConfigs(configs);
        } catch (err) {
            console.error(err);
            setError("Failed to load ASHRAE 241 compliance data.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    const filterOptions = useMemo(() => {
        const sites = [...new Set(allLocations.map(l => l.site))].sort();
        const buildings = [...new Set(allLocations.filter(l => filters.site === 'all' || l.site === filters.site).map(l => l.building))].sort();
        const floors = [...new Set(allLocations.filter(l => (filters.site === 'all' || l.site === filters.site) && (filters.building === 'all' || l.building === filters.building)).map(l => l.floor))].sort();
        return { sites, buildings, floors };
    }, [allLocations, filters.site, filters.building]);
    
     const handleFilterChange = (filterName: 'site' | 'building' | 'floor', value: string) => {
        setFilters(prev => {
            const newFilters = { ...prev, [filterName]: value };
            if (filterName === 'site') { newFilters.building = 'all'; newFilters.floor = 'all'; }
            if (filterName === 'building') { newFilters.floor = 'all'; }
            return newFilters;
        });
    };

    const filteredReportData = useMemo(() => {
        if (!reportData) return [];
        // FIX: Explicitly typed the Map to avoid type inference issues. Renamed 'location' to 'zoneLocation' to prevent potential name collisions.
        const locationMap = new Map<number, Location>(allLocations.map(l => [l.id, l]));
        return reportData.filter(zone => {
            const zoneLocation = locationMap.get(zone.locationId);
            if (!zoneLocation) return false;
            return (filters.site === 'all' || zoneLocation.site === filters.site) &&
                   (filters.building === 'all' || zoneLocation.building === filters.building) &&
                   (filters.floor === 'all' || zoneLocation.floor === filters.floor);
        });
    }, [reportData, allLocations, filters]);

    const summary = React.useMemo(() => {
        if (!filteredReportData) return { compliant: 0, nonCompliant: 0, total: 0 };
        const configuredZones = filteredReportData.filter(zone => zone.infectionRisk !== 'Not Configured');
        const compliant = configuredZones.filter(zone => zone.isCompliant).length;
        const total = configuredZones.length;
        return { compliant, nonCompliant: total - compliant, total };
    }, [filteredReportData]);
    
    const handleConfigure = (locationId: number | null) => {
        setSelectedLocationId(locationId);
        setIsModalOpen(true);
    };

    const handleSaveConfig = async (config: Ashrae241Config) => {
        await updateAshrae241Config(config);
        fetchData(); // Refetch all data after saving
    };
    
    const renderFilterDropdown = (label: string, name: 'site' | 'building' | 'floor', options: string[]) => (
        <select value={filters[name]} onChange={(e) => handleFilterChange(name, e.target.value)} className="bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white text-sm focus:ring-2 focus:ring-accent-dark focus:outline-none">
            <option value="all">All {label}s</option>
            {options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
        </select>
    );

    if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>;
    if (error) return <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error}</div>;

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-white">ASHRAE 241 - Infection Risk Management</h1>
                    <p className="text-teal-400 mt-1 text-lg">Assess building readiness and control of infectious aerosols in real-time.</p>
                </div>
                <button onClick={() => handleConfigure(null)} className="flex items-center gap-2 px-4 py-2 text-sm rounded-md text-white bg-slate-600 hover:bg-slate-500">
                    <Settings size={16}/> Configure Zones
                </button>
            </div>
            
             <div className="bg-secondary p-2 rounded-lg flex items-center gap-2 flex-wrap">
                {renderFilterDropdown('Site', 'site', filterOptions.sites)}
                {renderFilterDropdown('Building', 'building', filterOptions.buildings)}
                {renderFilterDropdown('Floor', 'floor', filterOptions.floors)}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard title="Configured Zones" value={summary.total.toString()} color="text-slate-300" />
                <StatCard title="Compliant Zones" value={summary.compliant.toString()} color="text-green-400" />
                <StatCard title="Zones Needing Action" value={summary.nonCompliant.toString()} color="text-red-400" />
            </div>

            {filteredReportData.length > 0 ? (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {filteredReportData.map(zone => (
                        <ZoneCard key={zone.locationId} zone={zone} onConfigure={() => handleConfigure(zone.locationId)} />
                    ))}
                </div>
            ) : (
                <div className="text-center py-16 bg-secondary rounded-lg">
                    <h3 className="text-xl font-semibold text-slate-300">No Zones Found</h3>
                    <p className="text-slate-400 mt-2">Your filter selection did not match any monitored zones.</p>
                </div>
            )}
            
            {isModalOpen && (
                <Ashrae241ConfigModal
                    isOpen={isModalOpen}
                    onClose={() => setIsModalOpen(false)}
                    onSave={handleSaveConfig}
                    locations={allLocations}
                    initialConfigs={allConfigs}
                    initialLocationId={selectedLocationId}
                />
            )}
        </div>
    );
};

export default Ashrae241Report;
