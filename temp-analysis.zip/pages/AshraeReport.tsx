import React, { useState, useEffect, useMemo } from 'react';
// FIX: Corrected import path for apiService.
import { getDevices, getRoomConfigurations, updateRoomConfiguration } from '../services/apiService';
import { useRealtimeData } from '../contexts/RealtimeDataContext';
// FIX: Corrected import path for types.
import { DeviceWithData, RoomConfiguration, AshraeSpaceType, RealtimeData } from '../types';
import { Loader2, Settings, Users, Shield, Ruler, X, Info } from 'lucide-react';

type Room = {
    device: DeviceWithData;
    config: RoomConfiguration;
    liveData: RealtimeData | null;
}

const OFFLINE_THRESHOLD = 30 * 1000; // 30 seconds

// --- Configuration Modal ---
const ConfigureRoomModal: React.FC<{
    room: Room;
    isOpen: boolean;
    onClose: () => void;
    onSave: (config: RoomConfiguration) => Promise<void>;
}> = ({ room, isOpen, onClose, onSave }) => {
    const [config, setConfig] = useState<RoomConfiguration>(room.config);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const spaceTypes: AshraeSpaceType[] = ['Not Set', 'Office', 'Conference/Meeting Room', 'Classroom', 'Library', 'Auditorium', 'Retail'];

    useEffect(() => {
      setConfig(room.config);
    }, [room]);

    const handleSave = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        await onSave(config);
        setIsSubmitting(false);
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4 animate-fade-in-scale">
            <div className="bg-secondary rounded-lg shadow-xl w-full max-w-md">
                <form onSubmit={handleSave}>
                    <div className="p-5 border-b border-slate-700 flex justify-between items-center">
                        <div>
                            <h2 className="text-xl font-bold text-white">Configure Room</h2>
                            <p className="text-cyan-400 text-sm">{room.device.location.name}</p>
                        </div>
                        <button type="button" onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-6 h-6" /></button>
                    </div>
                    <div className="p-5 space-y-4">
                        <div>
                            <label htmlFor="space-type" className="block text-sm font-medium text-slate-300 mb-1">Space Type (ASHRAE)</label>
                            <select id="space-type" value={config.spaceType} onChange={e => setConfig(c => ({...c, spaceType: e.target.value as AshraeSpaceType }))} className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white">
                                {spaceTypes.map(t => <option key={t} value={t}>{t}</option>)}
                            </select>
                        </div>
                         <div>
                            <label htmlFor="floor-area" className="block text-sm font-medium text-slate-300 mb-1">Floor Area (sq ft)</label>
                            <input id="floor-area" type="number" value={config.floorArea ?? ''} onChange={e => setConfig(c => ({...c, floorArea: e.target.value ? Number(e.target.value) : null }))} placeholder="e.g., 500" className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" />
                        </div>
                         <div>
                            <label htmlFor="max-occupancy" className="block text-sm font-medium text-slate-300 mb-1">Max Occupancy (IBC)</label>
                            <input id="max-occupancy" type="number" value={config.maxOccupancy ?? ''} onChange={e => setConfig(c => ({...c, maxOccupancy: e.target.value ? Number(e.target.value) : null }))} placeholder="e.g., 12" className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" />
                             <p className="text-xs text-slate-500 mt-1">Legal maximum for fire code and safety.</p>
                        </div>
                        <div className="flex items-start gap-3 p-3 bg-tertiary rounded-md text-sky-300 border border-sky-800/50">
                            <Info className="w-5 h-5 flex-shrink-0 mt-0.5" />
                            <p className="text-sm">Live occupancy is provided by mmWave sensors and does not need to be configured.</p>
                        </div>
                    </div>
                    <div className="p-5 border-t border-slate-700 flex justify-end gap-3">
                        <button type="button" onClick={onClose} className="px-4 py-2 rounded-md text-white bg-slate-600 hover:bg-slate-500">Cancel</button>
                        <button type="submit" disabled={isSubmitting} className="px-4 py-2 rounded-md text-white bg-accent hover:bg-accent-dark disabled:bg-slate-500 flex items-center gap-2">
                            {isSubmitting && <Loader2 className="w-4 h-4 animate-spin"/>}
                            Save
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

// --- Room Card ---
const RoomCard: React.FC<{ room: Room; onConfigure: () => void; }> = ({ room, onConfigure }) => {
    const { device, config, liveData } = room;
    const co2 = liveData?.co2;
    const occupancy = liveData?.occupancy;

    const co2Status = co2 === undefined ? { label: 'N/A', color: 'bg-slate-600', textColor: 'text-slate-400', message: 'Waiting for data...' }
        : co2 < 1000 ? { label: 'ADEQUATE', color: 'bg-green-500/20', textColor: 'text-green-400', message: 'CO₂ suggests good air exchange.' }
        : { label: 'POOR', color: 'bg-red-500/20', textColor: 'text-red-400', message: 'High CO₂ may indicate poor ventilation.' };

    const density = config.floorArea && occupancy !== undefined && occupancy > 0 ? config.floorArea / occupancy : null;
    const capacityPercent = config.maxOccupancy && occupancy !== undefined ? (occupancy / config.maxOccupancy) * 100 : null;

    return (
        <div className="bg-secondary p-6 rounded-lg shadow-lg flex flex-col group">
            <div className="flex justify-between items-start">
                <div>
                    <h3 className="text-xl font-bold text-cyan-400">{device.location.name}</h3>
                    <p className="text-sm text-slate-300">{device.location.building} / {device.location.floor}</p>
                </div>
                <button onClick={onConfigure} className="p-2 text-slate-500 hover:text-white hover:bg-slate-700 rounded-full transition-colors opacity-0 group-hover:opacity-100">
                    <Settings className="w-5 h-5"/>
                </button>
            </div>

            <div className={`my-6 text-center rounded-lg p-4 ${co2Status.color}`}>
                <p className={`text-2xl font-bold tracking-widest ${co2Status.textColor}`}>{co2Status.label}</p>
                <p className="text-sm text-slate-400">{co2Status.message}</p>
            </div>

            <div className="grid grid-cols-3 gap-4 text-center mb-6">
                <div>
                    <p className="text-4xl font-bold text-white">{co2 !== undefined ? co2.toFixed(1) : '--'}</p>
                    <p className="text-sm text-slate-400">CO₂ (ppm)</p>
                </div>
                 <div>
                    <div className="flex items-center justify-center gap-2">
                        <p className="text-4xl font-bold text-white">{occupancy !== undefined ? occupancy.toFixed(0) : '--'}</p>
                        {occupancy !== undefined && <div className="w-3 h-3 rounded-full bg-green-400 animate-pulse mt-1"></div>}
                    </div>
                    <p className="text-sm text-slate-400">Occupancy</p>
                </div>
                 <div>
                    <p className="text-4xl font-bold text-white">{config.floorArea ? config.floorArea.toLocaleString() : 'N/A'}</p>
                    <p className="text-sm text-slate-400">sq ft</p>
                </div>
            </div>

            <div className="border-t border-slate-700 pt-4 mt-auto space-y-4">
                 <div className="flex items-center gap-4">
                    <Users className="w-6 h-6 text-accent"/>
                    <div className="flex-grow">
                        <h4 className="font-semibold text-white flex items-center gap-2 mb-1">
                            <span>Occupant Density</span>
                            <span className="text-xs font-medium bg-cyan-900/50 text-cyan-400 px-2 py-0.5 rounded-full border border-cyan-800">ASHRAE 62.1</span>
                        </h4>
                        {density ? (
                            <p className="text-sm text-slate-300">{density.toFixed(0)} sq ft / person</p>
                        ) : (
                             <p className="text-sm text-slate-500">Configure space type and area for density analysis.</p>
                        )}
                    </div>
                </div>
                <div className="flex items-center gap-4">
                    <Shield className="w-6 h-6 text-accent"/>
                    <div className="flex-grow">
                        <h4 className="font-semibold text-white flex items-center gap-2 mb-1">
                            <span>Safety Capacity</span>
                            <span className="text-xs font-medium bg-cyan-900/50 text-cyan-400 px-2 py-0.5 rounded-full border border-cyan-800">IBC</span>
                        </h4>
                         {capacityPercent !== null ? (
                            <p className="text-sm text-slate-300">At {capacityPercent.toFixed(0)}% of max capacity ({occupancy?.toFixed(0)}/{config.maxOccupancy})</p>
                        ) : (
                             <p className="text-sm text-slate-500">Configure max occupancy for safety analysis.</p>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};


const AshraeReport: React.FC = () => {
    const [allDevices, setAllDevices] = useState<DeviceWithData[]>([]);
    const [roomConfigs, setRoomConfigs] = useState<RoomConfiguration[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const { realtimeData } = useRealtimeData();
    
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);

    const fetchData = async () => {
        try {
            setLoading(true);
            const [devices, configs] = await Promise.all([getDevices(), getRoomConfigurations()]);
            setAllDevices(devices);
            setRoomConfigs(configs);
        } catch (err) {
            console.error(err);
            setError("Failed to load compliance data.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);
    
    const onlineRooms = useMemo<Room[]>(() => {
        const now = Date.now();
        return allDevices.map(device => {
            const liveData = realtimeData[device.id] || null;
            const lastUpdate = liveData ? new Date(liveData.timestamp).getTime() : 0;
            const status: 'online' | 'offline' = (now - lastUpdate) < OFFLINE_THRESHOLD ? 'online' : 'offline';
            
            const config = roomConfigs.find(c => c.locationId === device.location_id) 
                || { locationId: device.location_id, spaceType: 'Not Set', floorArea: null, maxOccupancy: null };

            return { device: {...device, status}, config, liveData };
        })
        .filter(room => room.device.status === 'online' && !room.device.name.toLowerCase().includes('ahu'));
    }, [allDevices, roomConfigs, realtimeData]);


    const handleOpenModal = (room: Room) => {
        setSelectedRoom(room);
        setIsModalOpen(true);
    };

    const handleSaveChanges = async (updatedConfig: RoomConfiguration) => {
        await updateRoomConfiguration(updatedConfig);
        // Refetch configs to update the UI
        const configs = await getRoomConfigurations();
        setRoomConfigs(configs);
    };

    if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>;
    if (error) return <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error}</div>;

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold text-white">ASHRAE 62.1 - Ventilation & Occupancy Compliance</h1>
                <p className="text-teal-400 mt-1 text-lg">Assess ventilation (CO₂), occupant density, and safety capacity in real-time.</p>
            </div>

            {onlineRooms.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                    {onlineRooms.map(room => (
                        <RoomCard key={room.device.id} room={room} onConfigure={() => handleOpenModal(room)} />
                    ))}
                </div>
            ) : (
                <div className="text-center py-16 bg-secondary rounded-lg">
                    <h3 className="text-xl font-semibold text-slate-300">No Online Devices Found</h3>
                    <p className="text-slate-400 mt-2">Waiting for devices to come online to display occupancy data.</p>
                </div>
            )}


            {selectedRoom && (
                <ConfigureRoomModal
                    room={selectedRoom}
                    isOpen={isModalOpen}
                    onClose={() => setIsModalOpen(false)}
                    onSave={handleSaveChanges}
                />
            )}
        </div>
    );
};

export default AshraeReport;