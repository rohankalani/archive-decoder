import React, { useState, useEffect, useMemo } from 'react';
import { getDevices, updateDevice, getAhuFilterReportData } from '../services/apiService';
import { DeviceWithData, GlanceTimePeriod, AhuReport, MajorPollutant } from '../types';
import { useRealtimeData } from '../contexts/RealtimeDataContext';
import SiteOverviewCard, { OverviewData } from '../components/SiteOverviewCard';
import SiteOverviewModal from '../components/SiteOverviewModal';
import { Loader2, Search, X, SlidersHorizontal, LayoutGrid, ArrowLeft } from 'lucide-react';
import DeviceCard from '../components/DeviceCard';
import { useSettings } from '../contexts/SettingsContext';
import { useAlerts } from '../contexts/AlertsContext';
import subDays from 'date-fns/subDays';

type ViewMode = 'glance' | 'detailed';

const OFFLINE_THRESHOLD = 30 * 1000; // 30 seconds
const ELECTRICITY_COST_PER_KWH = 0.15; // $/kWh

const calculateAhuEnergySavings = (ahu: AhuReport) => {
    if (!ahu.airflowRate || !ahu.fanEfficiency || ahu.fanEfficiency === 0) return { annualEnergySavingsKwh: 0 };
    const daysOfData = ahu.historicalData.length;
    if (daysOfData === 0) return { annualEnergySavingsKwh: 0 };

    let totalEnergySavedKwh = 0;

    ahu.historicalData.forEach(dayData => {
        // Advanced filter energy for the day
        const powerKwAdvanced = (ahu.airflowRate * 0.000471947 * dayData.totalDifferentialPressure) / (ahu.fanEfficiency / 100) / 1000;
        const energyKwhAdvanced = powerKwAdvanced * 24;

        // Standard filter energy for the day
        const totalDpStandard = dayData.standardStageData.reduce((sum, stage) => sum + stage.dp, 0);
        const powerKwStandard = (ahu.airflowRate * 0.000471947 * totalDpStandard) / (ahu.fanEfficiency / 100) / 1000;
        const energyKwhStandard = powerKwStandard * 24;
        
        totalEnergySavedKwh += (energyKwhStandard - energyKwhAdvanced);
    });
    
    // The historical data is for 365 days, so totalEnergySavedKwh is the annual savings.
    return { annualEnergySavingsKwh: isNaN(totalEnergySavedKwh) ? 0 : totalEnergySavedKwh };
};

const calculateAhuTcoSavings = (ahu: AhuReport, electricityCost: number): { annualSavings: number } => {
    const { historicalData, airflowRate, fanEfficiency, filterStages } = ahu;
    const daysOfData = historicalData.length;
    if (!airflowRate || !fanEfficiency || !electricityCost || fanEfficiency === 0 || daysOfData === 0) {
        return { annualSavings: 0 };
    }

    let cumulativeEnergyCost = 0;
    let cumulativeEnergyCostStandard = 0;
    let cumulativeFilterCost = 0;
    let cumulativeFilterCostStandard = 0;

    filterStages.forEach(stage => {
        cumulativeFilterCost += stage.cost;
        cumulativeFilterCostStandard += stage.standardFilterCost;
    });

    historicalData.forEach((day, index) => {
        // Energy costs
        if (fanEfficiency > 0) {
            const powerKw = (airflowRate * 0.000471947 * day.totalDifferentialPressure) / (fanEfficiency / 100) / 1000;
            cumulativeEnergyCost += (powerKw * 24 * electricityCost);
            
            const standardTotalDp = day.standardStageData.reduce((sum, s) => sum + s.dp, 0);
            const powerKwStandard = (airflowRate * 0.000471947 * standardTotalDp) / (fanEfficiency / 100) / 1000;
            cumulativeEnergyCostStandard += (powerKwStandard * 24 * electricityCost);
        }

        // Filter replacement costs
        if (index > 0) {
            const prevDay = historicalData[index - 1];
            filterStages.forEach((stage, stageIndex) => {
                if (day.stageData[stageIndex].dp < prevDay.stageData[stageIndex].dp) {
                    cumulativeFilterCost += stage.cost;
                }
                if (day.standardStageData[stageIndex].dp < prevDay.standardStageData[stageIndex].dp) {
                    cumulativeFilterCostStandard += stage.standardFilterCost;
                }
            });
        }
    });

    const cumulativeCost = cumulativeEnergyCost + cumulativeFilterCost;
    const cumulativeCostStandard = cumulativeEnergyCostStandard + cumulativeFilterCostStandard;
    const totalSavings = cumulativeCostStandard - cumulativeCost;
    
    // Historical data is for 365 days, so totalSavings is the annual savings.
    return { annualSavings: isNaN(totalSavings) ? 0 : totalSavings };
};


const AHU_SITE_MAPPING: Record<string, string> = {
    'ahu-01': 'Corporate HQ Bangalore',
    'ahu-02': 'Factory Bangalore',
};


const Dashboard: React.FC = () => {
    const [allDevices, setAllDevices] = useState<DeviceWithData[]>([]);
    const [allAhuData, setAllAhuData] = useState<AhuReport[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const { realtimeData } = useRealtimeData();
    const { getQualityFromAqi, calculateOverallAqi } = useSettings();

    const [searchTerm, setSearchTerm] = useState('');
    const [viewMode, setViewMode] = useState<ViewMode>('glance');
    
    const [isSiteModalOpen, setIsSiteModalOpen] = useState(false);
    const [selectedSiteForModal, setSelectedSiteForModal] = useState<string | null>(null);
    const [timePeriod, setTimePeriod] = useState<GlanceTimePeriod>('30d');
    
    const [detailedFilters, setDetailedFilters] = useState({ site: 'all', building: 'all', block: 'all', floor: 'all' });

    const [glanceViewLevel, setGlanceViewLevel] = useState<'site' | 'building'>('site');
    const [selectedSite, setSelectedSite] = useState<string | null>(null);

    useEffect(() => {
        const fetchAllData = async () => {
            setLoading(true);
            try {
                const [devices, ahus] = await Promise.all([
                    getDevices(),
                    getAhuFilterReportData()
                ]);
                setAllDevices(devices);
                setAllAhuData(ahus);
            } catch (err) {
                setError("Failed to load dashboard data. Please check your connection.");
                console.error(err);
            } finally {
                setLoading(false);
            }
        };
        fetchAllData();
    }, []);
    
    const devicesWithLiveData = useMemo(() => {
        const now = Date.now();
        return allDevices.map(d => {
            const latest_data = realtimeData[d.id] || d.latest_data;
            const lastUpdate = latest_data ? new Date(latest_data.timestamp).getTime() : 0;
            const status: 'online' | 'offline' = (now - lastUpdate) < OFFLINE_THRESHOLD ? 'online' : 'offline';
            return { ...d, latest_data, status };
        });
    }, [allDevices, realtimeData]);
    
    const aggregatedSiteData = useMemo(() => {
        const sites: Record<string, { devices: DeviceWithData[] }> = {};
        devicesWithLiveData.forEach(d => {
            const siteName = d.location.site;
            if (!sites[siteName]) sites[siteName] = { devices: [] };
            sites[siteName].devices.push(d);
        });

        // Generate mock historical data for all devices for the last 30 days
        const mockHistorical = allDevices.reduce((acc, device) => {
            const history = Array.from({ length: 30 }, (_, i) => {
                const date = subDays(new Date(), 29 - i);
                const pointData = {
                    pm25: 10 + Math.random() * 25,
                    co2: 450 + Math.random() * 200,
                    voc: 50 + Math.random() * 150,
                };
                const { aqi, dominantPollutant } = calculateOverallAqi(pointData);
                return { aqi, dominantPollutant: dominantPollutant as MajorPollutant | null };
            });
            acc[device.id] = history;
            return acc;
        }, {} as Record<string, { aqi: number, dominantPollutant: MajorPollutant | null }[]>);


        return Object.entries(sites).map(([name, data]) => {
            let totalAqiSum = 0;
            const pollutantCounts: Record<string, number> = { pm25: 0, co2: 0, voc: 0, hcho: 0, nox: 0, pm10: 0 };
            let totalPoints = 0;

            data.devices.forEach(device => {
                const history = mockHistorical[device.id];
                if (history) {
                    history.forEach(point => {
                        totalAqiSum += point.aqi;
                        if (point.dominantPollutant && pollutantCounts[point.dominantPollutant] !== undefined) {
                            pollutantCounts[point.dominantPollutant]++;
                        }
                        totalPoints++;
                    });
                }
            });

            const avgAqi30d = totalPoints > 0 ? totalAqiSum / totalPoints : 0;
            const dominantPollutant30d = Object.keys(pollutantCounts).reduce((a, b) => pollutantCounts[a] > pollutantCounts[b] ? a : b, 'pm25') as MajorPollutant;

            const siteAhus = allAhuData.filter(ahu => AHU_SITE_MAPPING[ahu.id] === name);
            const cumulativeEnergySavingsKwh = siteAhus.reduce((sum, ahu) => {
                const { annualEnergySavingsKwh } = calculateAhuEnergySavings(ahu);
                return sum + annualEnergySavingsKwh;
            }, 0);

            const cumulativeTcoSavings = siteAhus.reduce((sum, ahu) => {
                const { annualSavings } = calculateAhuTcoSavings(ahu, ELECTRICITY_COST_PER_KWH);
                return sum + annualSavings;
            }, 0);

            const compliance = {
                ashrae62: 80 + Math.random() * 20,
                ashrae241: 75 + Math.random() * 25,
                leed: 85 + Math.random() * 15,
                well: 90 + Math.random() * 10,
                reset: 88 + Math.random() * 12,
            };

            const trends: ('improving' | 'steady' | 'worsening')[] = ['improving', 'steady', 'worsening'];
            const aqiTrendVsLastYear = trends[Math.floor(Math.random() * trends.length)];
            
            return {
                name,
                level: 'site' as const,
                deviceCount: data.devices.length,
                avgAqi30d,
                aqiQuality: getQualityFromAqi(avgAqi30d),
                dominantPollutant30d,
                aqiTrendVsLastYear,
                cumulativeEnergySavingsKwh,
                cumulativeTcoSavings,
                compliance,
            };
        });
    }, [devicesWithLiveData, allAhuData, allDevices, calculateOverallAqi, getQualityFromAqi]);
    
    const aggregatedBuildingData = useMemo<OverviewData[]>(() => {
        if (!selectedSite) return [];

        const siteDevices = devicesWithLiveData.filter(d => d.location.site === selectedSite);
        const buildings: Record<string, { devices: DeviceWithData[] }> = {};
        siteDevices.forEach(d => {
            const buildingName = d.location.building;
            if (!buildings[buildingName]) buildings[buildingName] = { devices: [] };
            buildings[buildingName].devices.push(d);
        });

        return Object.entries(buildings).map(([name, data]) => {
            const avgAqi30d = data.devices.reduce((sum, d) => sum + (d.latest_data?.iaqi || 0), 0) / data.devices.length || 0;
            
            // Note: For this drill-down, we'll use simplified mock data. A real implementation would fetch building-specific historicals.
            const compliance = {
                ashrae62: 70 + Math.random() * 30,
                ashrae241: 65 + Math.random() * 35,
                leed: 75 + Math.random() * 25,
                well: 80 + Math.random() * 20,
                reset: 78 + Math.random() * 22,
            };
            const trends: ('improving' | 'steady' | 'worsening')[] = ['improving', 'steady', 'worsening'];
            const aqiTrendVsLastYear = trends[Math.floor(Math.random() * trends.length)];
            
            return {
                name,
                level: 'building' as const,
                deviceCount: data.devices.length,
                avgAqi30d,
                aqiQuality: getQualityFromAqi(avgAqi30d),
                dominantPollutant30d: 'pm25' as MajorPollutant,
                aqiTrendVsLastYear,
                cumulativeEnergySavingsKwh: (1000 + Math.random() * 5000) * data.devices.length,
                cumulativeTcoSavings: (500 + Math.random() * 2000) * data.devices.length,
                compliance,
            };
        });
    }, [devicesWithLiveData, selectedSite, getQualityFromAqi]);

    const detailedFilterOptions = useMemo(() => {
        const locations = devicesWithLiveData.map(d => d.location);
        const sites = [...new Set(locations.map(l => l.site))].sort();
        const buildings = [...new Set(locations.filter(l => detailedFilters.site === 'all' || l.site === detailedFilters.site).map(l => l.building))].sort();
        const blocks = [...new Set(locations.filter(l => (detailedFilters.site === 'all' || l.site === detailedFilters.site) && (detailedFilters.building === 'all' || l.building === detailedFilters.building)).map(l => l.block))].sort();
        const floors = [...new Set(locations.filter(l => (detailedFilters.site === 'all' || l.site === detailedFilters.site) && (detailedFilters.building === 'all' || l.building === detailedFilters.building) && (detailedFilters.block === 'all' || l.block === detailedFilters.block)).map(l => l.floor))].sort();
        return { sites, buildings, blocks, floors };
    }, [devicesWithLiveData, detailedFilters.site, detailedFilters.building, detailedFilters.block]);

    const handleDetailedFilterChange = (filterName: 'site' | 'building' | 'block' | 'floor', value: string) => {
        setDetailedFilters(prev => {
            const newFilters = { ...prev, [filterName]: value };
            if (filterName === 'site') { newFilters.building = 'all'; newFilters.block = 'all'; newFilters.floor = 'all'; }
            if (filterName === 'building') { newFilters.block = 'all'; newFilters.floor = 'all'; }
            if (filterName === 'block') { newFilters.floor = 'all'; }
            return newFilters;
        });
    };

    const filteredDetailedDevices = useMemo(() => {
        return devicesWithLiveData.filter(d => {
            if (d.type === 'air-purifier') {
                return false;
            }
            const lowercasedTerm = searchTerm.toLowerCase();
            const matchesSearch = !searchTerm ||
                d.name.toLowerCase().includes(lowercasedTerm) ||
                d.location.name.toLowerCase().includes(lowercasedTerm);

            const { site, building, block, floor } = detailedFilters;
            const matchesFilters = (site === 'all' || d.location.site === site) &&
                   (building === 'all' || d.location.building === building) &&
                   (block === 'all' || d.location.block === block) &&
                   (floor === 'all' || d.location.floor === floor);
            
            return matchesSearch && matchesFilters;
        });
    }, [devicesWithLiveData, searchTerm, detailedFilters]);
    
    const filteredGlanceData = useMemo(() => {
        const data = glanceViewLevel === 'site' ? aggregatedSiteData : aggregatedBuildingData;
        if (!searchTerm) return data;
        const lowercasedTerm = searchTerm.toLowerCase();
        return data.filter(item => item.name.toLowerCase().includes(lowercasedTerm));
    }, [aggregatedSiteData, aggregatedBuildingData, searchTerm, glanceViewLevel]);

    const handleUpdateDeviceName = async (id: string, newName: string) => {
        try {
            const deviceToUpdate = allDevices.find(d => d.id === id);
            if (!deviceToUpdate) return;
            const updatedDevice = await updateDevice(id, newName, deviceToUpdate.location_id);
            setAllDevices(prev => prev.map(d => d.id === id ? { ...d, name: updatedDevice.name } : d));
        } catch (error) {
            console.error("Failed to update device name:", error);
        }
    };
    
    const handleSiteCardClick = (siteName: string) => {
        setSelectedSiteForModal(siteName);
        setIsSiteModalOpen(true);
    };

    const handleViewBuildingsClick = (siteName: string) => {
        setGlanceViewLevel('building');
        setSelectedSite(siteName);
    };

    const handleBackToSites = () => {
        setGlanceViewLevel('site');
        setSelectedSite(null);
    };

    const renderFilterDropdown = (label: string, name: 'site' | 'building' | 'block' | 'floor', options: string[]) => (
        <select value={detailedFilters[name]} onChange={(e) => handleDetailedFilterChange(name, e.target.value)} className="bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white text-sm focus:ring-2 focus:ring-accent-dark focus:outline-none">
            <option value="all">All {label}s</option>
            {options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
        </select>
    );

    const renderDetailedView = () => {
        const groupedBySite = filteredDetailedDevices.reduce((acc, device) => {
            const site = device.location.site || 'Unassigned Site';
            if (!acc[site]) acc[site] = [];
            acc[site].push(device);
            return acc;
        }, {} as Record<string, DeviceWithData[]>);

        const siteSortOrder = ['Corporate HQ Bangalore', 'Factory Bangalore', 'Factory Pune', 'GCC Delhi'];
        const sortedSites = Object.keys(groupedBySite).sort((a, b) => {
            const indexA = siteSortOrder.indexOf(a);
            const indexB = siteSortOrder.indexOf(b);
            if (indexA !== -1 && indexB !== -1) return indexA - indexB;
            if (indexA !== -1) return -1;
            if (indexB !== -1) return 1;
            return a.localeCompare(b);
        });

        return (
            <div className="space-y-8">
                {sortedSites.map(siteName => {
                    const siteDevices = groupedBySite[siteName];
                    const groupedByBuilding = siteDevices.reduce((acc, device) => {
                        const building = device.location.building || 'Unassigned Building';
                        if (!acc[building]) acc[building] = [];
                        acc[building].push(device);
                        return acc;
                    }, {} as Record<string, DeviceWithData[]>);

                    return (
                        <div key={siteName}>
                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 pb-2 border-b-2 border-slate-700">{siteName}</h2>
                            <div className="space-y-6">
                                {Object.keys(groupedByBuilding).sort().map(buildingName => (
                                    <div key={buildingName}>
                                        <h3 className="text-xl font-semibold text-slate-300 px-2 mb-4">{buildingName}</h3>
                                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                                            {groupedByBuilding[buildingName].sort((a, b) => a.name.localeCompare(b.name)).map(device => (
                                                <DeviceCard key={device.id} device={device} onUpdateName={handleUpdateDeviceName} />
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    );
                })}
                {filteredDetailedDevices.length === 0 && (
                     <div className="text-center py-16 bg-secondary rounded-lg">
                        <h3 className="text-xl font-semibold text-slate-300">No Devices Found</h3>
                        <p className="text-slate-400 mt-2">Your search and filters did not match any devices.</p>
                    </div>
                )}
            </div>
        );
    };
    
    const renderGlanceView = () => (
        <>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {filteredGlanceData.sort((a, b) => a.name.localeCompare(b.name)).map(data => (
                    <SiteOverviewCard
                        key={data.name}
                        data={data}
                        onViewBuildingsClick={() => handleViewBuildingsClick(data.name)}
                        onSiteDetailsClick={() => handleSiteCardClick(glanceViewLevel === 'site' ? data.name : selectedSite!)}
                    />
                ))}
            </div>
            {filteredGlanceData.length === 0 && <div className="text-center py-16 bg-secondary rounded-lg"><h3 className="text-xl font-semibold text-slate-300">No {glanceViewLevel === 'site' ? 'Sites' : 'Buildings'} Found</h3><p className="text-slate-400 mt-2">Your search did not match any item.</p></div>}
        </>
    );
    
    const getTitle = () => {
        if (viewMode === 'detailed') return 'Detailed Device View';
        if (glanceViewLevel === 'building') return `Building Overview: ${selectedSite}`;
        return 'Site Overview';
    };

    if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>;
    if (error) return <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error}</div>;

    return (
        <div className="space-y-6">
            {isSiteModalOpen && selectedSiteForModal && (
                <SiteOverviewModal
                    siteName={selectedSiteForModal}
                    timePeriod={timePeriod}
                    isOpen={isSiteModalOpen}
                    onClose={() => setIsSiteModalOpen(false)}
                />
            )}
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                 <div className="flex items-center gap-4">
                    <h1 className="text-3xl font-bold text-white">{getTitle()}</h1>
                 </div>
                 <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400"/>
                    <input type="text" placeholder="Search..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full sm:w-64 bg-secondary border border-slate-700 rounded-full pl-10 pr-10 py-2 text-white focus:ring-2 focus:ring-accent-dark focus:outline-none"/>
                    {searchTerm && <button onClick={() => setSearchTerm('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"><X className="w-5 h-5"/></button>}
                 </div>
            </div>
            
            <div className="bg-secondary p-2 rounded-lg flex items-center justify-between flex-wrap gap-2">
                 <div className="flex items-center gap-2">
                    {viewMode === 'glance' && glanceViewLevel === 'building' && (
                        <button onClick={handleBackToSites} className="flex items-center gap-2 px-3 py-1 text-sm font-semibold rounded-full hover:bg-slate-600">
                            <ArrowLeft size={16}/> Back to All Sites
                        </button>
                    )}
                    <div className="flex items-center gap-1 bg-tertiary p-1 rounded-full">
                        <button onClick={() => setViewMode('glance')} className={`flex items-center gap-2 px-3 py-1 text-sm font-semibold rounded-full ${viewMode === 'glance' ? 'bg-accent text-white' : 'hover:bg-slate-600'}`}><LayoutGrid size={16}/>Glance</button>
                        <button onClick={() => setViewMode('detailed')} className={`flex items-center gap-2 px-3 py-1 text-sm font-semibold rounded-full ${viewMode === 'detailed' ? 'bg-accent text-white' : 'hover:bg-slate-600'}`}><SlidersHorizontal size={16}/>Detailed</button>
                    </div>
                 </div>
                 {viewMode === 'detailed' && (
                    <div className="flex items-center gap-2 flex-wrap">
                        {renderFilterDropdown('Site', 'site', detailedFilterOptions.sites)}
                        {renderFilterDropdown('Building', 'building', detailedFilterOptions.buildings)}
                        {renderFilterDropdown('Block', 'block', detailedFilterOptions.blocks)}
                        {renderFilterDropdown('Floor', 'floor', detailedFilterOptions.floors)}
                    </div>
                 )}
            </div>

            {viewMode === 'glance' ? renderGlanceView() : renderDetailedView()}
        </div>
    );
};

export default Dashboard;