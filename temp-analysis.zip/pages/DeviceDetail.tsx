import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
// FIX: Corrected import path for apiService.
import { getDevice, getHistoricalData } from '../services/apiService';
import { useRealtimeData } from '../contexts/RealtimeDataContext';
import { useSettings } from '../contexts/SettingsContext';
// FIX: Corrected import path for types.
import { DeviceWithData, HistoricalData, Metric, ChartAggregation } from '../types';
import { Loader2, ArrowLeft, Calendar, Download } from 'lucide-react';
import { DateRange, DayPicker } from 'react-day-picker';
// FIX: Changed date-fns imports to use subpaths for functions not exported from the root module, resolving import errors.
import { format } from 'date-fns';
import subDays from 'date-fns/subDays';

import HistoricalChart from '../components/HistoricalChart';
import AqiSubIndexChart from '../components/AqiSubIndexChart';
import TimezoneSelector from '../components/TimezoneSelector';
import { exportToExcel } from '../services/exportService';
import MetricDisplay from '../components/MetricDisplay';


const DateRangePicker: React.FC<{ range: DateRange | undefined; onRangeChange: (range: DateRange | undefined) => void }> = ({ range, onRangeChange }) => {
    const [isOpen, setIsOpen] = useState(false);
    const pickerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (pickerRef.current && !pickerRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);
    
    const handleSelect = (selectedRange: DateRange | undefined) => {
        onRangeChange(selectedRange);
        // Close picker only if a full range is selected
        if (selectedRange?.from && selectedRange?.to) {
            setIsOpen(false);
        }
    }

    return (
        <div className="relative" ref={pickerRef}>
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="flex items-center gap-2 p-2 bg-tertiary rounded-full text-sm text-slate-300 hover:bg-slate-700 transition-colors"
                aria-haspopup="dialog"
                aria-expanded={isOpen}
            >
                <Calendar className="w-4 h-4 text-slate-400" />
                <span>
                    {range?.from ? format(range.from, 'LLL dd, y') : 'Start Date'} - {range?.to ? format(range.to, 'LLL dd, y') : 'End Date'}
                </span>
            </button>
            {isOpen && (
                <div className="absolute top-full mt-2 z-30 bg-secondary rounded-lg border border-slate-700 p-2 shadow-2xl">
                    <style>{`
                        .rdp {
                            --rdp-cell-size: 38px;
                            --rdp-caption-font-size: 1rem;
                            --rdp-background-color: transparent;
                            --rdp-color: #e2e8f0; /* slate-200 */
                            --rdp-accent-color: #38bdf8; /* sky-400 */
                            --rdp-accent-color-dark: #0ea5e9; /* sky-500 */
                        }
                        .rdp-button:hover:not([disabled]):not(.rdp-day_selected) {
                            background-color: #1e293b; /* slate-800 */
                        }
                        .rdp-day_today {
                            font-weight: bold;
                            color: var(--rdp-accent-color);
                        }
                        .rdp-day_selected, .rdp-day_selected:focus-visible, .rdp-day_selected:hover {
                           background-color: var(--rdp-accent-color);
                           color: #0b111c; /* slate-950 */
                        }
                        .rdp-nav_button:hover {
                             background-color: #1e293b; /* slate-800 */
                        }
                        .rdp-caption_label {
                           font-weight: 600;
                           color: #f1f5f9; /* slate-100 */
                        }
                        .rdp-head_cell {
                           color: #94a3b8; /* slate-400 */
                           font-size: 0.8rem;
                        }
                     `}</style>
                    <DayPicker
                        mode="range"
                        selected={range}
                        onSelect={handleSelect}
                        numberOfMonths={1}
                        defaultMonth={range?.from}
                        showOutsideDays
                        fixedWeeks
                    />
                </div>
            )}
        </div>
    );
};

// --- Metric Details ---
// FIX: Added 'dp', 'presence', 'smoke_vape_detected', 'battery', 'fan_speed' and 'filter_life' to satisfy the Record<Metric, ...> type.
const METRIC_DETAILS: Record<Metric, { name: string, unit: string }> = {
    iaqi: { name: 'IAQI', unit: '' },
    pm25: { name: 'PM2.5', unit: 'µg/m³' },
    pm10: { name: 'PM10', unit: 'µg/m³' },
    co2: { name: 'CO₂', unit: 'ppm' },
    temp: { name: 'Temp', unit: '°C' },
    humidity: { name: 'Humidity', unit: '%' },
    voc: { name: 'VOC', unit: 'index' },
    hcho: { name: 'HCHO', unit: 'ppb' },
    nox: { name: 'NOx', unit: 'index' },
    pm03: { name: 'PM0.3', unit: 'µg/m³' },
    pm1: { name: 'PM1', unit: 'µg/m³' },
    pm5: { name: 'PM5', unit: 'µg/m³' },
    pc03: { name: 'PC0.3', unit: '#/ft³' },
    pc05: { name: 'PC0.5', unit: '#/ft³' },
    pc1: { name: 'PC1', unit: '#/ft³' },
    pc25: { name: 'PC2.5', unit: '#/ft³' },
    pc5: { name: 'PC5', unit: '#/ft³' },
    pc10: { name: 'PC10', unit: '#/ft³' },
    occupancy: { name: 'Occupancy', unit: 'people' },
    dp: { name: 'Diff. Pressure', unit: 'Pa' },
    presence: { name: 'Presence', unit: '' },
    smoke_vape_detected: { name: 'Smoke/Vape', unit: '' },
    battery: { name: 'Battery', unit: '%' },
    fan_speed: { name: 'Fan Speed', unit: '%' },
    filter_life: { name: 'Filter Life', unit: '%' },
};

const chartMetrics: Record<string, Metric[]> = {
    pollutants: ['iaqi', 'pm25', 'pm10', 'co2'],
    environment: ['temp', 'humidity', 'voc', 'hcho'],
    particles: ['pm03', 'pm1', 'pm25', 'pm5', 'pm10'],
    particle_counts: ['pc03', 'pc05', 'pc1', 'pc25', 'pc5', 'pc10'],
};


const DeviceDetail: React.FC = () => {
    const { deviceId } = useParams<{ deviceId: string }>();
    const { realtimeData } = useRealtimeData();
    const { getMetricQuality, calculateOverallAqi, calculateAllSubIndices, unitSystem, convertValue } = useSettings();
    
    const [device, setDevice] = useState<DeviceWithData | null>(null);
    const [historicalData, setHistoricalData] = useState<HistoricalData[]>([]);
    const [pageLoading, setPageLoading] = useState(true);
    const [chartLoading, setChartLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const [aggregation, setAggregation] = useState<ChartAggregation>('1h');
    const [dateRange, setDateRange] = useState<DateRange | undefined>({ from: subDays(new Date(), 7), to: new Date() });
    const [timezone, setTimezone] = useState<string>(() => {
        try {
            return Intl.DateTimeFormat().resolvedOptions().timeZone;
        } catch (e) { return "UTC"; }
    });

    const liveData = deviceId ? realtimeData[deviceId] : null;
    const isOnline = liveData && (Date.now() - new Date(liveData.timestamp).getTime()) < 30000;

    useEffect(() => {
        const fetchDeviceDetails = async () => {
            if (!deviceId) return;
            try {
                setPageLoading(true);
                const deviceDetails = await getDevice(deviceId);
                setDevice(deviceDetails);
            } catch (err) {
                setError('Failed to fetch device details.');
                console.error(err);
            } finally {
                setPageLoading(false);
            }
        };
        fetchDeviceDetails();
    }, [deviceId]);

    useEffect(() => {
        const fetchHistorical = async () => {
            if (!deviceId || !dateRange?.from || !dateRange?.to) return;
            setChartLoading(true);
            try {
                const data = await getHistoricalData(deviceId, dateRange.from.toISOString(), dateRange.to.toISOString(), aggregation);
                setHistoricalData(data);
            } catch (err) {
                setError('Failed to load historical data.');
            } finally {
                setChartLoading(false);
            }
        };
        fetchHistorical();
    }, [deviceId, dateRange, aggregation]);

    const handleExport = useCallback(() => {
        if (device && historicalData.length > 0) {
            exportToExcel(device.name, historicalData, getMetricQuality, unitSystem, convertValue);
        } else {
            alert("No data available to export.");
        }
    }, [device, historicalData, getMetricQuality, unitSystem, convertValue]);

    const { aqi, quality } = calculateOverallAqi(liveData);
    
    const aqiSubIndexData = useMemo(() => {
        return historicalData.map(d => {
            const indices = calculateAllSubIndices(d);
            const overall = calculateOverallAqi(d);
            return {
                timestamp: d.timestamp,
                'Overall AQI': overall.aqi,
                'PM2.5': indices.pm25, 'PM10': indices.pm10,
                'HCHO': indices.hcho, 'VOC': indices.voc, 'NOx': indices.nox,
            };
        });
    }, [historicalData, calculateAllSubIndices, calculateOverallAqi]);

    const getMetricProps = (metric: Metric) => {
        const details = METRIC_DETAILS[metric];
        const rawValue = liveData?.[metric];
        const value = (rawValue !== undefined && rawValue !== null) ? rawValue : undefined;
        const { color } = getMetricQuality(metric, value ?? 0);
        return { 
            label: details.name, 
            value: value, 
            unit: details.unit, 
            color,
            size: 'normal' as const,
        };
    };

    if (pageLoading && !device) {
        return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>;
    }
    if (error) {
        return <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error}</div>;
    }
    if (!device) {
        return <div className="text-center py-10 text-slate-400">Device not found.</div>;
    }
    
    return (
        <div className="space-y-6">
            <div>
                <Link to="/" className="flex items-center gap-2 text-slate-400 hover:text-white mb-4 transition-colors w-fit">
                    <ArrowLeft className="w-5 h-5" /> Back to Dashboard
                </Link>
                <div className="flex justify-between items-start">
                    <div>
                         <p className="text-slate-300">{device.location.name} - {device.location.floor}</p>
                        <h1 className="text-3xl sm:text-4xl font-bold text-teal-400">{device.name}</h1>
                    </div>
                </div>
            </div>

            {/* --- Live Metrics Grid --- */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                    {/* Key Metrics */}
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-8">
                        <MetricDisplay {...getMetricProps('temp')} />
                        <MetricDisplay {...getMetricProps('humidity')} />
                        <MetricDisplay {...getMetricProps('co2')} />
                        <MetricDisplay {...getMetricProps('voc')} />
                        <MetricDisplay {...getMetricProps('hcho')} />
                        <MetricDisplay {...getMetricProps('nox')} />
                    </div>

                    {/* Separator */}
                    <div className="my-8 w-1/3 mx-auto h-px bg-gradient-to-r from-transparent via-teal-400 to-transparent"></div>

                    {/* Particulate Matter */}
                    <div>
                        <h2 className="text-sm font-semibold tracking-widest text-slate-400 uppercase mb-4">Particulate Matter (µg/m³)</h2>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-x-6 gap-y-8">
                            <MetricDisplay {...getMetricProps('pm03')} />
                            <MetricDisplay {...getMetricProps('pm1')} />
                            <MetricDisplay {...getMetricProps('pm25')} />
                            <MetricDisplay {...getMetricProps('pm5')} />
                            <MetricDisplay {...getMetricProps('pm10')} />
                        </div>
                    </div>
                    
                    {/* Separator */}
                    <div className="my-8 w-1/3 mx-auto h-px bg-gradient-to-r from-transparent via-teal-400 to-transparent"></div>

                    {/* Particle Count */}
                    <div>
                        <h2 className="text-sm font-semibold tracking-widest text-slate-400 uppercase mb-4">Particle Count (#/FT³)</h2>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-x-6 gap-y-8">
                            <MetricDisplay {...getMetricProps('pc03')} />
                            <MetricDisplay {...getMetricProps('pc05')} />
                            <MetricDisplay {...getMetricProps('pc1')} />
                            <MetricDisplay {...getMetricProps('pc25')} />
                            <MetricDisplay {...getMetricProps('pc5')} />
                            <MetricDisplay {...getMetricProps('pc10')} />
                        </div>
                    </div>
                </div>

                <div className="lg:col-span-1 flex flex-col items-center justify-center p-4">
                    <div className="relative w-56 h-56 flex items-center justify-center">
                        <svg className="absolute w-full h-full" viewBox="0 0 100 100">
                            <circle cx="50" cy="50" r="45" stroke="#334155" strokeWidth="5" fill="none" />
                            <circle
                                cx="50" cy="50" r="45"
                                stroke={isOnline ? quality.color : '#475569'}
                                strokeWidth="5" fill="none"
                                strokeDasharray="283" strokeDashoffset="0"
                                strokeLinecap="round"
                                transform="rotate(-90 50 50)"
                                style={{ transition: 'stroke 0.5s ease-in-out' }}
                            />
                        </svg>
                         <div
                            className="absolute inset-0 rounded-full"
                            style={{
                                boxShadow: isOnline ? `0 0 25px ${quality.color}, inset 0 0 15px ${quality.color}40` : 'none',
                                transition: 'box-shadow 0.5s ease-in-out'
                            }}
                        ></div>
                        <span className="relative text-7xl font-bold text-white">{isOnline ? aqi : '--'}</span>
                    </div>
                    <p className={`text-xl font-bold uppercase tracking-widest mt-4 ${!isOnline ? 'text-slate-500' : ''}`} style={isOnline ? { color: quality.color } : {}}>
                        {isOnline ? quality.label : 'Offline'}
                    </p>
                    <p className="text-xs text-slate-500 mt-auto pt-8">ID: {device.id}</p>
                </div>
            </div>

            {/* --- Chart Controls --- */}
            <div className="bg-secondary p-4 rounded-lg flex flex-col md:flex-row justify-between md:items-center gap-4">
                <div className="flex items-center gap-2 flex-wrap">
                    <DateRangePicker range={dateRange} onRangeChange={setDateRange} />
                    <div className="flex items-center gap-1 bg-tertiary p-1 rounded-full">
                        {(['1h', '8h', '1d'] as ChartAggregation[]).map(agg => (
                            <button key={agg} onClick={() => setAggregation(agg)} className={`px-3 py-1 text-sm font-semibold rounded-full transition-all duration-200 ${aggregation === agg ? 'bg-accent text-white' : 'bg-transparent text-slate-300 hover:bg-slate-600'}`}>
                                {agg}
                            </button>
                        ))}
                    </div>
                    <TimezoneSelector value={timezone} onChange={setTimezone} />
                </div>
                <button onClick={handleExport} className="flex items-center justify-center gap-2 px-4 py-2 rounded-full text-white bg-accent hover:bg-accent-dark transition-colors">
                    <Download className="w-4 h-4" /> Export Data
                </button>
            </div>
            
            {/* --- Charts --- */}
            <div className="space-y-6">
                 {chartLoading ? (
                    <div className="flex justify-center items-center h-48"><Loader2 className="w-6 h-6 text-accent animate-spin" /></div>
                 ) : (
                    <>
                        <HistoricalChart data={historicalData} metrics={chartMetrics.pollutants} metricDetails={METRIC_DETAILS} title="Key Pollutants" aggregation={aggregation} timezone={timezone} />
                        <AqiSubIndexChart data={aqiSubIndexData} aggregation={aggregation} timezone={timezone} />
                        <HistoricalChart data={historicalData} metrics={chartMetrics.environment} metricDetails={METRIC_DETAILS} title="Environmental Conditions" aggregation={aggregation} timezone={timezone} />
                        <HistoricalChart data={historicalData} metrics={chartMetrics.particles} metricDetails={METRIC_DETAILS} title="Particulate Matter (Mass)" aggregation={aggregation} timezone={timezone} />
                        <HistoricalChart data={historicalData} metrics={chartMetrics.particle_counts} metricDetails={METRIC_DETAILS} title="Particulate Matter (Count)" aggregation={aggregation} timezone={timezone} />
                    </>
                 )}
            </div>
        </div>
    );
};

export default DeviceDetail;
