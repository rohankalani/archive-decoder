import React, { useState, useEffect, useMemo } from 'react';
import { getDevices, getZones } from '../services/apiService';
import { useRealtimeData } from '../contexts/RealtimeDataContext';
import { DeviceWithData, RealtimeData, Zone, ZoneWithData } from '../types';
import { Loader2, CheckCircle, XCircle, Info, Gem } from 'lucide-react';

const ESTIDAMA_THRESHOLDS = {
    pm25: { max: 15, name: 'Particulate Matter (PM2.5)', unit: 'µg/m³' },
    pm10: { max: 50, name: 'Particulate Matter (PM10)', unit: 'µg/m³' },
    co2: { max: 750, name: 'Carbon Dioxide', unit: 'ppm' },
    voc: { max: 250, name: 'Total VOCs', unit: 'µg/m³' },
    temp: { min: 22.0, max: 25.0, name: 'Temperature', unit: '°C' },
    humidity: { min: 30, max: 60, name: 'Humidity', unit: '%' }
};

type MetricKey = keyof typeof ESTIDAMA_THRESHOLDS;

const aggregateWorstCase = (devices: DeviceWithData[]): RealtimeData | null => {
    const onlineDevices = devices.filter(d => d.status === 'online' && d.latest_data);
    if (onlineDevices.length === 0) return null;

    const aggregated: Partial<RealtimeData> = {
        timestamp: onlineDevices.reduce((latest, d) => (d.latest_data!.timestamp > latest ? d.latest_data!.timestamp : latest), ''),
        deviceId: 'zone-aggregated'
    };

    (Object.keys(ESTIDAMA_THRESHOLDS) as MetricKey[]).forEach(key => {
        const metricInfo = ESTIDAMA_THRESHOLDS[key];
        const values = onlineDevices.map(d => d.latest_data?.[key as keyof RealtimeData]).filter((v): v is number => v != null);

        if (values.length > 0) {
            if ('min' in metricInfo) {
                const mid = (metricInfo.min + metricInfo.max) / 2;
                (aggregated as any)[key] = values.reduce((worst, current) => Math.abs(current - mid) > Math.abs(worst - mid) ? current : worst);
            } else {
                (aggregated as any)[key] = Math.max(...values);
            }
        }
    });

    return aggregated as RealtimeData;
}

const MetricStatus: React.FC<{ metricKey: MetricKey; value: number | undefined }> = ({ metricKey, value }) => {
    const metricInfo = ESTIDAMA_THRESHOLDS[metricKey];
    let isCompliant: boolean | null = null;

    if (value !== undefined) {
        if ('min' in metricInfo) {
            isCompliant = value >= metricInfo.min && value <= metricInfo.max;
        } else {
            isCompliant = value <= metricInfo.max;
        }
    }

    const valueDisplay = value !== undefined ? value.toFixed(1) : '--';
    const complianceIcon = isCompliant === null ? <Info className="w-4 h-4 text-slate-500" />
                         : isCompliant ? <CheckCircle className="w-4 h-4 text-green-400" />
                         : <XCircle className="w-4 h-4 text-red-400" />;

    return (
        <div className="flex justify-between items-center bg-tertiary p-3 rounded-md">
            <div className="flex items-center gap-2">
                {complianceIcon}
                <span className="text-sm text-slate-300">{metricInfo.name}</span>
            </div>
            <span className="text-sm font-bold text-white">{valueDisplay} <span className="text-slate-400">{metricInfo.unit}</span></span>
        </div>
    );
};

const ComplianceCard: React.FC<{ zone: ZoneWithData }> = ({ zone }) => {
    const data = zone.aggregated_data;
    const complianceResults = Object.keys(ESTIDAMA_THRESHOLDS).map(key => {
        const metricKey = key as MetricKey;
        const metricInfo = ESTIDAMA_THRESHOLDS[metricKey];
        const value = data?.[metricKey as keyof RealtimeData] as number | undefined;
        if (value === undefined) return null;
        if ('min' in metricInfo) {
            return value >= metricInfo.min && value <= metricInfo.max;
        }
        return value <= metricInfo.max;
    });

    const validResults = complianceResults.filter(r => r !== null);
    const isOverallCompliant = validResults.length > 0 && validResults.every(r => r === true);
    
    let statusText: string;
    let statusColor: string;

    switch (zone.status) {
        case 'offline':
            statusText = 'Offline';
            statusColor = 'border-slate-600';
            break;
        case 'mixed':
            statusText = 'Partially Online';
            statusColor = 'border-yellow-500';
            break;
        default:
            statusText = isOverallCompliant ? '1 Pearl Compliant' : 'Action Required';
            statusColor = isOverallCompliant ? 'border-green-500' : 'border-red-500';
            break;
    }

    return (
        <div className={`bg-secondary p-6 rounded-lg shadow-lg border-l-4 ${statusColor}`}>
            <div className="flex justify-between items-start mb-4">
                <div>
                    <h3 className="text-xl font-bold text-white">{zone.name}</h3>
                    <p className="text-sm text-slate-400">{zone.devices.length} sensor(s) in zone</p>
                </div>
                <div className={`px-3 py-1 text-sm font-semibold rounded-full ${
                    zone.status === 'offline' ? 'bg-slate-600 text-slate-300' :
                    zone.status === 'mixed' ? 'bg-yellow-500/10 text-yellow-400' :
                    isOverallCompliant ? 'bg-green-500/10 text-green-400' :
                    'bg-red-500/10 text-red-400'
                }`}>
                    {statusText}
                </div>
            </div>
            <div className="space-y-2">
                {Object.keys(ESTIDAMA_THRESHOLDS).map(key => (
                    <MetricStatus
                        key={key}
                        metricKey={key as MetricKey}
                        value={data?.[key as keyof RealtimeData] as number | undefined}
                    />
                ))}
            </div>
        </div>
    );
};

const EstidamaReport: React.FC = () => {
    const [allDevices, setAllDevices] = useState<DeviceWithData[]>([]);
    const [zones, setZones] = useState<Zone[]>([]);
    const [loading, setLoading] = useState(true);
    const { realtimeData } = useRealtimeData();

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const [fetchedDevices, fetchedZones] = await Promise.all([getDevices(), getZones()]);
                setAllDevices(fetchedDevices);
                setZones(fetchedZones);
            } catch (e) {
                console.error("Failed to fetch data", e);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    const zonesWithData = useMemo<ZoneWithData[]>(() => {
        const deviceMap = new Map(allDevices.map(d => [d.id, d]));
        return zones.map(zone => {
            const devicesInZone = zone.deviceIds
                .map(id => deviceMap.get(id))
                .filter((d): d is DeviceWithData => !!d)
                .map(d => ({
                    ...d,
                    latest_data: realtimeData[d.id] || d.latest_data,
                    status: realtimeData[d.id] ? 'online' : 'offline'
                }));

            const onlineCount = devicesInZone.filter(d => d.status === 'online').length;
            let status: ZoneWithData['status'] = 'offline';
            if (onlineCount === devicesInZone.length) status = 'online';
            else if (onlineCount > 0) status = 'mixed';

            return {
                ...zone,
                devices: devicesInZone,
                aggregated_data: aggregateWorstCase(devicesInZone),
                status
            };
        });
    }, [zones, allDevices, realtimeData]);
    
    if (loading) {
        return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>;
    }

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-4">
                <Gem className="w-10 h-10 text-teal-400" />
                <div>
                    <h1 className="text-3xl font-bold text-white">Abu Dhabi Estidama Pearl Report</h1>
                    <p className="text-slate-400 mt-1">Live monitoring for Estidama Pearl Rating System compliance (1 Pearl minimum).</p>
                </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {zonesWithData.map(zone => (
                    <ComplianceCard key={zone.id} zone={zone} />
                ))}
            </div>
        </div>
    );
};

export default EstidamaReport;