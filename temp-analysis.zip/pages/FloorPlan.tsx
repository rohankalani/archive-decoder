import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { DeviceWithData, DevicePosition, DeviceType } from '../types';
import { getDevices, updateDevice } from '../services/apiService';
import { useRealtimeData } from '../contexts/RealtimeDataContext';
import { Loader2, Edit2, Check, X, Thermometer, Wind, Cloud, Upload, Trash2 } from 'lucide-react';
import DevicePopover from '../components/DevicePopover';
import { useSettings } from '../contexts/SettingsContext';
import useLocalStorage from '../hooks/useLocalStorage';
import { useAuth } from '../contexts/AuthContext';

const OFFLINE_THRESHOLD = 30 * 1000; // 30 seconds

const deviceTypeConfig: Record<DeviceType, { name: string; icon: React.ReactNode }> = {
    'standard': { name: 'Sensors', icon: <Thermometer size={16} /> },
    'air-purifier': { name: 'Purifiers', icon: <Wind size={16} /> },
    'vape-smoke': { name: 'Vape Detectors', icon: <Cloud size={16} /> },
};

const DEFAULT_FLOOR_PLAN_URL = 'https://storage.googleapis.com/maker-cloud-assets/rosaiq-assets/floorplan-dark-bg.png';

const FloorPlan: React.FC = () => {
    const [allDevices, setAllDevices] = useState<DeviceWithData[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const { realtimeData } = useRealtimeData();
    const { calculateOverallAqi } = useSettings();
    const { role } = useAuth();
    
    const [activeDevice, setActiveDevice] = useState<DeviceWithData | null>(null);
    const [popoverPosition, setPopoverPosition] = useState({ top: 0, left: 0 });
    const [locationFilters, setLocationFilters] = useState({ site: 'all', building: 'all', block: 'all', floor: 'all' });
    const [typeFilters, setTypeFilters] = useState<Record<DeviceType, boolean>>({
        'standard': true,
        'air-purifier': true,
        'vape-smoke': true,
    });

    const [isEditing, setIsEditing] = useState(false);
    const [devicePositions, setDevicePositions] = useLocalStorage<Record<string, DevicePosition>>('device-positions', {});
    const [tempPositions, setTempPositions] = useState<Record<string, DevicePosition>>({});
    const [floorPlanImage, setFloorPlanImage] = useLocalStorage<string | null>('floorplan-image', DEFAULT_FLOOR_PLAN_URL);
    
    const draggedDeviceRef = useRef<{ id: string; offsetX: number; offsetY: number } | null>(null);
    const floorPlanRef = useRef<HTMLDivElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const fetchData = useCallback(async () => {
        try {
            setLoading(true);
            const fetchedDevices = await getDevices();
            setAllDevices(fetchedDevices);
        } catch (err) {
            setError('Failed to fetch devices.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    useEffect(() => {
        if (allDevices.length > 0) {
            setDevicePositions(prevPositions => {
                const newPositions = { ...prevPositions };
                let updated = false;
                allDevices.forEach((d, i) => {
                    if (!newPositions[d.id]) {
                        newPositions[d.id] = { x: 10 + (i * 5 % 80), y: 20 + (i * 15 % 60) };
                        updated = true;
                    }
                });
                return updated ? newPositions : prevPositions;
            });
        }
    }, [allDevices, setDevicePositions]);

    const devicesWithLiveData = useMemo(() => {
        const now = Date.now();
        return allDevices.map(d => {
            const latest_data = realtimeData[d.id] || d.latest_data;
            const lastUpdate = latest_data ? new Date(latest_data.timestamp).getTime() : 0;
            const status: 'online' | 'offline' = (now - lastUpdate) < OFFLINE_THRESHOLD ? 'online' : 'offline';
            return { ...d, latest_data, status };
        });
    }, [allDevices, realtimeData]);

    const filterOptions = useMemo(() => {
        const locations = allDevices.map(d => d.location);
        const sites = [...new Set(locations.map(l => l.site))].sort();
        const buildings = [...new Set(locations.filter(l => locationFilters.site === 'all' || l.site === locationFilters.site).map(l => l.building))].sort();
        const blocks = [...new Set(locations.filter(l => (locationFilters.site === 'all' || l.site === locationFilters.site) && (locationFilters.building === 'all' || l.building === locationFilters.building)).map(l => l.block))].sort();
        const floors = [...new Set(locations.filter(l => (locationFilters.site === 'all' || l.site === locationFilters.site) && (locationFilters.building === 'all' || l.building === locationFilters.building) && (locationFilters.block === 'all' || l.block === locationFilters.block)).map(l => l.floor))].sort();
        return { sites, buildings, blocks, floors };
    }, [allDevices, locationFilters.site, locationFilters.building, locationFilters.block]);

    const handleLocationFilterChange = (filterName: 'site' | 'building' | 'block' | 'floor', value: string) => {
        setLocationFilters(prev => {
            const newFilters = { ...prev, [filterName]: value };
            if (filterName === 'site') { newFilters.building = 'all'; newFilters.block = 'all'; newFilters.floor = 'all'; }
            if (filterName === 'building') { newFilters.block = 'all'; newFilters.floor = 'all'; }
            if (filterName === 'block') { newFilters.floor = 'all'; }
            return newFilters;
        });
    };
    
    const filteredDevices = useMemo(() => {
        return devicesWithLiveData.filter(d =>
            (locationFilters.site === 'all' || d.location.site === locationFilters.site) &&
            (locationFilters.building === 'all' || d.location.building === locationFilters.building) &&
            (locationFilters.block === 'all' || d.location.block === locationFilters.block) &&
            (locationFilters.floor === 'all' || d.location.floor === locationFilters.floor) &&
            (typeFilters[d.type])
        );
    }, [devicesWithLiveData, locationFilters, typeFilters]);

    const handleDeviceClick = (device: DeviceWithData, event: React.MouseEvent<HTMLButtonElement>) => {
        if (isEditing) return;
        const rect = event.currentTarget.getBoundingClientRect();
        const popoverTop = rect.bottom + window.scrollY;
        const popoverLeft = rect.left + window.scrollX + rect.width / 2;
        setActiveDevice(device);
        setPopoverPosition({ top: popoverTop, left: popoverLeft });
    };

    const handleClosePopover = () => setActiveDevice(null);
    const handleUpdateDeviceName = async (deviceId: string, newName: string) => {
        const device = allDevices.find(d => d.id === deviceId);
        if (!device) return;
        await updateDevice(deviceId, newName, device.location_id);
        fetchData();
    };
    
    const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file && file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = (e) => {
                setFloorPlanImage(e.target?.result as string);
            };
            reader.readAsDataURL(file);
        }
    };
    
    const handleUploadClick = () => fileInputRef.current?.click();
    const handleRemoveImage = () => setFloorPlanImage(DEFAULT_FLOOR_PLAN_URL);


    const handleMouseDown = (e: React.MouseEvent, deviceId: string) => {
        if (!isEditing || !floorPlanRef.current) return;
        const target = e.currentTarget;
        const rect = target.getBoundingClientRect();
        draggedDeviceRef.current = { id: deviceId, offsetX: e.clientX - rect.left, offsetY: e.clientY - rect.top };
        e.preventDefault();
    };
    
    const handleMouseMove = (e: React.MouseEvent) => {
        if (!draggedDeviceRef.current || !floorPlanRef.current) return;
        const { id, offsetX, offsetY } = draggedDeviceRef.current;
        const containerRect = floorPlanRef.current.getBoundingClientRect();
        const x = e.clientX - containerRect.left - offsetX;
        const y = e.clientY - containerRect.top - offsetY;
        const newXPercent = Math.max(0, Math.min(100, (x / containerRect.width) * 100));
        const newYPercent = Math.max(0, Math.min(100, (y / containerRect.height) * 100));
        setTempPositions(prev => ({ ...prev, [id]: { x: newXPercent, y: newYPercent } }));
    };

    const handleMouseUp = () => { draggedDeviceRef.current = null; };
    const handleToggleEditMode = () => {
        if (isEditing) {
            setTempPositions({});
            setIsEditing(false);
        } else {
            setTempPositions(devicePositions);
            setIsEditing(true);
        }
    };
    const handleSaveChanges = () => {
        setDevicePositions(tempPositions);
        setIsEditing(false);
    };

    const renderFilterDropdown = (label: string, name: 'site' | 'building' | 'block' | 'floor', options: string[]) => (
        <select value={locationFilters[name]} onChange={(e) => handleLocationFilterChange(name, e.target.value)} className="bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white text-sm focus:ring-2 focus:ring-accent-dark focus:outline-none">
            <option value="all">All {label}s</option>
            {options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
        </select>
    );
    
    const renderDeviceIcon = (device: DeviceWithData) => {
        const isOnline = device.status === 'online';
        if (device.type === 'standard') {
            const { aqi, quality } = calculateOverallAqi(device.latest_data);
            const dotColor = isOnline ? quality.color : '#64748b';
            return (
                 <div className="relative w-8 h-8">
                    <div className="absolute inset-0 rounded-full flex items-center justify-center ring-4" style={{ backgroundColor: dotColor, borderColor: `${dotColor}40` }}>
                        <span className="text-sm font-bold text-black mix-blend-luminosity">{isOnline ? aqi : '-'}</span>
                    </div>
                    {isOnline && <div className="absolute inset-0 rounded-full animate-pulse-glow" style={{ borderColor: dotColor, borderWidth: '2px' }} />}
                </div>
            )
        }
        if (device.type === 'air-purifier') {
            const fanSpeed = device.latest_data?.fan_speed ?? 0;
            const isRunning = isOnline && fanSpeed > 0;
            return (
                <div className="relative w-8 h-8 flex items-center justify-center">
                    {isRunning && <div className="absolute inset-0 rounded-full bg-cyan-400 opacity-75 animate-ping" style={{ animationDuration: `${3 - (fanSpeed/100)*2}s`}}></div>}
                    <div className={`relative w-7 h-7 rounded-full flex items-center justify-center ring-4 ${isRunning ? 'bg-cyan-400 ring-cyan-400/30' : 'bg-slate-500 ring-slate-500/30'}`}>
                        <Wind size={16} className="text-white"/>
                    </div>
                </div>
            )
        }
        if (device.type === 'vape-smoke') {
            const isAlert = device.latest_data?.smoke_vape_detected === 1 || device.latest_data?.voc as number > 450;
            const isAlerting = isOnline && isAlert;
             return (
                <div className="relative w-8 h-8 flex items-center justify-center">
                    {isAlerting && <div className="absolute inset-0 rounded-full bg-red-500 opacity-75 animate-ping"></div>}
                    <div className={`relative w-7 h-7 rounded-full flex items-center justify-center ring-4 ${isAlerting ? 'bg-red-500 ring-red-500/30' : isOnline ? 'bg-green-500 ring-green-500/30' : 'bg-slate-500 ring-slate-500/30'}`}>
                        <Cloud size={16} className="text-white"/>
                    </div>
                </div>
            )
        }
        return null;
    }


    if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>;
    if (error) return <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error}</div>;

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                <h1 className="text-3xl font-bold text-white">Interactive Floor Plan</h1>
                {role === 'admin' && (
                    <div className="flex items-center gap-4">
                        <input type="file" ref={fileInputRef} onChange={handleImageUpload} accept="image/*" className="hidden" />
                        {isEditing ? (
                            <>
                                <button onClick={handleSaveChanges} className="flex items-center gap-2 px-4 py-2 text-sm rounded-md text-white bg-green-600 hover:bg-green-500"><Check size={18}/>Save Layout</button>
                                <button onClick={handleToggleEditMode} className="flex items-center gap-2 px-4 py-2 text-sm rounded-md text-white bg-slate-600 hover:bg-slate-500"><X size={18}/>Cancel</button>
                            </>
                        ) : (
                             <div className="flex items-center gap-2">
                                <button onClick={handleUploadClick} className="flex items-center gap-2 px-4 py-2 text-sm rounded-md text-white bg-slate-600 hover:bg-slate-500"><Upload size={16}/>Upload Plan</button>
                                {floorPlanImage !== DEFAULT_FLOOR_PLAN_URL && <button onClick={handleRemoveImage} className="flex items-center gap-2 px-4 py-2 text-sm rounded-md text-white bg-slate-600 hover:bg-slate-500"><Trash2 size={16}/>Remove Plan</button>}
                                <button onClick={handleToggleEditMode} className="flex items-center gap-2 px-4 py-2 text-sm rounded-md text-white bg-accent hover:bg-accent-dark"><Edit2 size={16}/>Edit Layout</button>
                             </div>
                        )}
                    </div>
                )}
            </div>
            <div className="bg-secondary p-2 rounded-lg flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2 flex-wrap">
                    {renderFilterDropdown('Site', 'site', filterOptions.sites)}
                    {renderFilterDropdown('Building', 'building', filterOptions.buildings)}
                    {renderFilterDropdown('Block', 'block', filterOptions.blocks)}
                    {renderFilterDropdown('Floor', 'floor', filterOptions.floors)}
                </div>
                <div className="flex items-center gap-2 p-1 bg-tertiary rounded-full">
                    {(Object.keys(deviceTypeConfig) as DeviceType[]).map(type => (
                        <button key={type} onClick={() => setTypeFilters(f => ({ ...f, [type]: !f[type] }))}
                            className={`flex items-center gap-2 px-3 py-1 text-sm font-semibold rounded-full transition-colors ${typeFilters[type] ? 'bg-accent text-white' : 'hover:bg-slate-600'}`}>
                            {deviceTypeConfig[type].icon}
                            {deviceTypeConfig[type].name}
                        </button>
                    ))}
                </div>
            </div>

            <div 
                className={`relative bg-cover bg-center rounded-lg aspect-[16/9] w-full max-w-7xl mx-auto overflow-hidden ${isEditing ? 'cursor-move border-2 border-dashed border-accent' : ''}`} 
                style={{ backgroundImage: `url(${floorPlanImage || DEFAULT_FLOOR_PLAN_URL})` }}
                onClick={handleClosePopover} 
                ref={floorPlanRef} 
                onMouseMove={handleMouseMove} 
                onMouseUp={handleMouseUp} 
                onMouseLeave={handleMouseUp}
            >
                <div className="absolute inset-0 bg-black/20"></div>
                {filteredDevices.map(device => {
                    const position = isEditing ? tempPositions[device.id] : devicePositions[device.id];
                    if (!position) return null;

                    return (
                        <button 
                            key={device.id} 
                            className={`absolute transform -translate-x-1/2 -translate-y-1/2 transition-transform z-10 ${!isEditing ? 'hover:scale-125' : 'cursor-grab'}`}
                            style={{ top: `${position.y}%`, left: `${position.x}%` }}
                            onClick={(e) => { e.stopPropagation(); handleDeviceClick(device, e); }}
                            onMouseDown={(e) => handleMouseDown(e, device.id)} 
                            title={device.name}
                        >
                            {renderDeviceIcon(device)}
                        </button>
                    );
                })}
            </div>
            {activeDevice && !isEditing && (
                <DevicePopover device={activeDevice} onClose={handleClosePopover} position={popoverPosition} onUpdateName={handleUpdateDeviceName} />
            )}
        </div>
    );
};

export default FloorPlan;