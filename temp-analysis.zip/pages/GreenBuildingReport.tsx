import React, { useState, useEffect, useMemo } from 'react';
import { getDevices, getZones } from '../services/apiService';
import { useRealtimeData } from '../contexts/RealtimeDataContext';
import { DeviceWithData, RealtimeData, Zone, ZoneWithData } from '../types';
import { Loader2, CheckCircle, XCircle, Info } from 'lucide-react';

// Define the thresholds from the Green Building regulations
const COMPLIANCE_THRESHOLDS = {
    co2: { max: 800, name: 'Carbon Dioxide', unit: 'ppm' },
    voc: { max: 300, name: 'Total VOCs', unit: 'µg/m³' },
    hcho: { max: 80, name: 'Formaldehyde', unit: 'ppb' },
    pm10: { max: 150, name: 'Particulates (PM10)', unit: 'µg/m³' },
    temp: { min: 22.5, max: 25.5, name: 'Temperature', unit: '°C' },
    humidity: { min: 30, max: 60, name: 'Humidity', unit: '%' }
};

type MetricKey = keyof typeof COMPLIANCE_THRESHOLDS;

const aggregateWorstCase = (devices: DeviceWithData[]): RealtimeData | null => {
    const onlineDevices = devices.filter(d => d.status === 'online' && d.latest_data);
    if (onlineDevices.length === 0) return null;

    const aggregated: Partial<RealtimeData> = {};
    
    // Find the latest timestamp
    aggregated.timestamp = onlineDevices.reduce((latest, d) => 
        (d.latest_data!.timestamp > latest ? d.latest_data!.timestamp : latest), '');

    // Aggregate metrics based on worst-case
    (Object.keys(COMPLIANCE_THRESHOLDS) as MetricKey[]).forEach(key => {
        const metricInfo = COMPLIANCE_THRESHOLDS[key];
        const values = onlineDevices.map(d => d.latest_data?.[key as keyof RealtimeData]).filter((v): v is number => v != null);

        if (values.length > 0) {
            if ('min' in metricInfo) { // For temp/humidity, find the value furthest from the ideal range center
                const mid = (metricInfo.min + metricInfo.max) / 2;
                // FIX: Type 'number' is not assignable to type 'never'. Using a type assertion to allow dynamic property assignment.
                (aggregated as any)[key] = values.reduce((worst, current) => Math.abs(current - mid) > Math.abs(worst - mid) ? current : worst);
            } else { // For pollutants, find the max value
                // FIX: Type 'number' is not assignable to type 'never'. Using a type assertion to allow dynamic property assignment.
                (aggregated as any)[key] = Math.max(...values);
            }
        }
    });

    // Add a placeholder deviceId as it's required by the RealtimeData type
    aggregated.deviceId = 'zone-aggregated';

    return aggregated as RealtimeData;
}


// Component for a single metric's status
const MetricStatus: React.FC<{ metricKey: MetricKey; value: number | undefined }> = ({ metricKey, value }) => {
    const metricInfo = COMPLIANCE_THRESHOLDS[metricKey];
    let isCompliant: boolean | null = null;

    if (value !== undefined) {
        if ('min' in metricInfo) {
            isCompliant = value >= metricInfo.min && value <= metricInfo.max;
        } else {
            isCompliant = value <= metricInfo.max;
        }
    }

    const valueDisplay = value !== undefined ? value.toFixed(1) : '--';
    const complianceIcon = isCompliant === null ? <Info className="w-4 h-4 text-slate-500" />
                         : isCompliant ? <CheckCircle className="w-4 h-4 text-green-400" />
                         : <XCircle className="w-4 h-4 text-red-400" />;

    return (
        <div className="flex justify-between items-center bg-tertiary p-3 rounded-md">
            <div className="flex items-center gap-2">
                {complianceIcon}
                <span className="text-sm text-slate-300">{metricInfo.name}</span>
            </div>
            <span className="text-sm font-bold text-white">{valueDisplay} <span className="text-slate-400">{metricInfo.unit}</span></span>
        </div>
    );
};

// Component for a single location's compliance card
const ComplianceCard: React.FC<{ zone: ZoneWithData }> = ({ zone }) => {
    const data = zone.aggregated_data;

    const complianceResults = Object.keys(COMPLIANCE_THRESHOLDS).map(key => {
        const metricKey = key as MetricKey;
        const metricInfo = COMPLIANCE_THRESHOLDS[metricKey];
        const value = data?.[metricKey as keyof RealtimeData] as number | undefined;

        if (value === undefined) return null; // Not enough data to judge

        if ('min' in metricInfo) {
            return value >= metricInfo.min && value <= metricInfo.max;
        }
        return value <= metricInfo.max;
    });

    const validResults = complianceResults.filter(r => r !== null);
    const isOverallCompliant = validResults.length > 0 && validResults.every(r => r === true);
    
    let statusText: string;
    let statusColor: string;

    switch (zone.status) {
        case 'offline':
            statusText = 'Offline';
            statusColor = 'border-slate-600';
            break;
        case 'mixed':
            statusText = 'Partially Online';
            statusColor = 'border-yellow-500';
            break;
        default: // online
            statusText = isOverallCompliant ? 'Compliant' : 'Action Required';
            statusColor = isOverallCompliant ? 'border-green-500' : 'border-red-500';
            break;
    }

    return (
        <div className={`bg-secondary p-6 rounded-lg shadow-lg border-l-4 ${statusColor}`}>
            <div className="flex justify-between items-start mb-4">
                <div>
                    <h3 className="text-xl font-bold text-white">{zone.name}</h3>
                    <p className="text-sm text-slate-400">{zone.devices.length} sensor(s)</p>
                </div>
                <div className={`px-3 py-1 text-sm font-semibold rounded-full ${
                    zone.status === 'offline' ? 'bg-slate-600 text-slate-300' :
                    zone.status === 'mixed' ? 'bg-yellow-500/10 text-yellow-400' :
                    isOverallCompliant ? 'bg-green-500/10 text-green-400' :
                    'bg-red-500/10 text-red-400'
                }`}>
                    {statusText}
                </div>
            </div>
            <div className="space-y-2">
                {Object.keys(COMPLIANCE_THRESHOLDS).map(key => (
                    <MetricStatus
                        key={key}
                        metricKey={key as MetricKey}
                        value={data?.[key as keyof RealtimeData] as number | undefined}
                    />
                ))}
            </div>
        </div>
    );
};


// Main Component
const GreenBuildingReport: React.FC = () => {
    const [allDevices, setAllDevices] = useState<DeviceWithData[]>([]);
    const [zones, setZones] = useState<Zone[]>([]);
    const [loading, setLoading] = useState(true);
    const { realtimeData } = useRealtimeData();

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const [fetchedDevices, fetchedZones] = await Promise.all([getDevices(), getZones()]);
                setAllDevices(fetchedDevices);
                setZones(fetchedZones);
            } catch (e) {
                console.error("Failed to fetch data", e);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    const zonesWithData = useMemo<ZoneWithData[]>(() => {
        const deviceMap = new Map(allDevices.map(d => [d.id, d]));
        
        return zones.map(zone => {
            const devicesInZone = zone.deviceIds
                .map(id => deviceMap.get(id))
                .filter((d): d is DeviceWithData => !!d)
                .map(d => ({
                    ...d,
                    latest_data: realtimeData[d.id] || d.latest_data,
                    status: realtimeData[d.id] ? 'online' : 'offline'
                }));

            const onlineCount = devicesInZone.filter(d => d.status === 'online').length;
            let status: ZoneWithData['status'] = 'offline';
            if (onlineCount === devicesInZone.length) {
                status = 'online';
            } else if (onlineCount > 0) {
                status = 'mixed';
            }

            return {
                ...zone,
                devices: devicesInZone,
                aggregated_data: aggregateWorstCase(devicesInZone),
                status
            };
        });
    }, [zones, allDevices, realtimeData]);

    const complianceSummary = useMemo(() => {
        const onlineZones = zonesWithData.filter(z => z.status !== 'offline');
        if (onlineZones.length === 0) {
            return { compliantCount: 0, totalCount: 0, complianceRate: 0 };
        }
        
        const compliantCount = onlineZones.reduce((acc, zone) => {
            const data = zone.aggregated_data;
            if (!data) return acc;

            const isCompliant = Object.keys(COMPLIANCE_THRESHOLDS).every(key => {
                const metricKey = key as MetricKey;
                const metricInfo = COMPLIANCE_THRESHOLDS[metricKey];
                const value = data[metricKey as keyof RealtimeData] as number | undefined;

                if (value === undefined) return true; // Ignore if no data for metric
                if ('min' in metricInfo) {
                    return value >= metricInfo.min && value <= metricInfo.max;
                }
                return value <= metricInfo.max;
            });

            return acc + (isCompliant ? 1 : 0);
        }, 0);
        
        return {
            compliantCount,
            totalCount: onlineZones.length,
            complianceRate: (compliantCount / onlineZones.length) * 100
        };
    }, [zonesWithData]);


    if (loading) {
        return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>;
    }

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold text-white">Dubai Green Building</h1>
                <p className="text-slate-400 mt-1">Monitoring indoor environmental quality against Dubai Green Building regulations.</p>
            </div>
            
            <div className="bg-secondary p-6 rounded-lg shadow-lg">
                <h2 className="text-2xl font-bold text-white mb-4">Compliance Overview</h2>
                <div className="flex flex-col md:flex-row items-center gap-8">
                    <div className="relative w-36 h-36 flex-shrink-0">
                        <svg className="w-full h-full" viewBox="0 0 36 36">
                            <path
                                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                                fill="none"
                                stroke="#334155"
                                strokeWidth="3"
                            />
                            <path
                                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                                fill="none"
                                stroke={complianceSummary.complianceRate > 0 ? "#4ade80" : "#334155"}
                                strokeWidth="3"
                                strokeDasharray={`${complianceSummary.complianceRate}, 100`}
                            />
                        </svg>
                        <div className="absolute inset-0 flex flex-col items-center justify-center">
                            <span className="text-4xl font-bold text-white">{complianceSummary.complianceRate.toFixed(0)}%</span>
                            <span className="text-sm text-slate-400">Compliant</span>
                        </div>
                    </div>
                    <div className="text-lg text-center md:text-left">
                        <p className="text-white"><strong className="text-green-400">{complianceSummary.compliantCount}</strong> of <strong className="text-cyan-400">{complianceSummary.totalCount}</strong> active zones are fully compliant.</p>
                        <p className="text-sm text-slate-400 mt-2">Based on aggregated live data from online sensors within each zone.</p>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {zonesWithData.map(zone => (
                    <ComplianceCard key={zone.id} zone={zone} />
                ))}
            </div>
        </div>
    );
};

export default GreenBuildingReport;