import React, { useState, useEffect, useMemo } from 'react';
// FIX: Corrected import path for apiService.
import { getLocations, getLeedReportData } from '../services/apiService';
// FIX: Corrected import path for types.
import { Location, LeedReportData, LeedDateRange, LeedMetric } from '../types';
import { Loader2, CheckCircle, XCircle, Printer } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { format } from 'date-fns';

const METRIC_NAMES: Record<LeedMetric, string> = {
    pm25: 'PM2.5',
    co2: 'Carbon Dioxide (CO₂)',
    voc: 'Total VOCs',
    hcho: 'Formaldehyde (HCHO)'
};

const MetricComplianceCard: React.FC<{ metric: LeedMetric; data: LeedReportData['metrics'][LeedMetric] }> = ({ metric, data }) => {
    const peakColor = data.isCompliant ? 'text-white' : 'text-red-400 font-bold';
    
    return (
        <div className="bg-slate-850/50 p-6 rounded-lg print:p-4 print:border print:border-slate-300">
            <div className="flex justify-between items-start mb-4">
                <div>
                    <h3 className="text-xl font-bold text-white">{METRIC_NAMES[metric]}</h3>
                    <p className="text-sm text-slate-400">Threshold: &lt; {data.threshold} {data.unit}</p>
                </div>
                {data.isCompliant ? (
                     <div className="flex items-center gap-2 px-3 py-1 bg-green-500/10 text-green-400 rounded-full text-sm font-semibold">
                        <CheckCircle className="w-4 h-4" /> Compliant
                    </div>
                ) : (
                    <div className="flex items-center gap-2 px-3 py-1 bg-red-500/10 text-red-400 rounded-full text-sm font-semibold">
                        <XCircle className="w-4 h-4" /> Non-Compliant
                    </div>
                )}
            </div>
            
            <div className="h-40 mb-4 print:h-32">
                 <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={data.trend} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#475569" strokeOpacity={0.5} />
                        <XAxis 
                            dataKey="timestamp" 
                            tickFormatter={(ts) => format(new Date(ts), 'MMM d, HH:mm')}
                            stroke="#94a3b8"
                            tick={{ fontSize: 10 }}
                            dy={5}
                        />
                        <YAxis stroke="#94a3b8" tick={{ fontSize: 10 }} />
                        <Tooltip
                            contentStyle={{ backgroundColor: '#162030', border: '1px solid #334155' }}
                            labelStyle={{ color: '#cbd5e1' }}
                            formatter={(value: number) => [`${value.toFixed(2)} ${data.unit}`, METRIC_NAMES[metric]]}
                        />
                        <ReferenceLine y={data.threshold} label={{ value: `LEED Limit`, fill: '#f87171', fontSize: 12, position: 'insideTopLeft' }} stroke="#f87171" strokeDasharray="3 3" strokeWidth={2} />
                        <Line type="monotone" dataKey="value" stroke="#38bdf8" strokeWidth={2} dot={false} activeDot={{ r: 5 }} />
                    </LineChart>
                </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-2 gap-4 text-center">
                <div className="bg-slate-950/50 p-3 rounded-md">
                    <p className="text-sm text-slate-400">Peak Value</p>
                    <p className={`text-2xl font-semibold ${peakColor}`}>{data.peak.toFixed(2)} <span className="text-sm font-normal text-slate-400">{data.unit}</span></p>
                </div>
                 <div className="bg-slate-950/50 p-3 rounded-md">
                    <p className="text-sm text-slate-400">Average</p>
                    <p className="text-2xl font-semibold text-white">{data.average.toFixed(2)} <span className="text-sm font-normal text-slate-400">{data.unit}</span></p>
                </div>
            </div>
        </div>
    );
}

const LeedReport: React.FC = () => {
    const [locations, setLocations] = useState<Location[]>([]);
    const [reportData, setReportData] = useState<LeedReportData | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const [selectedBuilding, setSelectedBuilding] = useState<string>('');
    const [selectedFloor, setSelectedFloor] = useState<string>('');
    const [dateRange, setDateRange] = useState<LeedDateRange>('7d');

    useEffect(() => {
        const fetchLocations = async () => {
            const locs = await getLocations();
            setLocations(locs);
            if (locs.length > 0) {
                const firstBuilding = locs[0].building;
                setSelectedBuilding(firstBuilding);
                const firstFloor = locs.find(l => l.building === firstBuilding)?.floor || '';
                setSelectedFloor(firstFloor);
            }
        };
        fetchLocations();
    }, []);

    const buildingOptions = useMemo(() => [...new Set(locations.map(l => l.building))], [locations]);
    const floorOptions = useMemo(() => [...new Set(locations.filter(l => l.building === selectedBuilding).map(l => l.floor))], [locations, selectedBuilding]);

    const handleGenerateReport = async () => {
        if (!selectedBuilding || !selectedFloor) return;
        setLoading(true);
        setError(null);
        setReportData(null);
        try {
            const data = await getLeedReportData(selectedBuilding, selectedFloor, dateRange);
            setReportData(data);
        } catch (err: any) {
            console.error(err);
            setError(err.message || 'Failed to generate LEED report.');
        } finally {
            setLoading(false);
        }
    };

    const handlePrint = () => {
        window.print();
    };

    return (
        <div className="space-y-6">
            <style>{`
                @media print {
                    body {
                        background-color: #ffffff !important;
                        color: #000000 !important;
                    }
                    .no-print, header {
                        display: none !important;
                    }
                    main {
                        padding: 0 !important;
                    }
                    .print-container {
                        box-shadow: none !important;
                        border: 1px solid #ccc;
                    }
                    .print-text-black {
                        color: #000000 !important;
                    }
                     .print-bg-white {
                        background-color: #ffffff !important;
                    }
                }
            `}</style>

            <div className="no-print">
                <h1 className="text-3xl font-bold text-white">Compliance Report</h1>
                <p className="text-slate-400 mt-1">Generate an IAQ Compliance Report based on LEED v4.1 standards.</p>
            </div>

            <div className="bg-secondary p-4 rounded-lg flex flex-col md:flex-row justify-between md:items-center gap-4 no-print">
                <div className="flex items-center gap-3 flex-wrap">
                    <div>
                        <label htmlFor="building-select" className="sr-only">Building</label>
                        <select id="building-select" value={selectedBuilding} onChange={e => setSelectedBuilding(e.target.value)} className="bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-accent-dark focus:outline-none">
                            {buildingOptions.map(b => <option key={b} value={b}>{b}</option>)}
                        </select>
                    </div>
                     <div>
                        <label htmlFor="floor-select" className="sr-only">Floor</label>
                        <select id="floor-select" value={selectedFloor} onChange={e => setSelectedFloor(e.target.value)} className="bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-accent-dark focus:outline-none">
                            {floorOptions.map(f => <option key={f} value={f}>{f}</option>)}
                        </select>
                    </div>
                     <div>
                        <label htmlFor="range-select" className="sr-only">Date Range</label>
                        <select id="range-select" value={dateRange} onChange={e => setDateRange(e.target.value as LeedDateRange)} className="bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-accent-dark focus:outline-none">
                            <option value="24h">Last 24 Hours</option>
                            <option value="7d">Last 7 Days</option>
                            <option value="30d">Last 30 Days</option>
                        </select>
                    </div>
                </div>
                 <button onClick={handleGenerateReport} disabled={loading} className="w-full md:w-auto px-6 py-2 rounded-md text-white bg-accent hover:bg-accent-dark transition-colors disabled:bg-slate-500 flex items-center justify-center gap-2">
                    {loading && <Loader2 className="w-4 h-4 animate-spin"/>}
                    Generate Report
                </button>
            </div>

            {loading && <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /> <span className="ml-3 text-lg">Analyzing Historical Data...</span></div>}
            {error && <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error}</div>}
            
            {reportData && (
                <div className="bg-secondary p-8 rounded-lg shadow-lg animate-fade-in-scale print-container print-bg-white">
                    <div className="flex justify-between items-start mb-6 pb-6 border-b border-slate-700 print:border-b-2 print:border-slate-300">
                        <div>
                            <h2 className="text-3xl font-bold text-white print-text-black">LEED IAQ Compliance Report</h2>
                            <p className="text-slate-300 print-text-black">{reportData.location.building} / {reportData.location.floor}</p>
                            <p className="text-sm text-slate-400 print-text-black">
                                Period: {format(new Date(reportData.period.from), 'd MMM yyyy')} - {format(new Date(reportData.period.to), 'd MMM yyyy')}
                            </p>
                        </div>
                        <div className="flex flex-col items-end gap-4">
                             {reportData.isOverallCompliant ? (
                                <div className="flex items-center gap-2 px-4 py-2 bg-green-500/10 text-green-400 rounded-md text-lg font-semibold">
                                    <CheckCircle className="w-6 h-6" /> Overall: Compliant
                                </div>
                            ) : (
                                <div className="flex items-center gap-2 px-4 py-2 bg-red-500/10 text-red-400 rounded-md text-lg font-semibold">
                                    <XCircle className="w-6 h-6" /> Overall: Non-Compliant
                                </div>
                            )}
                            <button onClick={handlePrint} className="flex items-center gap-2 px-4 py-2 text-sm rounded-md text-white bg-slate-600 hover:bg-slate-500 no-print">
                                <Printer className="w-4 h-4" /> Print Report
                            </button>
                        </div>
                    </div>
                    
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        {Object.entries(reportData.metrics).map(([key, value]) => (
                            <MetricComplianceCard key={key} metric={key as LeedMetric} data={value} />
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

export default LeedReport;