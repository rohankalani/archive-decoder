import React, { useState } from 'react';
import UserManagement from '../components/UserManagement';
import DeviceLocationManagement from '../components/DeviceLocationManagement';
import ManagePurifiers from '../components/ManagePurifiers';
import ManageVapeDevices from '../components/ManageVapeDevices';
import ZoneManagement from '../components/ZoneManagement';
import { Users, SlidersHorizontal, Wind, Cloud, Network, CheckCircle, XCircle, AlertTriangle, PowerOff, X, Loader2, Grid3X3 } from 'lucide-react';

// --- Types ---
type ConnectorStatus = 'Connected' | 'Error' | 'Disconnected';
interface Connector {
  protocol: string;
  description: string;
  status: ConnectorStatus;
  rate: string;
  lastSync: string;
}

// --- NEW COMPONENT: ConnectorConfigModal ---
const ConnectorConfigModal: React.FC<{
  connector: Connector | null;
  isOpen: boolean;
  onClose: () => void;
}> = ({ connector, isOpen, onClose }) => {
  const [isSaving, setIsSaving] = useState(false);

  if (!isOpen || !connector) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    // Simulate API call
    setTimeout(() => {
      setIsSaving(false);
      onClose();
    }, 1000);
  };

  const renderFields = () => {
    switch (connector.protocol) {
      case 'BACnet/IP':
        return (
          <>
            <div><label className="text-sm text-slate-300">IP Address</label><input type="text" defaultValue="192.168.1.100" className="w-full bg-tertiary mt-1 p-2 rounded border border-slate-600"/></div>
            <div><label className="text-sm text-slate-300">Port</label><input type="number" defaultValue="47808" className="w-full bg-tertiary mt-1 p-2 rounded border border-slate-600"/></div>
            <div><label className="text-sm text-slate-300">Device ID</label><input type="number" defaultValue="12345" className="w-full bg-tertiary mt-1 p-2 rounded border border-slate-600"/></div>
          </>
        );
      case 'Modbus TCP':
        return (
          <>
            <div><label className="text-sm text-slate-300">Host</label><input type="text" defaultValue="192.168.1.101" className="w-full bg-tertiary mt-1 p-2 rounded border border-slate-600"/></div>
            <div><label className="text-sm text-slate-300">Port</label><input type="number" defaultValue="502" className="w-full bg-tertiary mt-1 p-2 rounded border border-slate-600"/></div>
            <div><label className="text-sm text-slate-300">Slave ID</label><input type="number" defaultValue="1" className="w-full bg-tertiary mt-1 p-2 rounded border border-slate-600"/></div>
          </>
        );
      case 'OPC Unified Architecture':
        return (
          <>
            <div><label className="text-sm text-slate-300">Endpoint URL</label><input type="text" defaultValue="opc.tcp://192.168.1.102:4840" className="w-full bg-tertiary mt-1 p-2 rounded border border-slate-600"/></div>
            <div><label className="text-sm text-slate-300">Security Policy</label><select className="w-full bg-tertiary mt-1 p-2 rounded border border-slate-600"><option>None</option><option>Basic256Sha256</option></select></div>
          </>
        );
      case 'Generic REST API':
        return (
            <>
              <div><label className="text-sm text-slate-300">Base URL</label><input type="text" defaultValue="https://api.weather.com/v1/" className="w-full bg-tertiary mt-1 p-2 rounded border border-slate-600"/></div>
              <div><label className="text-sm text-slate-300">API Key</label><input type="password" defaultValue="•••••••••••••••" className="w-full bg-tertiary mt-1 p-2 rounded border border-slate-600"/></div>
              <div><label className="text-sm text-slate-300">Request Headers (JSON)</label><textarea rows={3} className="w-full bg-tertiary mt-1 p-2 rounded border border-slate-600 font-mono text-xs">{`{
  "Accept": "application/json"
}`}</textarea></div>
            </>
          );
      default:
        return <p className="text-slate-400">No configuration available for this connector type.</p>;
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4">
      <div className="bg-secondary rounded-lg shadow-xl w-full max-w-lg" onClick={e => e.stopPropagation()}>
        <form onSubmit={handleSave}>
          <div className="p-5 border-b border-slate-700 flex justify-between items-center">
            <div>
              <h2 className="text-xl font-bold text-white">Configure Connector</h2>
              <p className="text-sm text-cyan-400">{connector.protocol}</p>
            </div>
            <button type="button" onClick={onClose} className="text-slate-400 hover:text-white"><X size={24} /></button>
          </div>
          <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
            {renderFields()}
          </div>
          <div className="p-5 border-t border-slate-700 flex justify-end gap-3">
            <button type="button" onClick={onClose} className="px-4 py-2 rounded-md bg-slate-600">Cancel</button>
            <button type="submit" disabled={isSaving} className="px-4 py-2 rounded-md bg-accent hover:bg-accent-dark disabled:bg-slate-500 flex items-center gap-2">
              {isSaving && <Loader2 className="animate-spin" size={16} />} Save
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// --- DataConnectors Component ---
const connectorData: Connector[] = [
  {
    protocol: 'BACnet/IP',
    description: 'Main Building HVAC Controls',
    status: 'Connected',
    rate: '1483 points/min',
    lastSync: '3s ago',
  },
  {
    protocol: 'Modbus TCP',
    description: 'Factory Floor Energy Meters',
    status: 'Error',
    rate: '---',
    lastSync: '2h ago',
  },
  {
    protocol: 'OPC Unified Architecture',
    description: 'Research Lab Sensors',
    status: 'Disconnected',
    rate: '---',
    lastSync: '1d ago',
  },
  {
    protocol: 'Generic REST API',
    description: 'Weather Service Integration',
    status: 'Connected',
    rate: '15 points/min',
    lastSync: '5m ago',
  },
];

const statusConfig: Record<ConnectorStatus, { icon: React.ReactNode; color: string; ringColor: string; }> = {
    Connected: { icon: <CheckCircle className="w-5 h-5 text-green-400" />, color: 'text-green-400', ringColor: 'ring-green-500/30' },
    Error: { icon: <AlertTriangle className="w-5 h-5 text-red-400" />, color: 'text-red-400', ringColor: 'ring-red-500/30' },
    Disconnected: { icon: <PowerOff className="w-5 h-5 text-slate-500" />, color: 'text-slate-500', ringColor: 'ring-slate-500/30' },
};


const DataConnectors: React.FC<{ onConfigure: (connector: Connector) => void }> = ({ onConfigure }) => {
  return (
    <div className="bg-tertiary p-6 rounded-lg shadow-inner">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white">BMS & Data Connectors</h2>
        <p className="text-slate-400 mt-1 max-w-3xl">
          Configure and monitor data connectors for third-party systems like your Building Management System (BMS). These connectors run on-premise to securely translate and send data to RosaiQ Air OS.
        </p>
      </div>

      <div className="space-y-4">
        {connectorData.map((connector, index) => {
          const statusInfo = statusConfig[connector.status];
          return (
            <div key={index} className="bg-secondary p-4 rounded-lg flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
              <div className="flex items-center gap-4 flex-grow">
                <div className={`p-3 rounded-full bg-slate-800 ring-4 ${statusInfo.ringColor}`}>
                  <Network className="w-6 h-6 text-cyan-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-lg">{connector.protocol}</h3>
                  <p className="text-sm text-slate-400">{connector.description}</p>
                </div>
              </div>

              <div className="w-full lg:w-auto flex items-center justify-between lg:justify-end gap-x-6 gap-y-3 flex-wrap pl-2 lg:pl-0">
                <div className="flex items-center gap-2 text-sm" title={`Status: ${connector.status}`}>
                  {statusInfo.icon}
                  <span className={`font-semibold ${statusInfo.color}`}>{connector.status}</span>
                </div>
                
                <div className="text-sm text-center">
                  <p className="font-semibold text-white">{connector.rate}</p>
                  <p className="text-xs text-slate-500">Data Rate</p>
                </div>
                
                <div className="text-sm text-center">
                  <p className="font-semibold text-white">{connector.lastSync}</p>
                  <p className="text-xs text-slate-500">Last Sync</p>
                </div>

                <button 
                  onClick={() => onConfigure(connector)}
                  className="px-3 py-1.5 text-xs font-semibold bg-slate-600 text-slate-300 rounded-md hover:bg-slate-500 transition-colors">
                  Configure
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};


type Tab = 'sensors' | 'zones' | 'purifiers' | 'vape' | 'users' | 'connectors';

const TabButton: React.FC<{ active: boolean; onClick: () => void; children: React.ReactNode }> = ({ active, onClick, children }) => (
    <button onClick={onClick} className={`flex items-center gap-2 px-4 py-3 text-sm font-semibold transition-colors duration-200 border-b-2 ${active ? 'text-accent border-accent' : 'text-slate-400 border-transparent hover:text-white hover:border-slate-500'}`}>
        {children}
    </button>
);


const Management: React.FC = () => {
    const [activeTab, setActiveTab] = useState<Tab>('sensors');
    const [dataVersion, setDataVersion] = useState(0);
    const [isConnectorModalOpen, setIsConnectorModalOpen] = useState(false);
    const [selectedConnector, setSelectedConnector] = useState<Connector | null>(null);

    const handleDataChanged = () => {
        setDataVersion(v => v + 1);
    };

    const handleConfigureConnector = (connector: Connector) => {
        setSelectedConnector(connector);
        setIsConnectorModalOpen(true);
    };

    const renderContent = () => {
        switch (activeTab) {
            case 'sensors':
                return <DeviceLocationManagement key={`sensors-${dataVersion}`} />;
            case 'zones':
                return <ZoneManagement key={`zones-${dataVersion}`} onDataChanged={handleDataChanged} />;
            case 'purifiers':
                return <ManagePurifiers key={`purifiers-${dataVersion}`} onDataChanged={handleDataChanged} />;
            case 'vape':
                return <ManageVapeDevices key={`vape-${dataVersion}`} onDataChanged={handleDataChanged} />;
            case 'users':
                return <UserManagement key={`users-${dataVersion}`} />;
            case 'connectors':
                return <DataConnectors key={`connectors-${dataVersion}`} onConfigure={handleConfigureConnector} />;
            default:
                return null;
        }
    }


    return (
        <div className="space-y-6">
            <ConnectorConfigModal 
                isOpen={isConnectorModalOpen}
                onClose={() => setIsConnectorModalOpen(false)}
                connector={selectedConnector}
            />
            <div>
                <h1 className="text-3xl font-bold text-white">Management Console</h1>
                <p className="text-slate-400 mt-1">Administer devices, locations, and users.</p>
            </div>
            
            <div className="bg-secondary p-2 rounded-lg">
                <div className="flex border-b border-slate-700 flex-wrap">
                     <TabButton active={activeTab === 'sensors'} onClick={() => setActiveTab('sensors')}>
                        <SlidersHorizontal size={16} /> Sensors & Locations
                    </TabButton>
                    <TabButton active={activeTab === 'zones'} onClick={() => setActiveTab('zones')}>
                        <Grid3X3 size={16} /> Zone Management
                    </TabButton>
                    <TabButton active={activeTab === 'purifiers'} onClick={() => setActiveTab('purifiers')}>
                        <Wind size={16} /> Air Purifiers
                    </TabButton>
                    <TabButton active={activeTab === 'vape'} onClick={() => setActiveTab('vape')}>
                        <Cloud size={16} /> Vape Detectors
                    </TabButton>
                    <TabButton active={activeTab === 'users'} onClick={() => setActiveTab('users')}>
                        <Users size={16} /> User Management
                    </TabButton>
                    <TabButton active={activeTab === 'connectors'} onClick={() => setActiveTab('connectors')}>
                        <Network size={16} /> BMS & Data Connectors
                    </TabButton>
                </div>
                
                <div className="p-6">
                    {renderContent()}
                </div>
            </div>
        </div>
    );
};

export default Management;