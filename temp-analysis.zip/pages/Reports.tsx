import React, { useState, useEffect } from 'react';
// FIX: Corrected import path for apiService.
import { getWeeklyReportData } from '../services/apiService';
// FIX: Corrected import path for types.
import { ReportData, Metric, AlertType } from '../types';
import { Loader2, TrendingUp, ShieldAlert, AlertTriangle, BarChart2, Lightbulb } from 'lucide-react';
import { AreaChart, Area, LineChart, Line, Bar, BarChart as RechartsBarChart, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { useSettings } from '../contexts/SettingsContext';

const SummaryCard: React.FC<{ title: string; value: string; color: string; icon: React.ReactNode }> = ({ title, value, color, icon }) => (
    <div className="bg-secondary p-4 rounded-lg shadow-md flex items-center gap-4">
        <div className={`p-3 rounded-full`} style={{ backgroundColor: `${color}20`, color }}>
            {icon}
        </div>
        <div>
            <p className="text-2xl font-bold text-white">{value}</p>
            <p className="text-sm text-slate-400">{title}</p>
        </div>
    </div>
);

// FIX: Added missing alert types to satisfy the Record<AlertType, string> type.
const ALERT_TYPE_NAMES: Record<AlertType, string> = {
    'device-offline': 'Device Offline',
    'low-battery': 'Low Battery',
    'threshold-exceeded': 'Threshold Exceeded',
    'vape-detected': 'Vape Detected',
    'smoke-detected': 'Smoke Detected',
    'wildfire-risk': 'Wildfire Risk',
    'smoke-vape-detected': 'Smoke/Vape Event'
};

const Reports: React.FC = () => {
    const [reportData, setReportData] = useState<ReportData | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [aiSummary, setAiSummary] = useState('');
    const [aiSummaryLoading, setAiSummaryLoading] = useState(false);
    const { getMetricQuality, getQualityFromAqi, thresholds } = useSettings();

    useEffect(() => {
        const fetchData = async () => {
            try {
                setLoading(true);
                const data = await getWeeklyReportData();
                setReportData(data);
            } catch (err) {
                console.error(err);
                setError('Failed to generate weekly report.');
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    useEffect(() => {
        if (reportData) {
            generateAISummary();
        }
    }, [reportData]);

    const generateAISummary = () => {
        if (!reportData) return;
        setAiSummaryLoading(true);
        const { summary, alertAnalysis } = reportData;
        setTimeout(() => {
            let text = `Facility Manager, here is your weekly summary.\n\nOverall air quality was generally **${getQualityFromAqi(summary.overallAqi).label}**, with a weekly average AQI of **${summary.overallAqi}**. A total of **${alertAnalysis.total}** alerts were triggered. \n\nThe area with the highest average AQI was **${summary.worstLocation.name}** (AQI ${summary.worstLocation.aqi}), which should be prioritized for review. Conversely, **${summary.bestLocation.name}** (AQI ${summary.bestLocation.aqi}) maintained the best air quality.`;
            setAiSummary(text);
            setAiSummaryLoading(false);
        }, 1500);
    };

    const POLLUTANT_DETAILS: Record<string, { name: string, unit: string }> = {
        pm25: { name: 'PM2.5', unit: 'µg/m³' }, co2: { name: 'CO₂', unit: 'ppm' },
        voc: { name: 'VOC', unit: 'index' }, hcho: { name: 'HCHO', unit: 'ppb' },
        nox: { name: 'NOx', unit: 'index' }, pm10: { name: 'PM10', unit: 'µg/m³' },
    };

    const PIE_COLORS = ['#ef4444', '#f97316', '#3b82f6'];

    if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /> <span className="ml-3 text-lg">Generating Your Weekly Report...</span></div>;
    if (error) return <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error}</div>;
    if (!reportData) return <div className="text-center py-10 text-slate-400">No data available for the report.</div>;

    const { summary, dailyAqiTrend, locationHotspots, alertAnalysis, pollutantBreakdown } = reportData;

    return (
        <div className="space-y-8">
            <div>
                <h1 className="text-3xl font-bold text-white">Weekly Air Quality Report</h1>
                <p className="text-slate-400 mt-1">Analysis for the past 7 days.</p>
            </div>
            
            <div className="bg-secondary p-6 rounded-lg shadow-lg">
                <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2"><Lightbulb className="text-accent"/> Executive Summary</h2>
                {aiSummaryLoading ? <div className="flex items-center gap-2 text-slate-400"><Loader2 className="w-4 h-4 animate-spin"/>Analyzing trends...</div> : <p className="text-slate-300 whitespace-pre-wrap leading-relaxed" dangerouslySetInnerHTML={{ __html: aiSummary.replace(/\*\*(.*?)\*\*/g, '<strong class="text-white">$1</strong>') }} />}
            </div>

            <div className="bg-secondary p-6 rounded-lg shadow-lg">
                <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2"><TrendingUp className="text-accent"/> Weekly AQI Trend</h2>
                <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={dailyAqiTrend} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                        <defs>
                            <linearGradient id="colorAqi" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor={getQualityFromAqi(summary.overallAqi).color} stopOpacity={0.8}/>
                                <stop offset="95%" stopColor={getQualityFromAqi(summary.overallAqi).color} stopOpacity={0}/>
                            </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#475569" strokeOpacity={0.5} />
                        <XAxis dataKey="date" tickFormatter={(d) => new Date(d).toLocaleDateString(undefined, {weekday: 'short'})} stroke="#94a3b8" tick={{ fontSize: 12 }} />
                        <YAxis stroke="#94a3b8" tick={{ fontSize: 12 }} domain={[0, 'dataMax + 20']} />
                        <Tooltip contentStyle={{ backgroundColor: '#162030', border: '1px solid #334155' }} />
                        <Area type="monotone" dataKey="averageAqi" name="Average AQI" stroke={getQualityFromAqi(summary.overallAqi).color} strokeWidth={2} fillOpacity={1} fill="url(#colorAqi)" />
                    </AreaChart>
                </ResponsiveContainer>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-secondary p-6 rounded-lg shadow-lg">
                    <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2"><AlertTriangle className="text-accent"/> Location Hotspots</h2>
                    <div>
                        <h3 className="font-semibold text-slate-300 mb-2">By Highest Average AQI</h3>
                        <ul className="space-y-2">
                            {locationHotspots.byAqi.map(loc => (
                                <li key={loc.locationName} className="flex justify-between items-center bg-tertiary p-3 rounded-md text-sm">
                                    <span className="text-white">{loc.locationName}</span>
                                    <span className="font-bold" style={{color: getQualityFromAqi(loc.averageAqi).color}}>{loc.averageAqi}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                    <div className="mt-6">
                        <h3 className="font-semibold text-slate-300 mb-2">By Most Alerts</h3>
                         <ul className="space-y-2">
                            {locationHotspots.byAlerts.map(loc => (
                                <li key={loc.locationName} className="flex justify-between items-center bg-tertiary p-3 rounded-md text-sm">
                                    <span className="text-white">{loc.locationName}</span>
                                    <span className="font-bold text-slate-300">{loc.alertCount} {loc.alertCount === 1 ? 'alert' : 'alerts'}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
                <div className="bg-secondary p-6 rounded-lg shadow-lg">
                     <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2"><ShieldAlert className="text-accent"/> Alert Analysis</h2>
                     <p className="text-4xl font-bold text-white mb-4">{alertAnalysis.total} <span className="text-lg text-slate-400 font-normal">total alerts this week</span></p>
                     <ResponsiveContainer width="100%" height={250}>
                        <PieChart>
                            <Pie data={Object.entries(alertAnalysis.byType).map(([name, value]) => ({ name: ALERT_TYPE_NAMES[name as AlertType], value }))} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                                {Object.keys(alertAnalysis.byType).map((entry, index) => <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />)}
                            </Pie>
                            <Tooltip contentStyle={{ backgroundColor: '#162030', border: '1px solid #334155' }} />
                            <Legend />
                        </PieChart>
                     </ResponsiveContainer>
                </div>
            </div>

            <div className="bg-secondary p-6 rounded-lg shadow-lg">
                <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2"><BarChart2 className="text-accent"/> Pollutant Deep Dive</h2>
                <p className="text-slate-400 mb-4 text-sm">Weekly average concentration for key pollutants across all devices.</p>
                <div className="space-y-4">
                {Object.entries(pollutantBreakdown).map(([key, value]) => {
                    const metric = key as Metric;
                    const details = POLLUTANT_DETAILS[metric];
                    if (!details || typeof value !== 'number') return null;
                    const quality = getMetricQuality(metric, value);
                    
                    const metricThresholds = thresholds[metric];
                    // Use the 'moderate' threshold as the 100% mark for the bar for a more intuitive scale.
                    const maxForBar = metricThresholds?.moderate || value * 2; // Fallback if no threshold
                    const widthPercent = Math.min((value / maxForBar) * 100, 100);

                    return (
                        <div key={metric}>
                            <div className="flex justify-between items-baseline text-sm mb-1">
                                <h4 className="font-semibold text-slate-300">{details.name}</h4>
                                <p className="text-white font-bold">{value.toLocaleString()} <span className="text-xs text-slate-400 font-normal">{details.unit}</span></p>
                            </div>
                            <div className="w-full bg-tertiary rounded-full h-2.5">
                                <div className="h-2.5 rounded-full" style={{ width: `${widthPercent}%`, backgroundColor: quality.color }}></div>
                            </div>
                        </div>
                    )
                })}
                </div>
            </div>

        </div>
    );
};

export default Reports;