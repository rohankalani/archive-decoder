import React, { useState, useMemo } from 'react';
// FIX: Corrected import path for apiService.
import { getResetReportData } from '../services/apiService';
import { ResetReportData, ResetMetric, DailyResetBreakdown } from '../types';
import { Loader2, Calendar, BadgeCheck, X, CheckCircle, XCircle } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip as RechartsTooltip, ReferenceLine } from 'recharts';
import { DateRange, DayPicker } from 'react-day-picker';
// FIX: Changed date-fns imports to use subpaths for functions not exported from the root module, resolving import errors.
import { format, endOfMonth, eachDayOfInterval, isSameDay, getMonth, getYear, addMonths } from 'date-fns';
import startOfMonth from 'date-fns/startOfMonth';
import subMonths from 'date-fns/subMonths';


const RESET_THRESHOLDS: Record<ResetMetric, { limit: number; unit: string; name: string }> = {
    pm25: { limit: 15, unit: 'µg/m³', name: 'Particulate Matter (PM2.5)' },
    voc: { limit: 500, unit: 'µg/m³', name: 'Total Volatile Organic Compounds' },
    co2: { limit: 1000, unit: 'ppm', name: 'Carbon Dioxide (CO₂)' },
};


// --- Daily Detail Modal ---
const DailyDetailModal: React.FC<{ day: DailyResetBreakdown | null; onClose: () => void }> = ({ day, onClose }) => {
    if (!day) return null;
    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4 animate-fade-in-scale" onClick={onClose}>
            <div className="bg-secondary rounded-lg shadow-xl w-full max-w-sm" onClick={e => e.stopPropagation()}>
                <div className="p-5 border-b border-slate-700 flex justify-between items-center">
                    <div>
                        <h2 className="text-xl font-bold text-white">Daily Performance</h2>
                        <p className="text-cyan-400">{format(new Date(day.date), 'EEEE, MMMM d, yyyy')}</p>
                    </div>
                    <button onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-6 h-6" /></button>
                </div>
                <div className="p-5 space-y-4">
                    {(Object.keys(day.metrics) as ResetMetric[]).map((metric) => {
                        const data = day.metrics[metric];
                        const standard = RESET_THRESHOLDS[metric];
                        return (
                             <div key={metric} className={`p-3 rounded-lg flex justify-between items-center ${data.isCompliant ? 'bg-green-500/10' : 'bg-red-500/10'}`}>
                                <div>
                                    <p className="font-semibold text-white">{standard.name}</p>
                                    <p className="text-xs text-slate-400">Limit: ≤ {standard.limit} {standard.unit}</p>
                                </div>
                                <div className="text-right">
                                    <p className={`text-lg font-bold ${data.isCompliant ? 'text-green-400' : 'text-red-400'}`}>{data.value.toFixed(1)}</p>
                                    {data.isCompliant ? 
                                        <CheckCircle className="w-4 h-4 text-green-400 inline-block" /> : 
                                        <XCircle className="w-4 h-4 text-red-400 inline-block" />}
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div>
        </div>
    );
};

// --- Calendar Component ---
const ComplianceCalendar: React.FC<{ month: Date; data: DailyResetBreakdown[]; onDayClick: (day: DailyResetBreakdown) => void; }> = ({ month, data, onDayClick }) => {
    const monthStart = startOfMonth(month);
    const monthEnd = endOfMonth(month);
    const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });
    const startingDayOfWeek = monthStart.getDay(); // 0 = Sunday, 1 = Monday...

    const getDayData = (day: Date) => data.find(d => isSameDay(new Date(d.date), day));
    
    return (
        <div className="bg-tertiary p-4 rounded-lg">
            <h3 className="text-lg font-bold text-center text-white mb-3">{format(month, 'MMMM yyyy')}</h3>
            <div className="grid grid-cols-7 gap-1 text-center text-xs text-slate-400 mb-2">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => <div key={d}>{d}</div>)}
            </div>
            <div className="grid grid-cols-7 gap-1">
                {Array.from({ length: startingDayOfWeek }).map((_, i) => <div key={`empty-${i}`}></div>)}
                {daysInMonth.map(day => {
                    const dayData = getDayData(day);
                    let bgColor = 'bg-slate-700/50';
                    if (dayData) {
                        bgColor = dayData.isCompliant ? 'bg-green-500/80 hover:bg-green-400' : 'bg-red-500/80 hover:bg-red-400';
                    }
                    return (
                        <button 
                            key={day.toString()} 
                            onClick={() => dayData && onDayClick(dayData)}
                            disabled={!dayData}
                            className={`h-9 w-full rounded flex items-center justify-center text-sm font-semibold text-white transition-colors ${bgColor} disabled:opacity-50 disabled:cursor-not-allowed`}
                        >
                            {format(day, 'd')}
                        </button>
                    )
                })}
            </div>
        </div>
    );
};

// --- Metric Performance Card ---
const MetricPerformanceCard: React.FC<{ metric: ResetMetric, summary: ResetReportData['metricSummaries'][ResetMetric] }> = ({ metric, summary }) => {
    const standard = RESET_THRESHOLDS[metric];
    const avgColor = summary.periodAverage <= standard.limit ? 'text-white' : 'text-red-400';
    const peakColor = summary.peakDailyAverage <= standard.limit ? 'text-white' : 'text-red-400';

    return (
        <div className="bg-tertiary p-6 rounded-lg">
            <h3 className="text-xl font-bold text-white">{standard.name}</h3>
            <p className="text-sm text-slate-400 mb-4">RESET Limit: ≤ {standard.limit} {standard.unit} (Daily Avg)</p>
            <div className="h-28">
                 <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={summary.dailyAverages} margin={{ top: 5, right: 10, left: -25, bottom: 5 }}>
                        <defs><linearGradient id={`color-${metric}`} x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#38bdf8" stopOpacity={0.4}/><stop offset="95%" stopColor="#38bdf8" stopOpacity={0}/></linearGradient></defs>
                        <XAxis dataKey="date" tickFormatter={d => format(new Date(d), 'd MMM')} stroke="#94a3b8" tick={{ fontSize: 10 }} dy={5} />
                        <YAxis stroke="#94a3b8" tick={{ fontSize: 10 }} domain={['auto', 'dataMax + 10']} />
                        <RechartsTooltip contentStyle={{ backgroundColor: '#162030', border: '1px solid #334155' }} />
                        <ReferenceLine y={standard.limit} stroke="#f87171" strokeDasharray="3 3" />
                        <Area type="monotone" dataKey="value" stroke="#38bdf8" strokeWidth={2} fillOpacity={1} fill={`url(#color-${metric})`} />
                    </AreaChart>
                </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-3 gap-4 text-center mt-4">
                <div className="bg-slate-800 p-2 rounded"><p className="text-xs text-slate-400">Period Avg</p><p className={`text-lg font-bold ${avgColor}`}>{summary.periodAverage.toFixed(1)}</p></div>
                <div className="bg-slate-800 p-2 rounded"><p className="text-xs text-slate-400">Peak Daily Avg</p><p className={`text-lg font-bold ${peakColor}`}>{summary.peakDailyAverage.toFixed(1)}</p></div>
                <div className="bg-slate-800 p-2 rounded"><p className="text-xs text-slate-400">Days Exceeded</p><p className="text-lg font-bold text-white">{summary.daysExceeded}</p></div>
            </div>
        </div>
    );
};


const ResetReport: React.FC = () => {
    const [reportData, setReportData] = useState<ResetReportData | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    
    const getInitialDateRange = (): DateRange => {
        const to = new Date();
        const from = subMonths(to, 2);
        return { from, to };
    };
    
    const [dateRange, setDateRange] = useState<DateRange | undefined>(getInitialDateRange());
    const [isPickerOpen, setIsPickerOpen] = useState(false);
    const [selectedDay, setSelectedDay] = useState<DailyResetBreakdown | null>(null);
    
    const handleGenerateReport = async () => {
        if (!dateRange?.from || !dateRange.to) {
            setError("Please select a valid date range.");
            return;
        }
        setLoading(true);
        setError(null);
        setReportData(null);
        try {
            const data = await getResetReportData(dateRange.from, dateRange.to);
            setReportData(data);
        } catch (err: any) {
            setError(err.message || 'Failed to generate RESET report.');
        } finally {
            setLoading(false);
        }
    };
    
    const complianceStatus = useMemo(() => {
        if (!reportData) return { label: 'Awaiting Report', color: 'text-slate-400', bgColor: 'bg-slate-700' };
        const pct = reportData.overallCompliance.percentage;
        if (pct >= 95) return { label: 'Certified', color: 'text-green-400', bgColor: 'bg-green-500/10' };
        if (pct >= 80) return { label: 'Pre-Certification', color: 'text-yellow-400', bgColor: 'bg-yellow-500/10' };
        return { label: 'Action Required', color: 'text-red-400', bgColor: 'bg-red-500/10' };
    }, [reportData]);

    const calendarMonths = useMemo(() => {
        if (!dateRange?.from) return [];
        const start = startOfMonth(dateRange.from);
        return [start, addMonths(start, 1), addMonths(start, 2)];
    }, [dateRange]);

    return (
        <div className="space-y-6">
            <DailyDetailModal day={selectedDay} onClose={() => setSelectedDay(null)} />
            <div>
                <h1 className="text-3xl font-bold text-white">RESET™ Air Certification Report</h1>
                <p className="text-slate-400 mt-1">Real-time performance tracking for RESET Air for Commercial Interiors certification.</p>
            </div>

            <div className="bg-secondary p-4 rounded-lg flex flex-col md:flex-row justify-between md:items-center gap-4">
                <div className="relative">
                    <button onClick={() => setIsPickerOpen(o => !o)} className="flex items-center gap-2 px-4 py-2 bg-tertiary rounded-md text-slate-300 hover:bg-slate-700">
                        <Calendar className="w-5 h-5 text-accent"/>
                        <span>{dateRange?.from && dateRange?.to ? `${format(dateRange.from, 'd MMM yyyy')} - ${format(dateRange.to, 'd MMM yyyy')}` : 'Select 3 Month Period'}</span>
                    </button>
                     {isPickerOpen && (
                        <div className="absolute top-full mt-2 z-30 bg-secondary rounded-lg border border-slate-700 p-2 shadow-2xl">
                             <style>{`.rdp { --rdp-cell-size: 38px; --rdp-caption-font-size: 1rem; --rdp-background-color: transparent; --rdp-color: #e2e8f0; --rdp-accent-color: #38bdf8; } .rdp-button:hover:not([disabled]):not(.rdp-day_selected) { background-color: #1e2b3b; } .rdp-day_selected { background-color: var(--rdp-accent-color); color: #0b111c; } .rdp-caption_label { font-weight: 600; color: #f1f5f9; } .rdp-head_cell { color: #94a3b8; } `}</style>
                             <DayPicker mode="range" selected={dateRange} onSelect={setDateRange} numberOfMonths={3} onMonthChange={(month) => setDateRange({from: startOfMonth(month), to: endOfMonth(addMonths(month, 2))})} />
                        </div>
                    )}
                </div>
                 <button onClick={handleGenerateReport} disabled={loading} className="w-full md:w-auto px-6 py-2 rounded-md text-white bg-accent hover:bg-accent-dark transition-colors disabled:bg-slate-500 flex items-center justify-center gap-2">
                    {loading && <Loader2 className="w-4 h-4 animate-spin"/>}
                    Generate Report
                </button>
            </div>

            {loading && <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /> <span className="ml-3 text-lg">Analyzing 3 Months of Performance Data...</span></div>}
            {error && <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error}</div>}

            {reportData && (
                 <div className="space-y-6 animate-fade-in-scale">
                    <div className="bg-secondary p-6 rounded-lg shadow-lg">
                        <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2"><BadgeCheck className="text-accent"/> Overall Certification Status</h2>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
                            <div className={`p-4 rounded-lg ${complianceStatus.bgColor}`}>
                                <p className="text-sm text-slate-400">Certification Status</p>
                                <p className={`text-3xl font-bold ${complianceStatus.color}`}>{complianceStatus.label}</p>
                            </div>
                            <div className="p-4 rounded-lg bg-tertiary">
                                <p className="text-sm text-slate-400">Compliant Days</p>
                                <p className="text-3xl font-bold text-white">{reportData.overallCompliance.compliantDays} <span className="text-lg text-slate-500">/ {reportData.overallCompliance.totalDays}</span></p>
                            </div>
                            <div className="p-4 rounded-lg bg-tertiary">
                                <p className="text-sm text-slate-400">Compliance Score</p>
                                <p className="text-3xl font-bold text-white">{reportData.overallCompliance.percentage.toFixed(1)}<span className="text-lg text-slate-500">%</span></p>
                            </div>
                        </div>
                    </div>
                 
                    <div className="bg-secondary p-6 rounded-lg shadow-lg">
                         <h2 className="text-2xl font-bold text-white mb-4">Daily Compliance Calendar</h2>
                         <p className="text-slate-400 text-sm mb-4">Click on a day for a detailed performance breakdown.</p>
                         <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                            {calendarMonths.map(month => (
                                <ComplianceCalendar key={month.toString()} month={month} data={reportData.dailyBreakdown} onDayClick={setSelectedDay} />
                            ))}
                         </div>
                    </div>

                    <div className="bg-secondary p-6 rounded-lg shadow-lg">
                        <h2 className="text-2xl font-bold text-white mb-4">Pollutant Performance Breakdown</h2>
                        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                           <MetricPerformanceCard metric="pm25" summary={reportData.metricSummaries.pm25} />
                           <MetricPerformanceCard metric="voc" summary={reportData.metricSummaries.voc} />
                           <MetricPerformanceCard metric="co2" summary={reportData.metricSummaries.co2} />
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ResetReport;