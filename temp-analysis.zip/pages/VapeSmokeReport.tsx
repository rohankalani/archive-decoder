import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { getDevices } from '../services/apiService';
import { useRealtimeData } from '../contexts/RealtimeDataContext';
import { DeviceWithData, RealtimeData, Alert as AlertType } from '../types';
import { Loader2, User, Cloudy, Flame, List, Settings } from 'lucide-react';
import AlertCard from '../components/AlertCard';
import { useAlerts } from '../contexts/AlertsContext';


type Tab = 'status' | 'history';
type VapeDeviceStatus = 'Clear' | 'Vaping Detected' | 'Smoke Detected' | 'Offline' | 'Initializing';

const OFFLINE_THRESHOLD = 30 * 1000;

// --- Helper Functions & Components ---

const getDeviceStatus = (device: DeviceWithData, liveData: RealtimeData | null, activeAlerts: AlertType[]): VapeDeviceStatus => {
    if (device.status === 'offline') return 'Offline';
    if (!liveData) return 'Initializing';
    if (activeAlerts.some(a => a.deviceId === device.id && a.type === 'smoke-detected')) return 'Smoke Detected';
    if (activeAlerts.some(a => a.deviceId === device.id && a.type === 'vape-detected')) return 'Vaping Detected';
    return 'Clear';
};

const statusConfig: Record<VapeDeviceStatus, { color: string, icon: React.ReactNode }> = {
    'Clear': { color: 'border-green-500/50', icon: <Cloudy className="w-8 h-8 text-green-400" /> },
    'Vaping Detected': { color: 'border-orange-500 animate-pulse', icon: <Cloudy className="w-8 h-8 text-orange-400" /> },
    'Smoke Detected': { color: 'border-red-500 animate-pulse', icon: <Flame className="w-8 h-8 text-red-500" /> },
    'Offline': { color: 'border-slate-600', icon: <Cloudy className="w-8 h-8 text-slate-500" /> },
    'Initializing': { color: 'border-slate-700', icon: <Loader2 className="w-8 h-8 text-slate-500 animate-spin" /> },
};

const TabButton: React.FC<{ active: boolean; onClick: () => void; children: React.ReactNode }> = ({ active, onClick, children }) => (
    <button onClick={onClick} className={`flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-md transition-colors ${active ? 'bg-accent text-white' : 'text-slate-300 hover:bg-slate-700'}`}>
        {children}
    </button>
);

// --- Sub-Views (Tabs) ---

const LiveStatusView: React.FC<{ devices: DeviceWithData[], activeAlerts: AlertType[] }> = ({ devices, activeAlerts }) => (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {devices.map(device => {
            const liveData = device.latest_data;
            const deviceStatus = getDeviceStatus(device, liveData, activeAlerts);
            const config = statusConfig[deviceStatus];
            const voc = liveData?.voc;
            const pm25 = liveData?.pm25;
            const presence = liveData?.presence;

            return (
                <div key={device.id} className={`bg-secondary p-5 rounded-lg border-2 ${config.color} transition-all`}>
                    <div className="flex justify-between items-start">
                        <div>
                            <h3 className="text-lg font-bold text-white">{device.name}</h3>
                            <p className="text-sm text-slate-400">{device.location.name}</p>
                        </div>
                        {config.icon}
                    </div>
                    <div className="mt-4">
                        <p className="text-2xl font-bold text-white">{deviceStatus}</p>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-center mt-6 border-t border-slate-700 pt-4">
                        <div>
                            <p className="text-2xl font-bold text-white">{voc?.toFixed(0) ?? '--'}</p>
                            <p className="text-xs text-slate-400">VOC Index</p>
                        </div>
                        <div>
                            <p className="text-2xl font-bold text-white">{pm25?.toFixed(1) ?? '--'}</p>
                            <p className="text-xs text-slate-400">PM2.5 (µg/m³)</p>
                        </div>
                        <div>
                            <div className="flex items-center justify-center gap-2 h-7">
                                {presence === 1 ? <User className="w-7 h-7 text-accent" /> : <User className="w-7 h-7 text-slate-600" />}
                            </div>
                            <p className="text-xs text-slate-400 mt-1">{presence === 1 ? 'Presence' : 'No Presence'}</p>
                        </div>
                    </div>
                </div>
            );
        })}
    </div>
);

const EventHistoryView: React.FC = () => {
    const { alerts, acknowledgeAlert } = useAlerts();
    const vapeSmokeAlerts = useMemo(() => {
        const relevantTypes: AlertType['type'][] = ['vape-detected', 'smoke-detected', 'smoke-vape-detected'];
        return alerts.filter(a => relevantTypes.includes(a.type));
    }, [alerts]);

    return (
        <div>
            {vapeSmokeAlerts.length > 0 ? (
                <div className="space-y-4">
                    {vapeSmokeAlerts.map(alert => (
                        <AlertCard key={alert.id} alert={alert} onAcknowledge={acknowledgeAlert} />
                    ))}
                </div>
            ) : (
                <div className="text-center py-16 bg-secondary rounded-lg">
                    <h3 className="text-xl font-semibold text-slate-300">No Events Logged</h3>
                    <p className="text-slate-400 mt-2">The historical log for vape or smoke alerts is clear.</p>
                </div>
            )}
        </div>
    );
};

// --- Main Component ---

const VapeSmokeReport: React.FC = () => {
    const [allDevices, setAllDevices] = useState<DeviceWithData[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const { realtimeData } = useRealtimeData();
    const { alerts } = useAlerts();
    const [activeTab, setActiveTab] = useState<Tab>('status');

    const fetchData = useCallback(async () => {
        try {
            setLoading(true);
            const devices = await getDevices();
            setAllDevices(devices);
        } catch (err) {
            console.error(err);
            setError("Failed to load device list.");
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const devicesWithLiveData = useMemo(() => {
        const now = Date.now();
        return allDevices.map(d => {
            const latest_data = realtimeData[d.id] || d.latest_data;
            const lastUpdate = latest_data ? new Date(latest_data.timestamp).getTime() : 0;
            const status: 'online' | 'offline' = (now - lastUpdate) < OFFLINE_THRESHOLD ? 'online' : 'offline';
            return { ...d, latest_data, status };
        });
    }, [allDevices, realtimeData]);
    
    const vapeDevices = useMemo(() => devicesWithLiveData.filter(d => d.type === 'vape-smoke'), [devicesWithLiveData]);
    const activeAlerts = useMemo(() => alerts.filter(a => a.status === 'active'), [alerts]);

    const renderContent = () => {
        if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>;
        if (error) return <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error}</div>;

        if (vapeDevices.length === 0 && activeTab !== 'history') {
             return (
                <div className="text-center py-16 bg-secondary rounded-lg">
                    <h3 className="text-xl font-semibold text-slate-300">No Vape/Smoke Detectors Found</h3>
                    <p className="text-slate-400 mt-2">Add and configure detectors in the Management Console.</p>
                </div>
            );
        }

        switch (activeTab) {
            case 'status':
                return <LiveStatusView devices={vapeDevices} activeAlerts={activeAlerts} />;
            case 'history':
                return <EventHistoryView />;
            default:
                return null;
        }
    };

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold text-white">Vape, Smoke & Wildfire Detection</h1>
                <p className="text-slate-400 mt-1">Real-time monitoring and alerts for environmental threats.</p>
            </div>

            <div className="bg-secondary p-2 rounded-lg flex items-center gap-2 flex-wrap">
                <TabButton active={activeTab === 'status'} onClick={() => setActiveTab('status')}><Cloudy size={16}/>Live Status</TabButton>
                <TabButton active={activeTab === 'history'} onClick={() => setActiveTab('history')}><List size={16}/>Event History</TabButton>
            </div>

            {renderContent()}
        </div>
    );
};

export default VapeSmokeReport;