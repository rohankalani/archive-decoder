import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Link } from 'react-router-dom';
// FIX: Moved the 'WellSettings' type import from 'apiService' to 'types' as it is a type definition, not an export from the service.
import { getWellComplianceData, getWellSettings } from '../services/apiService';
import { WellComplianceReport, WellPeriod, WellFeatureId, WellComplianceState, WellDrillDownData, WellSettings } from '../types';
import { Loader2, CheckCircle, XCircle, Download, BookOpen, Settings, Star, ShieldCheck } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import WellDrillDownModal from '../components/WellDrillDownModal';
import { WELL_FEATURES } from '../utils/wellStandard';


const FeatureRow: React.FC<{ feature: WellDrillDownData['feature'], status: WellComplianceState, onClick: () => void }> = ({ feature, status, onClick }) => {
    const isCompliant = status === 'Compliant';
    return (
        <tr className="border-b border-slate-700 hover:bg-slate-750/50 cursor-pointer" onClick={onClick}>
            <td className="p-4">
                <p className="font-bold text-white">{feature.id}: {feature.name}</p>
                <p className="text-sm text-slate-400">{feature.description}</p>
            </td>
            <td className="p-4 text-center">
                {feature.type === 'Precondition' ? (
                    <span className="font-semibold text-cyan-400">Required</span>
                ) : (
                    <span className="font-semibold text-white">{feature.points}</span>
                )}
            </td>
            <td className="p-4 text-center">
                {status === 'N/A' ? <span className="text-slate-500">N/A</span> :
                 isCompliant ? (
                    <span className="flex items-center justify-center gap-2 text-green-400"><CheckCircle className="w-6 h-6" /> Compliant</span>
                ) : (
                    <span className="flex items-center justify-center gap-2 text-red-400"><XCircle className="w-6 h-6" /> Non-compliant</span>
                )}
            </td>
        </tr>
    );
};

const WellReport: React.FC = () => {
    const [reportData, setReportData] = useState<WellComplianceReport | null>(null);
    const [wellSettings, setWellSettings] = useState<WellSettings | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [period, setPeriod] = useState<WellPeriod>('30d');
    
    const [isDrillDownOpen, setIsDrillDownOpen] = useState(false);
    const [selectedFeatureData, setSelectedFeatureData] = useState<WellDrillDownData | null>(null);
    
    const fetchData = useCallback(async () => {
        setLoading(true);
        setError(null);
        try {
            const settings = await getWellSettings();
            setWellSettings(settings);
            const data = await getWellComplianceData(period, settings);
            setReportData(data);
        } catch (err: any) {
            setError(err.message || 'Failed to generate WELL report.');
        } finally {
            setLoading(false);
        }
    }, [period]);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const summary = useMemo(() => {
        if (!reportData) return { totalPoints: 0, earnedPoints: 0, preconditionsMet: 0, totalPreconditions: 0 };
        
        let earnedPoints = 0;
        let preconditionsMet = 0;
        
        const optimizationFeatures = WELL_FEATURES.filter(f => f.type === 'Optimization');
        const preconditionFeatures = WELL_FEATURES.filter(f => f.type === 'Precondition');

        optimizationFeatures.forEach(f => {
            if (reportData[f.id]?.certification === 'Compliant') {
                earnedPoints += f.points || 0;
            }
        });
        
        preconditionFeatures.forEach(f => {
             if (reportData[f.id]?.certification === 'Compliant') {
                preconditionsMet++;
            }
        });

        return {
            totalPoints: optimizationFeatures.reduce((sum, f) => sum + (f.points || 0), 0),
            earnedPoints,
            preconditionsMet,
            totalPreconditions: preconditionFeatures.length
        };
    }, [reportData]);
    
    const handleFeatureClick = (featureId: WellFeatureId) => {
        if (!reportData) return;
        const feature = WELL_FEATURES.find(f => f.id === featureId);
        const status = reportData[featureId];
        // FIX: Safely access optional historicalData and guard against opening drill-down without data.
        if (feature && status && feature.metrics.length > 0 && status.historicalData) {
            setSelectedFeatureData({
                feature,
                status,
                historicalData: status.historicalData, // This is mock data added in apiService
            });
            setIsDrillDownOpen(true);
        }
    };

    return (
        <div className="space-y-6">
            {selectedFeatureData && (
                <WellDrillDownModal
                    isOpen={isDrillDownOpen}
                    onClose={() => setIsDrillDownOpen(false)}
                    data={selectedFeatureData}
                />
            )}
            <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                 <div>
                    <h1 className="text-3xl font-bold text-white">WELL Compliance Checker</h1>
                    <p className="text-slate-400 mt-1">Real-time compliance status based on continuous monitoring data.</p>
                </div>
                <div className="flex items-center gap-2">
                    <select value={period} onChange={e => setPeriod(e.target.value as WellPeriod)} className="bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white text-sm">
                        <option value="7d">Last 7 Days</option>
                        <option value="30d">Last 30 Days</option>
                        <option value="90d">Last 90 Days</option>
                    </select>
                    <Link to="/well-settings" className="flex items-center gap-2 px-3 py-2 text-sm rounded-md text-white bg-slate-600 hover:bg-slate-500">
                        <Settings className="w-4 h-4" /> Settings
                    </Link>
                </div>
            </div>

            {loading && <div className="flex justify-center items-center h-96"><Loader2 className="w-8 h-8 text-accent animate-spin" /> <span className="ml-3 text-lg">Analyzing Compliance Data...</span></div>}
            {error && <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error}</div>}

            {!loading && !error && reportData && (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in-scale">
                    <div className="lg:col-span-2 bg-secondary p-6 rounded-lg shadow-lg">
                        <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                           <BookOpen className="text-accent"/> Breakdown
                        </h2>
                        <div className="overflow-x-auto">
                            <table className="w-full text-left">
                                <thead className="text-xs text-slate-400 uppercase bg-slate-950/50">
                                    <tr>
                                        <th className="p-4">Feature</th>
                                        <th className="p-4 text-center">Type / Points</th>
                                        <th className="p-4 text-center">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {WELL_FEATURES.map(feature => (
                                        <FeatureRow key={feature.id} feature={feature} status={reportData[feature.id]?.certification ?? 'N/A'} onClick={() => handleFeatureClick(feature.id)} />
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div className="space-y-6">
                        <div className="bg-secondary p-6 rounded-lg shadow-lg flex flex-col items-center justify-center">
                             <h2 className="text-2xl font-bold text-white mb-4">Optimization Points</h2>
                             <div className="w-48 h-48 relative">
                                 <ResponsiveContainer width="100%" height="100%">
                                    <PieChart>
                                        <Pie data={[{name: 'Earned', value: summary.earnedPoints}, {name: 'Remaining', value: summary.totalPoints - summary.earnedPoints}]} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius="70%" outerRadius="100%" startAngle={90} endAngle={-270}>
                                            <Cell fill="#fcd34d" />
                                            <Cell fill="#334155" />
                                        </Pie>
                                    </PieChart>
                                </ResponsiveContainer>
                                <div className="absolute inset-0 flex flex-col items-center justify-center">
                                    <span className="text-5xl font-bold text-yellow-300">{summary.earnedPoints}</span>
                                    <span className="text-sm text-slate-400">Points Earned</span>
                                </div>
                             </div>
                        </div>
                        <div className="bg-secondary p-6 rounded-lg shadow-lg">
                            <h2 className="text-xl font-bold text-white mb-3">Most "Points-for-Buck"</h2>
                            <ul className="space-y-2 text-sm text-slate-300">
                                <li className="flex items-center gap-2"><ShieldCheck className="w-5 h-5 text-green-400"/><span><strong className="text-white">{summary.preconditionsMet} / {summary.totalPreconditions}</strong> preconditions met</span></li>
                                <li className="flex items-center gap-2"><Star className="w-5 h-5 text-yellow-400"/><span><strong className="text-white">{summary.earnedPoints}</strong> optimization points earned</span></li>
                                <li className="flex items-center gap-2"><Star className="w-5 h-5 text-yellow-400"/><span><strong className="text-white">+1 point more</strong> than other monitors (CO & NO2)</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default WellReport;