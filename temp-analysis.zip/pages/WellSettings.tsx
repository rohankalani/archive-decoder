import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { getWellSettings, updateWellSettings } from '../services/apiService';
import { WellSettings, OccupancyDay, Metric } from '../types';
// FIX: Imported WELL_FEATURES to resolve reference error.
import { WELL_THRESHOLDS, WELL_FEATURES } from '../utils/wellStandard';
import { Loader2, ArrowLeft, Save } from 'lucide-react';

const DayButton: React.FC<{ day: OccupancyDay, selected: boolean, onClick: () => void }> = ({ day, selected, onClick }) => (
    <button type="button" onClick={onClick} className={`w-10 h-10 rounded-full font-semibold transition-colors ${selected ? 'bg-accent text-white' : 'bg-tertiary hover:bg-slate-700'}`}>
        {day.charAt(0)}
    </button>
);

const WellSettings: React.FC = () => {
    const [settings, setSettings] = useState<WellSettings | null>(null);
    const [loading, setLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchSettings = async () => {
            try {
                setLoading(true);
                const data = await getWellSettings();
                setSettings(data);
            } catch (err) {
                setError("Failed to load settings.");
            } finally {
                setLoading(false);
            }
        };
        fetchSettings();
    }, []);

    const handleScheduleDayToggle = (day: OccupancyDay) => {
        if (!settings) return;
        setSettings(prev => ({
            ...prev!,
            schedule: {
                ...prev!.schedule,
                days: { ...prev!.schedule.days, [day]: !prev!.schedule.days[day] }
            }
        }));
    };
    
    const handleTimeChange = (field: 'startTime' | 'endTime', value: string) => {
         if (!settings) return;
         setSettings(prev => ({ ...prev!, schedule: { ...prev!.schedule, [field]: value } }));
    };
    
    const handleThresholdChange = (metric: Metric, key: string, value: string) => {
        if (!settings) return;
        const numValue = Number(value);
        if (isNaN(numValue)) return;
        
        setSettings(prev => {
            const newOverrides = { ...prev!.thresholdOverrides };
            const existing = newOverrides[metric];
            if (typeof existing === 'object' && existing !== null) {
                (newOverrides[metric] as any)[key] = numValue;
            } else {
                 newOverrides[metric] = { [key]: numValue };
            }
            return { ...prev!, thresholdOverrides: newOverrides };
        });
    };

    const handleSave = async () => {
        if (!settings) return;
        setIsSaving(true);
        try {
            await updateWellSettings(settings);
        } catch (err) {
            setError("Failed to save settings.");
        } finally {
            setIsSaving(false);
        }
    };
    
    if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>;
    if (error) return <div className="text-center py-10 text-red-400 bg-red-900/20 rounded-lg">{error}</div>;
    if (!settings) return <div className="text-center py-10 text-slate-400">Could not load settings.</div>;

    return (
        <div className="space-y-6 max-w-4xl mx-auto">
            <div>
                 <Link to="/well-report" className="flex items-center gap-2 text-slate-400 hover:text-white mb-4 transition-colors w-fit">
                    <ArrowLeft className="w-5 h-5" /> Back to WELL Dashboard
                </Link>
                <h1 className="text-3xl font-bold text-white">WELL Compliance Settings</h1>
                <p className="text-slate-400 mt-1">Configure occupancy schedules and compliance thresholds for your project.</p>
            </div>
            
            <div className="bg-secondary p-6 rounded-lg shadow-lg">
                <h2 className="text-2xl font-bold text-white mb-3">Occupancy Schedule</h2>
                <p className="text-slate-400 text-sm mb-4">Define occupied hours for accurate compliance calculations. Data points outside this schedule will be excluded.</p>
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-slate-300 mb-2">Occupied Days</label>
                        <div className="flex gap-2">
                           {(['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] as OccupancyDay[]).map(day => (
                               <DayButton key={day} day={day} selected={settings.schedule.days[day]} onClick={() => handleScheduleDayToggle(day)} />
                           ))}
                        </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                         <div>
                            <label htmlFor="start-time" className="block text-sm font-medium text-slate-300 mb-1">Start Time</label>
                            <input id="start-time" type="time" value={settings.schedule.startTime} onChange={e => handleTimeChange('startTime', e.target.value)} className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" />
                        </div>
                        <div>
                            <label htmlFor="end-time" className="block text-sm font-medium text-slate-300 mb-1">End Time</label>
                            <input id="end-time" type="time" value={settings.schedule.endTime} onChange={e => handleTimeChange('endTime', e.target.value)} className="w-full bg-tertiary border border-slate-600 rounded-md px-3 py-2 text-white" />
                        </div>
                    </div>
                </div>
            </div>
            
             <div className="bg-secondary p-6 rounded-lg shadow-lg">
                <h2 className="text-2xl font-bold text-white mb-3">Compliance Thresholds</h2>
                <p className="text-slate-400 text-sm mb-4">View and override the default WELL thresholds. Blank fields will use the standard WELL value.</p>
                <div className="space-y-4">
                    {Object.entries(WELL_THRESHOLDS).map(([key, value]) => {
                         if (Object.keys(value).length === 0) return null;
                         const feature = WELL_FEATURES.find(f => f.id === key);
                         return (
                            <div key={key} className="bg-tertiary p-4 rounded-md">
                                <h3 className="font-bold text-cyan-400">{feature?.name} ({key})</h3>
                                <div className="grid grid-cols-2 gap-4 mt-2">
                                {(Object.keys(value) as (keyof typeof value)[]).map(metricKey => {
                                    const metric = metricKey.replace('_min','').replace('_max','') as Metric;
                                    const label = metricKey.includes('_min') ? 'Min' : metricKey.includes('_max') ? 'Max' : 'Max';
                                    const currentOverride = (settings.thresholdOverrides as any)[metric];
                                    return(
                                    <div key={metricKey}>
                                        <label className="block text-sm font-medium text-slate-300 mb-1 capitalize">{metric} {label}</label>
                                        <input type="number" 
                                        placeholder={`Default: ${value[metricKey]}`}
                                        value={typeof currentOverride === 'object' ? currentOverride?.[label.toLowerCase()] ?? '' : currentOverride ?? ''}
                                        onChange={e => handleThresholdChange(metric, label.toLowerCase(), e.target.value)}
                                        className="w-full bg-slate-800 border border-slate-600 rounded-md px-3 py-2 text-white placeholder:text-slate-500"/>
                                    </div>
                                    )
                                })}
                                </div>
                            </div>
                         )
                    })}
                </div>
            </div>
            
             <div className="flex justify-end">
                <button onClick={handleSave} disabled={isSaving} className="flex items-center gap-2 px-6 py-3 rounded-md text-white bg-accent hover:bg-accent-dark disabled:bg-slate-500">
                    {isSaving ? <Loader2 className="w-5 h-5 animate-spin"/> : <Save className="w-5 h-5"/>}
                    {isSaving ? 'Saving...' : 'Save Settings'}
                </button>
            </div>
        </div>
    );
};

export default WellSettings;