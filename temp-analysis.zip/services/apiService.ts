import { 
    DeviceWithData, Location, ReportData, User, UserRole,
    WellPeriod, LeedReportData, LeedDateRange,
    RoomConfiguration, ResetReportData, GlanceTimePeriod, GlanceSummary,
    SiteDetails, AhuReportData, FilterStage, RosaiqAhsMonitor, AhuReport, MajorPollutant, AhuHistoricalPoint, Ashrae241ReportData, Ashrae241Config, FilterGrade,
    AirPurifierConfig, DeviceType, Zone, WellComplianceReport, HistoricalData, WellComplianceStatus, OccupancySchedule, WellSettings
} from '../types';
import { initialBreakpoints, AQI_POLLUTANTS } from '../contexts/SettingsContext';
import { format, add, getDaysInMonth, endOfMonth, eachDayOfInterval, isSameDay } from 'date-fns';
import subDays from 'date-fns/subDays';
import subHours from 'date-fns/subHours';
import subMonths from 'date-fns/subMonths';
import { WELL_THRESHOLDS } from '../utils/wellStandard';

// --- In-Memory Mock Database ---
let mockLocations: Location[] = [
    { id: 1, name: "Corp HQ - Floor 1", site: "Corporate HQ Bangalore", building: "Main Tower", block: "West Wing", floor: "Floor 1" },
    { id: 2, name: "Corp HQ - Floor 12", site: "Corporate HQ Bangalore", building: "Main Tower", block: "East Wing", floor: "Floor 12" },
    { id: 3, name: "Bangalore Fab - Cleanroom", site: "Factory Bangalore", building: "Fabrication Unit", block: "Cleanroom A", floor: "Floor 1" },
    { id: 4, name: "Pune Fab - Welding Bay", site: "Factory Pune", building: "Fabrication Unit", block: "Welding Bay", floor: "Floor 1" },
    { id: 5, name: "Delhi GCC - Open Office", site: "GCC Delhi", building: "Tower B", block: "Open Workspace", floor: "Floor 5" },
];

let mockDevices: DeviceWithData[] = [
    { id: 'sim-device-04', name: 'CEO Office Sensor', type: 'standard', location_id: 2, location: mockLocations[1], latest_data: null, status: 'offline' },
    { id: 'sim-device-01', name: 'Conference Room Sensor', type: 'standard', location_id: 1, location: mockLocations[0], latest_data: null, status: 'offline' },
    { id: 'sim-device-02', name: 'Cleanroom Lab Sensor', type: 'standard', location_id: 3, location: mockLocations[2], latest_data: null, status: 'offline' },
    { id: 'sim-device-03', name: 'AHU Duct Sensor', type: 'standard', location_id: 4, location: mockLocations[3], latest_data: null, status: 'offline' },
    { id: 'sim-device-21', name: 'GCC Factory Floor Sensor', type: 'standard', location_id: 5, location: mockLocations[4], latest_data: null, status: 'offline' },
    { id: 'sim-device-11', name: 'HQ Floor 1 Restroom', type: 'vape-smoke', location_id: 1, location: mockLocations[0], latest_data: null, status: 'offline' },
    { id: 'purifier-01', name: 'Conference Room Purifier', type: 'air-purifier', location_id: 1, location: mockLocations[0], latest_data: null, status: 'offline' },
    { id: 'purifier-02', name: 'CEO Office Purifier', type: 'air-purifier', location_id: 2, location: mockLocations[1], latest_data: null, status: 'offline' },
];

let mockUsers: User[] = [
    { id: '1', email: 'admin@rosaiq.com', role: 'admin', status: 'Active' },
    { id: '2', email: 'user@example.com', role: 'user', status: 'Active' },
];

let mockZones: Zone[] = [
    { id: 'zone-1', name: 'CEO Office', deviceIds: ['sim-device-04'] },
    { id: 'zone-2', name: 'Floor 1 Conference Area', deviceIds: ['sim-device-01'] },
    { id: 'zone-3', name: 'Lab Cleanroom', deviceIds: ['sim-device-02'] }
];

let mockWellSettings: WellSettings = {
    schedule: {
        days: { Sun: false, Mon: true, Tue: true, Wed: true, Thu: true, Fri: true, Sat: false },
        startTime: '09:00',
        endTime: '17:00'
    },
    thresholdOverrides: {}
};

let mockAshrae241Configs: Ashrae241Config[] = [
    { locationId: 1, floorArea: 800, ceilingHeight: 10, targetECACH: 6.0, outdoorAirflow: 150, recirculatedAirflow: 450, mervRating: 13, inRoomDevices: [{id: '1', name: 'Portable HEPA 1', cadr: 250}]},
    { locationId: 2, floorArea: 400, ceilingHeight: 10, targetECACH: 5.0, outdoorAirflow: 80, recirculatedAirflow: 200, mervRating: 13, inRoomDevices: []},
];

let mockAirPurifierConfigs: AirPurifierConfig[] = [
    { deviceId: 'purifier-01', cadr: 250, roomArea: 400, autoMode: { enabled: true, occupancyRequired: true, pm25Threshold: 12, vocThreshold: 200 } },
    { deviceId: 'purifier-02', cadr: 150, roomArea: 250, autoMode: { enabled: true, occupancyRequired: false, pm25Threshold: 10, vocThreshold: 150 } },
];

const calculateSubIndex = (metric: MajorPollutant, value: number): number => {
    const table = initialBreakpoints[metric as 'pm25' | 'voc' | 'co2']; // co2 is empty, but we'll treat it linearly
    if (metric === 'co2') {
        if (value <= 800) return 50;
        if (value <= 1000) return 100;
        return 150;
    }
    if (!table || table.length === 0) return 0;

    const breakpoint = table.find(b => value >= b[0] && value <= b[1]);
    if (!breakpoint) {
      if(value > table[table.length - 1][1]) return table[table.length - 1][3];
      return 0;
    }

    const [c_lo, c_hi, i_lo, i_hi] = breakpoint;
    if (c_hi - c_lo === 0) return i_lo;

    const aqi = ((i_hi - i_lo) / (c_hi - c_lo)) * (value - c_lo) + i_lo;
    return Math.round(aqi);
};

const generateHistoricalData = (deviceId: string, from: string, to: string, aggregation: string): any[] => {
    const data = [];
    let currentDate = new Date(from);
    while (currentDate <= new Date(to)) {
        const pointData = {
            pm25: 10 + Math.random() * 25,
            co2: 450 + Math.random() * 800,
            temp: 20 + Math.random() * 5,
            humidity: 40 + Math.random() * 25,
            voc: 50 + Math.random() * 550,
            hcho: 15 + Math.random() * 20,
            nox: 20 + Math.random() * 30,
            pm03: 8 + Math.random() * 20,
            pm1: 9 + Math.random() * 22,
            pm5: 12 + Math.random() * 28,
            pm10: 15 + Math.random() * 30,
            pc03: 32000 + Math.random() * 10000,
            pc05: 9000 + Math.random() * 5000,
            pc1: 1500 + Math.random() * 1000,
            pc25: 300 + Math.random() * 200,
            pc5: 80 + Math.random() * 50,
            pc10: 25 + Math.random() * 20,
        };
        const iaqiValues = AQI_POLLUTANTS.map(p => calculateSubIndex(p as any, (pointData as any)[p]));
        const iaqi = Math.max(...iaqiValues, 0);
        data.push({ timestamp: currentDate.toISOString(), iaqi, ...pointData });

        if (aggregation === '1d') currentDate.setDate(currentDate.getDate() + 1);
        else if (aggregation === '8h') currentDate.setHours(currentDate.getHours() + 8);
        else currentDate.setHours(currentDate.getHours() + 1);
    }
    return data;
};

// --- Mock API Implementation ---
const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

export const getDevices = async (): Promise<DeviceWithData[]> => { await delay(200); return JSON.parse(JSON.stringify(mockDevices)); };
export const getDevice = async (id: string): Promise<DeviceWithData> => { await delay(200); const device = mockDevices.find(d => d.id === id); if (device) return JSON.parse(JSON.stringify(device)); throw new Error("Device not found"); };
export const addDevice = async (name: string, location_id: number, type: DeviceType = 'standard'): Promise<DeviceWithData> => {
    await delay(300);
    const location = mockLocations.find(l => l.id === location_id);
    if (!location) throw new Error("Location not found");
    const newDevice: DeviceWithData = { id: `dev-${Date.now()}`, name, type, location_id, location, latest_data: null, status: 'offline' };
    mockDevices.push(newDevice);
    return newDevice;
};
export const updateDevice = async (id: string, name: string, location_id: number): Promise<DeviceWithData> => {
    await delay(300);
    const deviceIndex = mockDevices.findIndex(d => d.id === id);
    if (deviceIndex === -1) throw new Error("Device not found");
    const location = mockLocations.find(l => l.id === location_id);
    if (!location) throw new Error("Location not found");
    mockDevices[deviceIndex] = { ...mockDevices[deviceIndex], name, location_id, location };
    return mockDevices[deviceIndex];
};
export const deleteDevice = async (id: string): Promise<void> => { await delay(300); mockDevices = mockDevices.filter(d => d.id !== id); };
export const getHistoricalData = async (deviceId: string, from: string, to: string, aggregation: string): Promise<any[]> => { await delay(500); return generateHistoricalData(deviceId, from, to, aggregation); };
export const getLocations = async (): Promise<Location[]> => { await delay(100); return JSON.parse(JSON.stringify(mockLocations)); };
export const addLocation = async (name: string, site: string, building: string, block: string, floor: string): Promise<Location> => {
    await delay(300);
    const newLocation: Location = { id: Date.now(), name, site, building, block, floor };
    mockLocations.push(newLocation);
    return newLocation;
};
export const deleteLocation = async (id: number): Promise<void> => { await delay(300); mockDevices = mockDevices.filter(d => d.location_id !== id); mockLocations = mockLocations.filter(l => l.id !== id); };
export const getUsers = async (): Promise<User[]> => { await delay(300); return JSON.parse(JSON.stringify(mockUsers)); };
export const inviteUser = async (email: string, role: UserRole): Promise<User> => {
    await delay(500);
    const newUser: User = { id: String(Date.now()), email, role, status: 'Pending' };
    mockUsers.push(newUser);
    return newUser;
};
export const deleteUser = async (id: string): Promise<void> => { await delay(300); mockUsers = mockUsers.filter(u => u.id !== id); };
export const getRoomConfigurations = async (): Promise<RoomConfiguration[]> => { await delay(100); return []; };
export const updateRoomConfiguration = async (config: RoomConfiguration): Promise<RoomConfiguration> => { await delay(300); return config; };

// --- Zone Management API ---
export const getZones = async (): Promise<Zone[]> => { await delay(150); return JSON.parse(JSON.stringify(mockZones)); };
export const addZone = async (name: string, deviceIds: string[]): Promise<Zone> => {
    await delay(300);
    const newZone: Zone = { id: `zone-${Date.now()}`, name, deviceIds };
    mockZones.push(newZone);
    return newZone;
};
export const updateZone = async (id: string, name: string, deviceIds: string[]): Promise<Zone> => {
    await delay(300);
    const zoneIndex = mockZones.findIndex(z => z.id === id);
    if (zoneIndex === -1) throw new Error("Zone not found");
    mockZones[zoneIndex] = { ...mockZones[zoneIndex], name, deviceIds };
    return mockZones[zoneIndex];
};
export const deleteZone = async (id: string): Promise<void> => {
    await delay(300);
    mockZones = mockZones.filter(z => z.id !== id);
};


// --- Air Purifier Config API ---
export const getAirPurifierConfigs = async (): Promise<AirPurifierConfig[]> => {
    await delay(100);
    return JSON.parse(JSON.stringify(mockAirPurifierConfigs));
};
export const updateAirPurifierConfig = async (config: AirPurifierConfig): Promise<AirPurifierConfig> => {
    await delay(300);
    const index = mockAirPurifierConfigs.findIndex(c => c.deviceId === config.deviceId);
    if (index > -1) {
        mockAirPurifierConfigs[index] = config;
    } else {
        mockAirPurifierConfigs.push(config);
    }
    return config;
};

// --- Advanced Mocks ---
const SITES = ["Corporate HQ Bangalore", "Factory Bangalore", "Factory Pune", "GCC Delhi"];
const BUILDINGS_PER_SITE = 2;

const generateTrendData = (days: number, isMonthly: boolean, valueFn: (day: number) => number) => {
    const trend = [];
    const now = new Date();
    for (let i = 0; i < days; i++) {
        const date = isMonthly ? subMonths(now, i) : subDays(now, i);
        trend.push({ time: date.toISOString(), value: valueFn(i) });
    }
    return trend.reverse();
};

const generatePollutantTrends = (days: number, isMonthly: boolean) => ({
    pm25: generateTrendData(days, isMonthly, (i) => 10 + Math.random() * 15 + i * 0.1),
    co2: generateTrendData(days, isMonthly, (i) => 450 + Math.random() * 100 + i * 2),
    voc: generateTrendData(days, isMonthly, (i) => 60 + Math.random() * 40 + i * 1),
});

export const getGlanceSummaries = async (period: GlanceTimePeriod): Promise<GlanceSummary[]> => {
    await delay(400);
    const isMonthly = period === '12m';
    const days = isMonthly ? 12 : 30;
    return SITES.map((site, i) => ({
        name: site, level: 'site', totalCount: 5 + i, onlineCount: 4 + i,
        trend: generateTrendData(days, isMonthly, (d) => 30 + Math.random() * 25 + d * 0.2).map(t => ({ time: t.time, aqi: t.value })),
    }));
};
export const getSiteDetails = async (siteName: string, period: GlanceTimePeriod): Promise<SiteDetails> => {
    await delay(600);
    const isMonthly = period === '12m';
    const days = isMonthly ? 12 : 30;
    const buildingSummaries = Array.from({ length: BUILDINGS_PER_SITE }, (_, i) => {
        const buildingName = `${siteName.split(' ')[0]} Building ${String.fromCharCode(65 + i)}`;
        return {
            name: buildingName, level: 'building' as const, totalCount: 3, onlineCount: 3,
            trend: generateTrendData(days, isMonthly, (d) => 25 + Math.random() * 20).map(t => ({ time: t.time, aqi: t.value })),
            pollutantTrends: generatePollutantTrends(days, isMonthly),
        };
    });
    return { siteName, pollutantTrends: generatePollutantTrends(days, isMonthly), buildingSummaries };
};
export const getWeeklyReportData = async (): Promise<ReportData> => {
    await delay(800);
    return {
        summary: { overallAqi: 45, worstLocation: { name: "Factory Pune", aqi: 68 }, bestLocation: { name: "Corporate HQ", aqi: 32 } },
        dailyAqiTrend: Array.from({ length: 7 }, (_, i) => ({ date: subDays(new Date(), 6 - i).toISOString(), averageAqi: 30 + Math.random() * 25 })),
        locationHotspots: {
            byAqi: [{ locationName: 'Factory Pune', averageAqi: 68 }, { locationName: 'Factory Bangalore', averageAqi: 55 }],
            byAlerts: [{ locationName: 'Factory Pune', alertCount: 5 }, { locationName: 'GCC Delhi', alertCount: 2 }],
        },
        alertAnalysis: { total: 8, byType: { 'threshold-exceeded': 5, 'device-offline': 3 } },
        pollutantBreakdown: { pm25: 12.5, co2: 650, voc: 180, hcho: 40 },
    };
};
export const getLeedReportData = async (building: string, floor: string, range: LeedDateRange): Promise<LeedReportData> => {
    await delay(1000);
    const days = range === '24h' ? 1 : (range === '7d' ? 7 : 30);
    const generateTrend = () => Array.from({ length: 24 }, (_, i) => ({ timestamp: subHours(new Date(), 23 - i).toISOString(), value: 10 + Math.random() * 10 }));
    return {
        location: { building, floor },
        period: { from: subDays(new Date(), days).toISOString(), to: new Date().toISOString() },
        isOverallCompliant: true,
        metrics: {
            pm25: { isCompliant: true, threshold: 12, unit: 'µg/m³', peak: 11.5, average: 8.2, trend: generateTrend() },
            co2: { isCompliant: true, threshold: 900, unit: 'ppm', peak: 850, average: 650, trend: generateTrend().map(t => ({ ...t, value: t.value * 40 + 450 })) },
            voc: { isCompliant: false, threshold: 500, unit: 'µg/m³', peak: 580, average: 480, trend: generateTrend().map(t => ({ ...t, value: t.value * 25 + 300 })) },
            hcho: { isCompliant: true, threshold: 27, unit: 'ppb', peak: 25, average: 18, trend: generateTrend() },
        }
    };
};
export const getResetReportData = async (from: Date, to: Date): Promise<ResetReportData> => {
    await delay(1200);
    const days = eachDayOfInterval({ start: from, end: to });
    const dailyBreakdown = days.map(day => {
        const isCompliant = Math.random() > 0.1;
        return {
            date: day.toISOString(),
            isCompliant,
            metrics: {
                pm25: { value: 10 + Math.random() * 10, isCompliant: isCompliant || Math.random() > 0.1 },
                voc: { value: 400 + Math.random() * 200, isCompliant: isCompliant || Math.random() > 0.1 },
                co2: { value: 600 + Math.random() * 300, isCompliant: isCompliant || Math.random() > 0.1 },
            }
        };
    });
    const compliantDays = dailyBreakdown.filter(d => d.isCompliant).length;
    return {
        overallCompliance: { totalDays: days.length, compliantDays, percentage: (compliantDays / days.length) * 100 },
        dailyBreakdown,
        metricSummaries: {
            pm25: { periodAverage: 12.5, peakDailyAverage: 22.1, daysExceeded: 5, dailyAverages: dailyBreakdown.map(d => ({ date: d.date, value: d.metrics.pm25.value })) },
            voc: { periodAverage: 480, peakDailyAverage: 550, daysExceeded: 8, dailyAverages: dailyBreakdown.map(d => ({ date: d.date, value: d.metrics.voc.value })) },
            co2: { periodAverage: 750, peakDailyAverage: 950, daysExceeded: 3, dailyAverages: dailyBreakdown.map(d => ({ date: d.date, value: d.metrics.co2.value })) },
        }
    };
};

// --- WELL Settings API ---
export const getWellSettings = async (): Promise<WellSettings> => {
    await delay(200);
    return JSON.parse(JSON.stringify(mockWellSettings));
};
export const updateWellSettings = async (settings: WellSettings): Promise<WellSettings> => {
    await delay(400);
    mockWellSettings = JSON.parse(JSON.stringify(settings));
    return mockWellSettings;
}

// --- WELL Compliance Checker ---
const checkCompliance = (data: HistoricalData[], checks: Record<string, any>, schedule: OccupancySchedule): { compliantPoints: number, totalPoints: number } => {
    if (data.length === 0) return { compliantPoints: 0, totalPoints: 0 };
    
    const dayMap = { 0: 'Sun', 1: 'Mon', 2: 'Tue', 3: 'Wed', 4: 'Thu', 5: 'Fri', 6: 'Sat' };
    const [startHour, startMin] = schedule.startTime.split(':').map(Number);
    const [endHour, endMin] = schedule.endTime.split(':').map(Number);

    const occupiedData = data.filter(point => {
        const d = new Date(point.timestamp);
        const dayOfWeek = dayMap[d.getUTCDay() as keyof typeof dayMap];
        if (!schedule.days[dayOfWeek]) return false;

        const hour = d.getUTCHours();
        const min = d.getUTCMinutes();

        if (hour > startHour && hour < endHour) return true;
        if (hour === startHour && min >= startMin) return true;
        if (hour === endHour && min < endMin) return true;

        return false;
    });

    if (occupiedData.length === 0) return { compliantPoints: 0, totalPoints: 0 };

    let compliantPoints = 0;
    occupiedData.forEach(point => {
        let isPointCompliant = true;
        for (const metric in checks) {
            if (metric.includes('_min')) {
                const realMetric = metric.replace('_min', '') as keyof HistoricalData;
                const value = point[realMetric] as number;
                if (value === undefined || value === null || value < checks[metric]) { isPointCompliant = false; break; }
            } else if (metric.includes('_max')) {
                const realMetric = metric.replace('_max', '') as keyof HistoricalData;
                const value = point[realMetric] as number;
                if (value === undefined || value === null || value > checks[metric]) { isPointCompliant = false; break; }
            } else {
                const value = point[metric as keyof HistoricalData] as number;
                if (value === undefined || value === null || value > checks[metric]) { isPointCompliant = false; break; }
            }
        }
        if (isPointCompliant) compliantPoints++;
    });

    return { compliantPoints, totalPoints: occupiedData.length };
};


export const getWellComplianceData = async (period: WellPeriod, settings: WellSettings): Promise<WellComplianceReport> => {
    await delay(1000);
    const days = parseInt(period.replace('d', ''));
    const from = subDays(new Date(), days).toISOString();
    const to = new Date().toISOString();
    const historicalData = generateHistoricalData('sim-device-01', from, to, '1h');
    const thresholds = { ...WELL_THRESHOLDS, ...settings.thresholdOverrides };

    const report: Partial<WellComplianceReport> = {};

    for (const key in WELL_THRESHOLDS) {
        const featureId = key as keyof typeof WELL_THRESHOLDS;
        const featureThresholds = thresholds[featureId];
        
        // A08 is special case - based on having monitors, not thresholds
        if(featureId === 'A08' || featureId === 'T06') {
             report[featureId] = {
                certification: 'Compliant', recertification: 'Compliant',
                compliantPoints: 1, totalPoints: 1, compliancePercentage: 100, thresholds: {}
            };
            continue;
        }

        const { compliantPoints, totalPoints } = checkCompliance(historicalData, featureThresholds, settings.schedule);
        const compliancePercentage = totalPoints > 0 ? (compliantPoints / totalPoints) * 100 : 0;
        const isCompliant = compliancePercentage >= 90;

        report[featureId] = {
            certification: totalPoints > 0 ? (isCompliant ? 'Compliant' : 'Non-compliant') : 'N/A',
            recertification: totalPoints > 0 ? (isCompliant ? 'Compliant' : 'Non-compliant') : 'N/A',
            compliantPoints,
            totalPoints,
            compliancePercentage,
            thresholds: featureThresholds,
            // Add raw data for drill-down
            // In a real app, you might fetch this only when needed
            historicalData: historicalData,
        };
    }

    return report as WellComplianceReport;
};


// --- ASHRAE 241 ---
const MERV_EFFICIENCY: Record<number, number> = { 8: 0.20, 13: 0.85, 14: 0.90, 16: 0.95 };
export const getAshrae241Configs = async (): Promise<Ashrae241Config[]> => { await delay(100); return JSON.parse(JSON.stringify(mockAshrae241Configs)) };
export const updateAshrae241Config = async (config: Ashrae241Config): Promise<Ashrae241Config> => {
    await delay(300);
    const index = mockAshrae241Configs.findIndex(c => c.locationId === config.locationId);
    if (index > -1) {
        mockAshrae241Configs[index] = config;
    } else {
        mockAshrae241Configs.push(config);
    }
    return config;
};

export const getAshrae241ReportData = async (): Promise<Ashrae241ReportData> => {
    await delay(500);
    return mockLocations.map(loc => {
        const config = mockAshrae241Configs.find(c => c.locationId === loc.id);
        if (!config || !config.floorArea || !config.ceilingHeight || !config.outdoorAirflow || !config.recirculatedAirflow || !config.mervRating) {
             return {
                locationId: loc.id, locationName: loc.name, isCompliant: false, infectionRisk: 'Not Configured',
                equivalentCleanAirflow: { current: 0, target: 5, unit: 'eCACH' },
                contribution: { outdoorAir: 0, filtration: 0, inRoomCleaning: 0 }
            };
        }
        
        const zoneVolume = config.floorArea * config.ceilingHeight;
        if (zoneVolume === 0) {
            // Avoid division by zero
            return {
                locationId: loc.id, locationName: loc.name, isCompliant: false, infectionRisk: 'Not Configured',
                equivalentCleanAirflow: { current: 0, target: config.targetECACH, unit: 'eCACH' },
                contribution: { outdoorAir: 0, filtration: 0, inRoomCleaning: 0 }
            };
        }

        const outdoorAirCFM = config.outdoorAirflow;
        const filtrationCFM = config.recirculatedAirflow * (MERV_EFFICIENCY[config.mervRating] || 0);
        const inRoomCFM = config.inRoomDevices.reduce((sum, dev) => sum + dev.cadr, 0);

        const outdoorAirECACH = (outdoorAirCFM / zoneVolume) * 60;
        const filtrationECACH = (filtrationCFM / zoneVolume) * 60;
        const inRoomECACH = (inRoomCFM / zoneVolume) * 60;

        const currentECACH = outdoorAirECACH + filtrationECACH + inRoomECACH;
        const isCompliant = currentECACH >= config.targetECACH;

        let infectionRisk: 'Low' | 'Moderate' | 'High' = 'Low';
        if (!isCompliant) {
            infectionRisk = currentECACH > config.targetECACH * 0.7 ? 'Moderate' : 'High';
        }

        return {
            locationId: loc.id,
            locationName: loc.name,
            isCompliant,
            infectionRisk,
            equivalentCleanAirflow: {
                current: parseFloat(currentECACH.toFixed(1)),
                target: config.targetECACH,
                unit: 'eCACH',
            },
            contribution: {
                outdoorAir: parseFloat(outdoorAirECACH.toFixed(1)),
                filtration: parseFloat(filtrationECACH.toFixed(1)),
                inRoomCleaning: parseFloat(inRoomECACH.toFixed(1)),
            },
        };
    });
};

const MERV_TO_PM1_EFFICIENCY: Record<FilterGrade, { initial: number, final: number }> = {
    'MERV 8': { initial: 25, final: 15 },
    'MERV 13': { initial: 88, final: 80 },
    'F7': { initial: 92, final: 85 },
    'F8': { initial: 96, final: 90 },
    'HEPA 13': { initial: 99.97, final: 99.9 },
    'Custom': { initial: 50, final: 40 },
};

const generateAhuHistoricalData = (ahu: AhuReport): AhuHistoricalPoint[] => {
    const data: AhuHistoricalPoint[] = [];
    const days = 365;

    let stageStates = ahu.filterStages.map(stage => {
        const effRange = MERV_TO_PM1_EFFICIENCY[stage.grade] || MERV_TO_PM1_EFFICIENCY['Custom'];
        return {
            currentDp: stage.initialDp,
            daysInUse: 0,
            dailyDpIncrease: stage.lifespanDays > 0 ? (250 - stage.initialDp) / stage.lifespanDays : 0,
            currentEfficiency: effRange.initial,
        };
    });
    
    let standardStageStates = ahu.filterStages.map(stage => ({
        currentDp: stage.standardFilterInitialDp,
        daysInUse: 0,
        dailyDpIncrease: stage.standardFilterLifespanDays > 0 ? (stage.standardFilterFinalDp - stage.standardFilterInitialDp) / stage.standardFilterLifespanDays : 0,
    }));

    for (let i = 0; i < days; i++) {
        const timestamp = subDays(new Date(), days - 1 - i).toISOString();

        // Update Advanced Filters
        stageStates = stageStates.map((state, index) => {
            const stage = ahu.filterStages[index];
            if (stage.lifespanDays > 0 && state.daysInUse >= stage.lifespanDays) {
                return { ...state, currentDp: stage.initialDp, daysInUse: 1 };
            }
            return { ...state, currentDp: state.currentDp + state.dailyDpIncrease, daysInUse: state.daysInUse + 1 };
        });

        // Update efficiency based on the new state
        stageStates.forEach((state, index) => {
            const stage = ahu.filterStages[index];
            const effRange = MERV_TO_PM1_EFFICIENCY[stage.grade] || MERV_TO_PM1_EFFICIENCY['Custom'];
            const lifeConsumed = stage.lifespanDays > 0 ? Math.min(state.daysInUse / stage.lifespanDays, 1) : 1;
            state.currentEfficiency = effRange.initial - (effRange.initial - effRange.final) * lifeConsumed;
        });
        
        // Update Standard Filters
        standardStageStates = standardStageStates.map((state, index) => {
            const stage = ahu.filterStages[index];
            if (stage.standardFilterLifespanDays > 0 && state.daysInUse >= stage.standardFilterLifespanDays) {
                return { ...state, currentDp: stage.standardFilterInitialDp, daysInUse: 1 };
            }
            return { ...state, currentDp: state.currentDp + state.dailyDpIncrease, daysInUse: state.daysInUse + 1 };
        });

        const totalDifferentialPressure = stageStates.reduce((sum, s) => sum + s.currentDp, 0);
        // Calculate overall efficiency: E_total = 1 - (1 - E1/100) * (1 - E2/100)
        const totalParticleEfficiency = 100 * (1 - stageStates.reduce((product, s) => product * (1 - s.currentEfficiency / 100), 1));

        data.push({
            timestamp,
            totalDifferentialPressure,
            particleEfficiency: totalParticleEfficiency,
            stageData: stageStates.map(s => ({ dp: s.currentDp, efficiency: s.currentEfficiency })),
            standardStageData: standardStageStates.map(s => ({ dp: s.currentDp })),
        });
    }
    return data;
};

let mockAhuData: AhuReport[] = [
    {
        id: 'ahu-01', name: 'Rooftop Unit 1 (RTU-1)', totalDpChangeThreshold: 300, airflowRate: 15000, fanEfficiency: 70,
        rosaiqMonitor: { id: 'rosaiq-mon-01', targetParticleSize: 'pm1' },
        filterStages: [
            { id: 'stg-01', name: 'Pre-Filter', type: 'Panel', grade: 'MERV 8', initialDp: 22.5, cost: 40, lifespanDays: 180, standardFilterInitialDp: 45, standardFilterFinalDp: 180, standardFilterLifespanDays: 90, standardFilterCost: 25 },
            { id: 'stg-02', name: 'Final Filter', type: 'V-Cell', grade: 'MERV 13', initialDp: 45, cost: 180, lifespanDays: 400, standardFilterInitialDp: 90, standardFilterFinalDp: 250, standardFilterLifespanDays: 210, standardFilterCost: 110 },
        ],
        historicalData: []
    },
    {
        id: 'ahu-02', name: 'Factory Floor AHU', totalDpChangeThreshold: 400, airflowRate: 25000, fanEfficiency: 75,
        rosaiqMonitor: { id: 'rosaiq-mon-02', targetParticleSize: 'pm25' },
        filterStages: [
            { id: 'stg-f-01', name: 'Pre-Filter', type: 'Bag', grade: 'F7', initialDp: 30, cost: 80, lifespanDays: 120, standardFilterInitialDp: 50, standardFilterFinalDp: 200, standardFilterLifespanDays: 75, standardFilterCost: 50 },
            { id: 'stg-f-02', name: 'Final Filter', type: 'V-Cell', grade: 'F8', initialDp: 55, cost: 250, lifespanDays: 365, standardFilterInitialDp: 100, standardFilterFinalDp: 300, standardFilterLifespanDays: 180, standardFilterCost: 150 },
        ],
        historicalData: []
    }
];
mockAhuData[0].historicalData = generateAhuHistoricalData(mockAhuData[0]);
mockAhuData[1].historicalData = generateAhuHistoricalData(mockAhuData[1]);

export const getAhuFilterReportData = async (): Promise<AhuReportData> => { await delay(500); return JSON.parse(JSON.stringify(mockAhuData)); };
export const getAhuReportById = async (id: string): Promise<AhuReport | undefined> => {
    await delay(300);
    return JSON.parse(JSON.stringify(mockAhuData.find(ahu => ahu.id === id)));
}

export const addAhu = async (name: string, totalDpChangeThreshold: number, airflowRate: number, fanEfficiency: number, filterStages: FilterStage[], rosaiqMonitor: RosaiqAhsMonitor): Promise<AhuReport> => {
    await delay(300);
    const newAhu: AhuReport = { id: `ahu-${Date.now()}`, name, totalDpChangeThreshold, airflowRate, fanEfficiency, filterStages, rosaiqMonitor, historicalData: [] };
    newAhu.historicalData = generateAhuHistoricalData(newAhu);
    mockAhuData.push(newAhu);
    return newAhu;
};
export const updateAhu = async (id: string, name: string, totalDpChangeThreshold: number, airflowRate: number, fanEfficiency: number, filterStages: FilterStage[], rosaiqMonitor: RosaiqAhsMonitor): Promise<AhuReport> => {
    await delay(300);
    const ahuIndex = mockAhuData.findIndex(a => a.id === id);
    if (ahuIndex === -1) throw new Error("AHU not found");
    const updatedAhu = { ...mockAhuData[ahuIndex], name, totalDpChangeThreshold, airflowRate, fanEfficiency, filterStages, rosaiqMonitor };
    updatedAhu.historicalData = generateAhuHistoricalData(updatedAhu);
    mockAhuData[ahuIndex] = updatedAhu;
    return updatedAhu;
};
export const deleteAhu = async (id: string): Promise<void> => { await delay(300); mockAhuData = mockAhuData.filter(a => a.id !== id); };