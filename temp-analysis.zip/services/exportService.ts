import { utils, writeFile } from 'xlsx';
// FIX: Corrected import path for types.
import { HistoricalData, Metric, UnitSystem } from '../types';
import { useSettings } from '../contexts/SettingsContext';

type GetQualityFn = ReturnType<typeof useSettings>['getMetricQuality'];
type ConvertValueFn = ReturnType<typeof useSettings>['convertValue'];

const qualityFills = {
    'Good': { fgColor: { rgb: "C6EFCE" }, bgColor: { rgb: "006100" } },
    'Comfort': { fgColor: { rgb: "C6EFCE" }, bgColor: { rgb: "006100" } },
    'Ideal': { fgColor: { rgb: "C6EFCE" }, bgColor: { rgb: "006100" } },
    'Moderate': { fgColor: { rgb: "FFEB9C" }, bgColor: { rgb: "9C6500" } },
    'Warm': { fgColor: { rgb: "FFEB9C" }, bgColor: { rgb: "9C6500" } },
    'Dry': { fgColor: { rgb: "FFEB9C" }, bgColor: { rgb: "9C6500" } },
    'Unhealthy for Sensitive Groups': { fgColor: { rgb: "FF7F0E" }, bgColor: { rgb: "9C5700" } }, // Orange
    'Unhealthy': { fgColor: { rgb: "FFC7CE" }, bgColor: { rgb: "9C0006" } },
    'Very Unhealthy': { fgColor: { rgb: "DDA0DD" }, bgColor: { rgb: "7030A0" } }, // Purple
    'Hazardous': { fgColor: { rgb: "C00000" }, bgColor: { rgb: "703000" } }, // Maroon
    'Hot': { fgColor: { rgb: "FFC7CE" }, bgColor: { rgb: "9C0006" } },
    'Very Dry': { fgColor: { rgb: "FFC7CE" }, bgColor: { rgb: "9C0006" } },
    'Very Hot': { fgColor: { rgb: "D32F2F" }, bgColor: { rgb: "FFFFFF" } },
    'Humid': { fgColor: { rgb: "D32F2F" }, bgColor: { rgb: "FFFFFF" } },
    'Cold': { fgColor: { rgb: "B3E5FC" }, bgColor: { rgb: "01579B" } },
    'N/A': {}, // Default no-fill
};

const metricOrder: Metric[] = [ 'iaqi', 'pm25', 'co2', 'temp', 'humidity', 'voc', 'hcho', 'nox', 'pm03', 'pm1', 'pm5', 'pm10', 'pc03', 'pc05', 'pc1', 'pc25', 'pc5', 'pc10' ];

export const exportToExcel = async (
    deviceName: string, 
    data: HistoricalData[], 
    getMetricQuality: GetQualityFn,
    unitSystem: UnitSystem,
    convertValue: ConvertValueFn
) => {
    if (!data.length) {
        alert("No data available to export.");
        return;
    }
    
    const pcUnit = unitSystem === 'metric' ? '(#/m³)' : '(#/ft³)';
    const headers = ['Timestamp', ...metricOrder.map(h => h.startsWith('pc') ? `${h.toUpperCase()} ${pcUnit}` : h.toUpperCase())];
    
    const workbook = utils.book_new();
    const worksheet = utils.json_to_sheet([]);
    utils.sheet_add_aoa(worksheet, [headers], { origin: 'A1' });

    data.forEach((row, rowIndex) => {
        const rowData: (Date | number | null)[] = [new Date(row.timestamp)];
        metricOrder.forEach((metric, colIndex) => {
            const rawValue = row[metric as keyof HistoricalData] as number;
            
            if (rawValue === undefined || rawValue === null) {
                rowData.push(null);
                return;
            }

            const displayValue = convertValue(metric, rawValue);
            rowData.push(displayValue);
            
            // Coloring is based on the raw value
            const quality = getMetricQuality(metric, rawValue);
            const qualityKey = quality.label as keyof typeof qualityFills;
            const fill = qualityFills[qualityKey];
            
            if (fill) {
                const cellAddress = utils.encode_cell({ r: rowIndex + 1, c: colIndex + 1 });
                if (!worksheet[cellAddress]) worksheet[cellAddress] = { t: 'n', v: displayValue };
                worksheet[cellAddress].s = { fill: { patternType: "solid", ...fill } };
            }
        });
        // FIX: Replaced sheet_add_json with sheet_add_aoa for appending rows, resolving the 'invalid skipHeader' issue.
        utils.sheet_add_aoa(worksheet, [rowData], { origin: -1 });
    });
    
    const colWidths = headers.map(h => ({ wch: h.length + 5 }));
    worksheet['!cols'] = colWidths;

    utils.book_append_sheet(workbook, worksheet, 'Device Data');
    
    const fileName = `${deviceName}_Export_${new Date().toISOString().split('T')[0]}.xlsx`;
    writeFile(workbook, fileName);
};
