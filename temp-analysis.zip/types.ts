// --- Base Metric & Data Types ---
export type Metric =
  | 'iaqi' | 'pm25' | 'co2' | 'temp' | 'humidity' | 'voc' | 'hcho' | 'nox'
  | 'pm03' | 'pm1' | 'pm5' | 'pm10' | 'pc03' | 'pc05' | 'pc1' | 'pc25' | 'pc5' | 'pc10'
  | 'occupancy' | 'dp' | 'presence' | 'smoke_vape_detected' | 'battery'
  | 'fan_speed' | 'filter_life';

export type PurifierMode = 'auto' | 'manual' | 'off';

export type RealtimeData = {
  deviceId: string;
  timestamp: string;
  iaqi?: number;
  pm25?: number;
  co2?: number;
  temp?: number;
  humidity?: number;
  voc?: number;
  hcho?: number;
  nox?: number;
  pm03?: number;
  pm1?: number;
  pm5?: number;
  pm10?: number;
  pc03?: number;
  pc05?: number;
  pc1?: number;
  pc25?: number;
  pc5?: number;
  pc10?: number;
  occupancy?: number;
  dp?: number;
  presence?: 0 | 1;
  smoke_vape_detected?: 0 | 1;
  battery?: number;
  // Air Purifier Specific
  mode?: PurifierMode;
  fan_speed?: number; // 0-100%
  filter_life?: number; // 0-100%
};

export type HistoricalData = {
  timestamp: string;
} & Partial<Record<Metric, number>>;

// --- Device & Location Types ---
export interface Location {
  id: number;
  name: string;
  site: string;
  building: string;
  block: string;
  floor: string;
}

export type DeviceType = 'standard' | 'vape-smoke' | 'air-purifier';

export interface Device {
  id: string;
  name: string;
  location_id: number;
  location: Location;
  type: DeviceType;
}

export interface DeviceWithData extends Device {
  latest_data: RealtimeData | null;
  status: 'online' | 'offline';
  historical_snippet?: HistoricalData[];
}

export interface DevicePosition {
    x: number;
    y: number;
}

// --- NEW: Zone Management Types ---
export interface Zone {
  id: string;
  name: string;
  deviceIds: string[];
}

export interface ZoneWithData extends Zone {
  devices: DeviceWithData[];
  aggregated_data: RealtimeData | null;
  status: 'online' | 'offline' | 'mixed';
}


// --- Settings & AQI Types ---
export type UnitSystem = 'metric' | 'imperial';
export type AqiLevel = 'Good' | 'Moderate' | 'Unhealthy for Sensitive Groups' | 'Unhealthy' | 'Very Unhealthy' | 'Hazardous';

export interface Thresholds {
  good: number;
  moderate: number;
  poor: number;
}

// [Concentration Low, Concentration High, AQI Low, AQI High]
export type Breakpoint = [number, number, number, number];
export type BreakpointTable = Breakpoint[];

// --- Alerting ---
export type AlertSeverity = 'critical' | 'warning' | 'info';
export type AlertStatus = 'active' | 'resolved';
export type AlertType = 'device-offline' | 'low-battery' | 'threshold-exceeded' | 'vape-detected' | 'smoke-detected' | 'smoke-vape-detected' | 'wildfire-risk';

export interface Alert {
  id: string;
  type: AlertType;
  severity: AlertSeverity;
  status: AlertStatus;
  title: string;
  description: string;
  deviceId: string;
  deviceName: string;
  locationName: string;
  timestamp: string;
  resolvedTimestamp?: string;
}

// --- User Management ---
export type UserRole = 'admin' | 'user';
export interface User {
  id: string;
  email: string;
  role: UserRole;
  status: 'Active' | 'Pending';
}

// --- Reporting ---
export type ChartAggregation = '1h' | '8h' | '1d';

export interface ReportData {
  summary: {
    overallAqi: number;
    worstLocation: { name: string; aqi: number };
    bestLocation: { name: string; aqi: number };
  };
  dailyAqiTrend: { date: string; averageAqi: number }[];
  locationHotspots: {
    byAqi: { locationName: string; averageAqi: number }[];
    byAlerts: { locationName: string; alertCount: number }[];
  };
  alertAnalysis: {
    total: number;
    byType: Partial<Record<AlertType, number>>;
  };
  pollutantBreakdown: Partial<Record<Metric, number>>;
}

// --- ASHRAE 62.1 Report ---
export type AshraeSpaceType = 'Not Set' | 'Office' | 'Conference/Meeting Room' | 'Classroom' | 'Library' | 'Auditorium' | 'Retail';
export interface RoomConfiguration {
    locationId: number;
    spaceType: AshraeSpaceType;
    floorArea: number | null;
    maxOccupancy: number | null;
}

// --- ASHRAE 241 Report ---
export interface InRoomDevice {
    id: string;
    name: string;
    cadr: number; // Clean Air Delivery Rate in CFM
}

export interface Ashrae241Config {
    locationId: number;
    floorArea: number | null;
    ceilingHeight: number | null;
    targetECACH: number;
    outdoorAirflow: number | null; // CFM
    recirculatedAirflow: number | null; // CFM
    mervRating: number | null; // e.g., 8, 13, 16
    inRoomDevices: InRoomDevice[];
}

export interface Ashrae241ZoneData {
    locationId: number;
    locationName: string;
    isCompliant: boolean;
    infectionRisk: 'Low' | 'Moderate' | 'High' | 'Not Configured';
    equivalentCleanAirflow: {
        current: number; // eCACH
        target: number;
        unit: string;
    };
    contribution: {
        outdoorAir: number;
        filtration: number;
        inRoomCleaning: number;
    };
}
export type Ashrae241ReportData = Ashrae241ZoneData[];


// --- WELL Report ---
export type WellPeriod = '7d' | '30d' | '90d';
export type WellComplianceState = 'Compliant' | 'Non-compliant' | 'N/A';
export type WellFeatureId = 'A01' | 'A03' | 'A05' | 'A06' | 'A08' | 'T01' | 'T06' | 'T07';

export interface WellFeature {
    id: WellFeatureId;
    name: string;
    type: 'Precondition' | 'Optimization';
    points?: number;
    description: string;
    metrics: Metric[];
}

export interface WellComplianceStatus {
    certification: WellComplianceState;
    recertification: WellComplianceState;
    compliancePercentage: number;
    compliantPoints: number;
    totalPoints: number;
    thresholds: Record<string, any>;
    // FIX: Added optional historicalData property for drill-down functionality.
    historicalData?: HistoricalData[];
}

export type WellComplianceReport = Record<WellFeatureId, WellComplianceStatus>;

export type OccupancyDay = 'Sun' | 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat';
export interface OccupancySchedule {
    days: Record<OccupancyDay, boolean>;
    startTime: string; // "HH:mm"
    endTime: string;   // "HH:mm"
}

export interface WellSettings {
    schedule: OccupancySchedule;
    thresholdOverrides: Partial<Record<Metric, number | { min: number; max: number }>>;
}

export interface WellDrillDownData {
    feature: WellFeature;
    status: WellComplianceStatus;
    historicalData: HistoricalData[];
}


// --- LEED Report ---
export type LeedMetric = 'pm25' | 'co2' | 'voc' | 'hcho';
export type LeedDateRange = '24h' | '7d' | '30d';
export interface LeedReportData {
    location: { building: string; floor: string };
    period: { from: string; to: string };
    isOverallCompliant: boolean;
    metrics: Record<LeedMetric, {
        isCompliant: boolean;
        threshold: number;
        unit: string;
        peak: number;
        average: number;
        trend: { timestamp: string; value: number }[];
    }>;
}

// --- RESET Report ---
export type ResetMetric = 'pm25' | 'voc' | 'co2';
export interface DailyResetBreakdown {
    date: string;
    isCompliant: boolean;
    metrics: Record<ResetMetric, {
        value: number;
        isCompliant: boolean;
    }>;
}
export interface ResetReportData {
    overallCompliance: {
        totalDays: number;
        compliantDays: number;
        percentage: number;
    };
    dailyBreakdown: DailyResetBreakdown[];
    metricSummaries: Record<ResetMetric, {
        periodAverage: number;
        peakDailyAverage: number;
        daysExceeded: number;
        dailyAverages: { date: string; value: number }[];
    }>;
}

// --- Glance View ---
export type MajorPollutant = 'pm25' | 'co2' | 'voc';
export type GlanceTimePeriod = '30d' | '12m';

export interface GlanceSummary {
    name: string;
    level: 'site' | 'building';
    totalCount: number;
    onlineCount: number;
    trend: { time: string; aqi: number }[];
    pollutantTrends?: Record<MajorPollutant, { time: string; value: number }[]>;
}

export interface SiteDetails {
    siteName: string;
    pollutantTrends: Record<MajorPollutant, { time: string; value: number }[]>;
    buildingSummaries: (GlanceSummary & { pollutantTrends: Record<MajorPollutant, { time: string; value: number }[]> })[];
}

// --- AHU Report ---
export type FilterType = 'Panel' | 'Bag' | 'V-Cell';
export type FilterGrade = 'MERV 8' | 'MERV 13' | 'F7' | 'F8' | 'HEPA 13' | 'Custom';
export type ParticleSize = 'pm05' | 'pm1' | 'pm25';

export interface FilterStage {
    id: string;
    name: string;
    type: FilterType;
    grade: FilterGrade;
    initialDp: number;
    cost: number;
    lifespanDays: number;
    standardFilterInitialDp: number;
    standardFilterFinalDp: number;
    standardFilterLifespanDays: number;
    standardFilterCost: number;
}

export interface RosaiqAhsMonitor {
    id: string;
    targetParticleSize: ParticleSize;
}

export interface AhuHistoricalPoint {
    timestamp: string;
    totalDifferentialPressure: number;
    particleEfficiency: number;
    stageData: { dp: number; efficiency: number; }[];
    standardStageData: { dp: number }[];
}

export interface AhuReport {
    id: string;
    name: string;
    totalDpChangeThreshold: number;
    airflowRate: number; // in CFM
    fanEfficiency: number; // in %
    filterStages: FilterStage[];
    rosaiqMonitor: RosaiqAhsMonitor;
    historicalData: AhuHistoricalPoint[];
}

export type AhuReportData = AhuReport[];

// --- Air Purifier ---
export interface AirPurifierConfig {
    deviceId: string;
    cadr: number; // Clean Air Delivery Rate in CFM
    roomArea: number | null; // sq ft
    autoMode: {
        enabled: boolean;
        occupancyRequired: boolean;
        pm25Threshold: number | null;
        vocThreshold: number | null;
    }
}