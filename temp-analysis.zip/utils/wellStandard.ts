import { WellFeature, Metric, WellFeatureId } from '../types';

export const WELL_FEATURES: WellFeature[] = [
    { id: 'A01', name: 'Fundamental Air Quality', type: 'Precondition', description: 'Meet thresholds for PM2.5 and TVOCs.', metrics: ['pm25', 'voc']},
    { id: 'A03', name: 'Ventilation Effectiveness', type: 'Precondition', description: 'Ensure CO2 levels are within acceptable limits.', metrics: ['co2']},
    { id: 'T01', name: 'Thermal Performance', type: 'Precondition', description: 'Monitor temperature to ensure thermal comfort.', metrics: ['temp']},
    { id: 'A05', name: 'Enhanced Air Quality', type: 'Optimization', points: 3, description: 'Meet stricter thresholds for PM2.5, PM10, and CO.', metrics: ['pm25', 'pm10']},
    { id: 'A06', name: 'Enhanced Ventilation', type: 'Optimization', points: 2, description: 'Maintain lower CO2 levels for enhanced performance.', metrics: ['co2']},
    { id: 'A08', name: 'Air Quality Monitoring & Awareness', type: 'Optimization', points: 2, description: 'Install monitors and display data.', metrics: []},
    { id: 'T06', name: 'Thermal Comfort Monitoring', type: 'Optimization', points: 1, description: 'Monitor Temp & RH.', metrics: ['temp', 'humidity']},
    { id: 'T07', name: 'Humidity Control', type: 'Optimization', points: 1, description: 'Maintain relative humidity within an ideal range.', metrics: ['humidity']},
];


// FIX: Imported WellFeatureId to resolve type error.
export const WELL_THRESHOLDS: Record<WellFeatureId, Record<string, any>> = {
    A01: { pm25: 15, voc: 500 }, // voc in µg/m³
    A03: { co2: 900 }, // ppm
    A05: { pm25: 10, pm10: 20 },
    A06: { co2: 750 },
    A08: {}, // No thresholds, based on installation
    T01: { temp_min: 21, temp_max: 26 }, // °C
    T06: { temp_min: 21, temp_max: 26, humidity_min: 30, humidity_max: 60 },
    T07: { humidity_min: 30, humidity_max: 60 } // %
};